# PassiveSubs

Turns native Japanese subtitles into **passive-learning karaoke subtitles**, following the method shown in
[this video](https://www.youtube.com/watch?v=3wF91iArEp0) (see [Credits](#credits)):

```
Japanese:    昨日、友達と海に行った。
PassiveSubs: YESTERDAY, FRIEND to SEA ni GO-tta.
```

No subtitles, videos or name lists for any show are included: bring your own Japanese subtitle file.

* Japanese word order is kept, so your brain learns the grammar by ear.
* Meaning-carrying words are **UPPERCASE English**; grammar (particles, endings) stays **lowercase romaji**
  (or hiragana, if you prefer).
* Every piece is a karaoke syllable, so words appear or glow as they're spoken.
* Output is a `.ass` file (load it in VLC: *Subtitle > Add Subtitle File*, or mpv).

## Start (Windows)

1. Double-click **`Start.bat`**. It uses your normal Python (3.10 or newer, including 3.15) and installs everything
   into a private `.venv` folder on the first run (a minute or two). If setup ever fails halfway, run it again:
   it cleans up and retries.
2. Word splitting uses fugashi (MeCab + UniDic) where it installs (Python 3.10 - 3.14), and otherwise the
   pure-Python janome splitter, which gives nearly the same results. The log shows which one is in use.
3. Drop the episode into the **VIDEO** box. If the video has no Japanese subtitles inside it, also drop the
   Japanese `.ass`/`.srt` file into the **JAPANESE SUBTITLES** box (files dropped on the wrong box are moved to the right one).
4. Click **Convert**. The new file is saved next to the video, e.g. `Episode01.PassiveRomaji.ass`.

Where the Japanese comes from, in order:
1. the file in the JAPANESE SUBTITLES box, if you gave one;
2. a subtitle file next to the video with the same name (`Episode01.ja.srt`, `Episode01.jpn.ass`, ...);
3. the Japanese subtitle track inside the video (found by its language tag, or by looking for Japanese text).

Picture-based subtitle tracks (Blu-ray PGS / DVD VobSub) can't be read; use a text `.srt`/`.ass` file for those.

## Timing: auto-align

When the Japanese subtitles are a separate file (for example subtitles from a streaming service used with a different release),
they are often timed for a different version of the episode. PassiveSubs listens to the video's audio, finds
where people are talking, and moves the subtitles to match. It can apply different shifts to different parts,
so a missing intro, opening song or bumper is handled. Lines that aren't in the video (cut opening lyrics,
anything past the end) are removed. A report shows what it changed.
Click **Preview in VLC** to check. If it's still slightly early or late, set **Then shift by** (seconds) and convert again.
Subtitles taken from inside the video itself are already timed for it and are left as they are.

**Wrong subtitle file?** When a separate subtitle file doesn't seem to belong to the video, PassiveSubs warns
you (the .ass is still saved). It checks whether the subtitles run longer than the video or cover much less of it,
whether the file names name a different show or episode, and whether auto-align had to chop the subtitles into
many pieces to fit the speech (the right file needs only 1 to 3).

**Switching to new subtitles.** PassiveSubs never changes the video: its subtitles are separate `.ass` files next
to it, and VLC loads every one whose name starts with the video's name. So when you convert a video again, the
older PassiveSubs files for it are moved into an **Old PassiveSubs** folder beside the video (nothing is deleted),
and the player finds only the new one. **Remove old subs** does the same without converting. **Preview in VLC**
always shows just the newest file.

**Clean video copy** (after converting) makes `<video>.PassiveSubs.mkv`: the same picture and sound, copied
without re-encoding, with the video's built-in subtitle tracks (English, Spanish, ...) left out and your
PassiveSubs subtitles as its only track, switched on. The original video isn't changed. It's always .mkv because
.mp4 can't keep karaoke styling.

**Subtitle formats.** Text: .ass .ssa .srt .vtt .smi/.sami .ttml/.dfxp (Netflix-style) .sbv (YouTube) .lrc
.sub (MicroDVD or SubViewer) .mpl .txt .json and the rarer ones ffmpeg knows (AQTitle, JACOsub, PJS, RealText,
Spruce STL, SCC, VPlayer). Any text encoding: UTF-8/16, Shift-JIS, EUC-JP and Chinese/Korean fansub encodings
are detected automatically. Pictures: Blu-ray .sup and DVD .idx/.sub (see below). Subtitle tracks inside
.mkv/.mp4 videos work too, text or picture.

**Blu-ray picture subtitles (.sup).** DVD .idx/.sub files and DVD subtitle tracks inside a video work the same way. Blu-ray rips often have the Japanese subtitles as pictures (a `.sup` file,
or a "PGS" track inside the .mkv). Drop the .sup in the JAPANESE SUBTITLES box (or leave it empty if the track is
inside the video). The app asks Claude to read the pictures into text, so it needs your API key in the Claude AI
box (the AI option itself can stay off). This happens once: the text is saved as `<name>.ja.srt` and reused.

**Where do I get Japanese subtitles?** Many downloads only have English and other languages built in. Then the app
says so, and you need a Japanese .srt/.ass for the episode. Drop it
in the JAPANESE SUBTITLES box; auto-align lines it up with your video. Files PassiveSubs made (`.Passive...ass`)
can't be used as input. The **Character names** list starts on Automatic each time, so a new show doesn't get
another show's names.

## Songs: lyrics mode

For an opening or ending (or any song video) where you only have the lyrics as plain text:

1. Drop the video (e.g. a creditless OP) into the **VIDEO** box.
2. Drop a `.txt` with the Japanese lyrics, one line per sung line, into the **JAPANESE SUBTITLES** box.
   No timestamps needed; blank lines and romaji/English lines are ignored, and very long lines are split at spaces.
3. Click **Convert**. The result is the usual PassiveSubs karaoke file, with each word timed to when it is sung.

How it works: the singer's voice is separated from the music, a Japanese speech recogniser listens to it, and each
character of your lyrics is matched to what it heard. The first time, the models (about 230 MB) are downloaded to
`%APPDATA%\PassiveSubs\models`; after that it works offline and takes about a minute per song. The timing is saved
in a `PassiveSubs lyrics timing` folder next to the video (so VLC doesn't show it as a second, plain Japanese subtitle
track) and reused the next time. You can fix a line there by hand.

Tested on a TV-size anime opening: 88% of lyric characters were matched to the recogniser, and line
starts landed within about 0.1 s of the singing (lines appear 0.15 s early so you can read ahead).
Lyrics for the full song work with the shorter TV-size opening: lines that nobody sings in the video are left
out, and the log lists them. If the singing doesn't match the lyrics at all (wrong song), it stops and says so.

## Options

| Option | What it does |
|---|---|
| Romaji / Hiragana | How untranslated grammar is written: `wa, ni, -ta` or `は, に, -た`. |
| Karaoke effect | *Words appear* (the main style), *Whole line glows*, or *Plain karaoke* (no effects, for editing in Aegisub). |
| Particle を | `o` or `wo`. |
| Pronunciation above words | Tick *Show the Japanese pronunciation in small text above each English word* to get furigana-style readings: `kime` above `DECIDE-ta`, `tokoro` above `PLACE` (or `きめ`, `ところ` in hiragana mode; loanwords stay katakana, `サークル` above `CLUB`). Only the part the English replaces is shown, so `TELL-ru` gets `tsutae`. With *Words appear* each reading appears with its word. Long lines are split into rows by PassiveSubs itself so the readings line up; this works for lines at the top of the screen too. Names have no reading (they are already the sound). |
| Character names | *Automatic* picks a name list from `passive_subs/data/names` when the show's name is in the file name, or when the subtitles use several of a list's names. None are included for real shows: copy `Example_Show.txt`, rename it after your show (`My_Show.txt`) and fill in its names; a line like `# also: myshow, マイショー` adds other names the show goes by in file names. Or choose a list by hand. Names the subtitles give a reading for, like `春香(はるか)`, are picked up automatically, and a full name is split into its two halves (`山田花子(やまだはなこ)` gives YAMADA-HANAKO and HANAKO). Speaker labels such as `（春香）`, sound notes such as `（笛の音）`, separate furigana/ruby lines and Chinese fansub credits are left out. For anything else use **Edit my glossary** (`春香 = HARUKA`). |
| Show names as | `KAEDE` (the name), `KAEDE (MAPLE)` (name + the literal meaning of its kanji), or just `(MAPLE)`: you already hear the name, and the brackets tell you it's a name. Names with no known meaning stay as the name. |
| Words I know | Click *Manage words I know...*, type words you have learned (`猫 ばか やめて ごめんなさい`, separated by normal or Japanese spaces) and press **Add**. It tells you which were new and which were already in your list, and you can select and remove any word. These words are shown in Japanese instead of English (`猫 ga FISH o 食べ-ta`), so you move from learning the sound to reading the kanji. Conjugated entries like `やめて` match every form of the word; phrases like `ごめんなさい` match as written. Saved for every show (`%APPDATA%\PassiveSubs\known_words.txt`). |
| Words to learn | After converting, the panel on the right shows the most frequent words in those subtitles that you don't know yet (Japanese, reading, English, how often). Tick the ones you know and add them to Words I know in one click, or export the list as CSV for Anki / Excel. |
| Flashcards | Click *Study these words with flashcards...* under Words to learn. The 20 most frequent new words from the episode become cards (saved between sessions in `%APPDATA%\PassiveSubs\flashcards`). Each card plays the moment the word is said in the video (*Play the whole line* for context): guess the meaning, press Space to see it, then **Failed** (it comes back in a few cards) or **Remembered**. Remember a word 3 times in a row and it moves to a test: a sentence with the word missing (a new one written by Claude if you gave an API key, otherwise the line from the episode) and four kana to pick from. Pick right and the word goes to Words I know; pick wrong and it goes back to learning. To find the exact moment in the audio it uses the speech recogniser from lyrics mode (downloaded once, about 230 MB); until that's there, the clip is cut from the subtitle timing, which is close but can be a little off. |
| My permanent glossary | Same format, applied to every conversion (saved in `%APPDATA%\PassiveSubs\my_glossary.txt`). |
| Claude AI (optional) | With an Anthropic API key, Claude picks the right meaning of each word for the sentence and romanizes names, then makes a second pass that double-checks every line against the sentences around it and fixes what is still wrong (the log lists each fix and why). Without it, the offline dictionary is used. Every conversion also gets a free format check (UPPERCASE glosses, hyphens, nothing Japanese left in a gloss). |

## How it works

1. **Read** the Japanese lines (`pysubs2`; `ffmpeg` pulls the track out of videos).
2. **Split into words** with MeCab + UniDic (`fugashi`, `unidic-lite`), which gives part of speech, dictionary form and reading.
3. **Decide per word**: content words (nouns, verbs, adjectives, katakana loanwords, names) get an UPPERCASE gloss;
   particles, auxiliaries and conjugation endings stay romaji and hang off their word with a dash (`AID-shi-te-iru`).
4. **Gloss** from an offline JMdict/KANJIDIC dictionary (+ built-in overrides in `passive_subs/data/overrides.txt`),
   or from Claude when enabled.
5. **Time** each piece. Native subtitles only have line timing, so word timing is estimated from the number of
   spoken syllables (about 8 per second, the rest of the line goes to the last word), exactly the shape of the
   hand-timed files. For perfect timing, open the "Plain karaoke" output in Aegisub and adjust.
6. **Write** the `.ass` with the same karaoke templates as the original project
   (raw karaoke lines are kept as comments, so Aegisub can re-apply the template).

## Command line

```
convert-cli.bat Episode01.mkv --names "春香=HARUKA, 楓=KAEDE"
convert-cli.bat *.srt --hiragana --effect nofx
convert-cli.bat Episode01.mkv --ai --context "My Show episode 1"   (needs ANTHROPIC_API_KEY)
```

## Limits

* Dictionary mode takes the most common meaning, so some words will be off (e.g. slang, puns, names the
  dictionary doesn't know). Add them to a name list or your glossary, or use the Claude option.
* Timing is estimated, not aligned to the audio.

## Credits

* **Method.** The idea (Japanese word order, UPPERCASE English for meaning words, lowercase romaji grammar,
  karaoke timing) comes from the *Karaoke Subs That Teach Japanese* project and its
  [video](https://www.youtube.com/watch?v=3wF91iArEp0). PassiveSubs is an independent tool that produces
  subtitles in that style; none of that project's subtitle files are included here.
* **Dictionary data.** `passive_subs/data/jmdict_gloss.json.gz` is derived from
  [JMdict and KANJIDIC2](https://www.edrdg.org/wiki/index.php/JMdict-EDICT_Dictionary_Project), the property of the
  [Electronic Dictionary Research and Development Group](https://www.edrdg.org/), used in conformance with the
  Group's [licence](https://www.edrdg.org/edrdg/licence.html) (Creative Commons Attribution-ShareAlike). That file
  stays under CC BY-SA; see [`passive_subs/data/README.md`](passive_subs/data/README.md). Rebuild it with
  `pip install jamdict-data` and `python tools/build_dict.py`.
* **Libraries.** fugashi + unidic-lite (MeCab, UniDic), janome, pysubs2, imageio-ffmpeg (FFmpeg), tkinterdnd2,
  numpy, sherpa-onnx, and the Anthropic Python SDK. Lyrics mode downloads the UVR MDX vocal-separation model and
  the SenseVoice speech model from the [sherpa-onnx releases](https://github.com/k2-fsa/sherpa-onnx/releases)
  on first use; they keep their own licences and are not part of this repository.

## Licence

The code is released under the [MIT licence](LICENSE). The bundled dictionary file is under CC BY-SA (see above).
