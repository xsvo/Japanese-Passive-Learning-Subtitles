"""Build passive_subs/data/jmdict_gloss.json.gz, a compact headword->gloss dictionary, from the
JMdict / KANJIDIC2 sqlite database in the jamdict-data package.

    pip install jamdict-data
    python tools/build_dict.py                      # finds the database and writes the default file
    python tools/build_dict.py jamdict.db out.json.gz

The dictionary data is (c) the Electronic Dictionary Research and Development Group (EDRDG),
licensed CC BY-SA (https://www.edrdg.org/edrdg/licence.html). The generated file carries that licence.
"""
import sqlite3, json, gzip, re, sys, collections, os, lzma, shutil, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, "..", "passive_subs", "data", "jmdict_gloss.json.gz")


def find_db():
    try:
        import jamdict_data
    except ImportError:
        sys.exit("Install the dictionary first:  pip install jamdict-data")
    xz = os.path.join(os.path.dirname(jamdict_data.__file__), "jamdict.db.xz")
    db = os.path.join(tempfile.gettempdir(), "jamdict.db")
    if not os.path.exists(db):
        print("Unpacking", xz)
        with lzma.open(xz) as src, open(db, "wb") as dst:
            shutil.copyfileobj(src, dst)
    return db


db = sys.argv[1] if len(sys.argv) > 1 else find_db()
out = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUT
c = sqlite3.connect(db)
def prio_score(tags):
    s = 0
    for t in tags:
        if t in ('news1','ichi1','spec1','gai1'): s = max(s, 3)
        elif t in ('news2','ichi2','spec2','gai2'): s = max(s, 2)
        elif t.startswith('nf'):
            s = max(s, 2 if int(t[2:]) <= 24 else 1)
    return s
kanji = collections.defaultdict(list)
for kid, idseq, text in c.execute("select ID, idseq, text from Kanji"):
    kanji[idseq].append((kid, text))
kjp = collections.defaultdict(list)
for kid, t in c.execute("select kid, text from KJP"): kjp[kid].append(t)
kana = collections.defaultdict(list)
for kid, idseq, text in c.execute("select ID, idseq, text from Kana"):
    kana[idseq].append((kid, text))
knp = collections.defaultdict(list)
for kid, t in c.execute("select kid, text from KNP"): knp[kid].append(t)
senses = collections.defaultdict(list)
for sid, idseq in c.execute("select ID, idseq from Sense order by ID"):
    senses[idseq].append(sid)
gl = collections.defaultdict(list)
for sid, lang, text in c.execute("select sid, lang, text from SenseGloss order by rowid"):
    if lang in (None, '', 'eng'): gl[sid].append(text)
pos = collections.defaultdict(list)
for sid, t in c.execute("select sid, text from pos"): pos[sid].append(t)
misc = collections.defaultdict(list)
for sid, t in c.execute("select sid, text from misc"): misc[sid].append(t)

def clean(g):
    g = re.sub(r'\([^)]*\)', '', g)
    g = re.sub(r'\s+', ' ', g).strip(' ;,.')
    g = re.sub(r'^to ', '', g)
    g = re.sub(r'^(be|become) able to ', '', g) if False else g
    return g.strip()
def pick(glosses):
    cs = [clean(g) for g in glosses]
    cs = [g for g in cs if g]
    if not cs: return None
    for g in cs:
        if len(g.split()) <= 3 and len(g) <= 24: return g
    return min(cs, key=len)

D = collections.defaultdict(list)  # headword -> [score, readings, gloss, flags]
for idseq, sids in senses.items():
    gloss = None; flags = []
    for sid in sids[:3]:
        if not gl[sid]: continue
        m = misc[sid]
        g = pick(gl[sid])
        if g:
            gloss = g
            p = ' '.join(pos[sid])
            pass
            if 'uk' in ' '.join(m) or 'usually written using kana' in ' '.join(m): flags.append('uk')
            break
    if not gloss: continue
    ks = kanji.get(idseq, []); rs = kana.get(idseq, [])
    readings = [t for _, t in rs]
    kscore = max([prio_score(kjp[k]) for k, _ in ks] or [0])
    rscore = max([prio_score(knp[k]) for k, _ in rs] or [0])
    for k, t in ks:
        D[t].append([prio_score(kjp[k]) or kscore, readings[:4], gloss, ''.join(sorted(set(flags)))])
    for k, t in rs:
        D[t].append([prio_score(knp[k]) + (1 if 'uk' in flags or not ks else 0), [], gloss, ''.join(sorted(set(flags)))])
out_d = {}
for h, lst in D.items():
    lst.sort(key=lambda x: -x[0])
    out_d[h] = lst[:4]
with gzip.open(out, 'wt', encoding='utf-8') as f:
    json.dump(out_d, f, ensure_ascii=False, separators=(',', ':'))
print(len(out_d))

# ---- KANJIDIC: single-kanji meaning + reading fallback (key "#<kanji>")
kd = {}
for lit, cid in c.execute("select literal, ID from character"):
    kd[cid] = [lit, None, None]
for cid, val, lang in c.execute("select g.cid, m.value, m.m_lang from rm_group g join meaning m on m.gid=g.ID order by m.rowid"):
    if lang in (None, '', 'en') and kd[cid][1] is None:
        kd[cid][1] = val
for cid, rtype, val in c.execute("select g.cid, r.r_type, r.value from rm_group g join reading r on r.gid=g.ID order by r.rowid"):
    if rtype in ('ja_kun', 'ja_on') and kd[cid][2] is None:
        kd[cid][2] = val.split('.')[0].replace('-', '')
for lit, mean, rd in kd.values():
    if mean:
        out_d['#' + lit] = [[0, [rd] if rd else [], mean, 'k']]
with gzip.open(out, 'wt', encoding='utf-8') as f:
    json.dump(out_d, f, ensure_ascii=False, separators=(',', ':'))
print('with kanji', len(out_d))
