@echo off
setlocal
cd /d "%~dp0"
title PassiveSubs

if exist ".venv\installed.ok" (
  fc /b "requirements.txt" ".venv\installed.ok" >nul 2>nul && goto run
  echo Updating PassiveSubs packages...
  ".venv\Scripts\python.exe" -m pip install --only-binary=fugashi -r requirements.txt
  copy /y "requirements.txt" ".venv\installed.ok" >nul
  goto run
)

echo Setting up PassiveSubs (first run only, needs internet, takes a minute or two)...
echo.
rem A failed earlier setup leaves a half-built .venv behind: start clean.
if exist ".venv" rmdir /s /q ".venv"

rem Use your normal Python (3.10 or newer).
call :find
if defined PY goto make_venv

echo PassiveSubs needs Python 3.10 or newer, and none was found.
echo Please install it from the page that is opening now
echo (tick "Add python.exe to PATH"), then run Start.bat again.
start https://www.python.org/downloads/
pause
exit /b 1

:make_venv
echo Using Python: %PY%
%PY% -m venv .venv
if not exist ".venv\Scripts\python.exe" ( echo Could not create the virtual environment with %PY%. & pause & exit /b 1 )
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
rem fugashi (most accurate word splitter) only installs where a ready-made build exists;
rem everywhere else the pure-Python janome splitter is used instead.
".venv\Scripts\python.exe" -m pip install --only-binary=fugashi -r requirements.txt
".venv\Scripts\python.exe" -c "import janome, numpy, pysubs2, imageio_ffmpeg, tkinter" >nul 2>nul
if errorlevel 1 ( echo. & echo Installing packages failed - see the messages above. & pause & exit /b 1 )
copy /y "requirements.txt" ".venv\installed.ok" >nul
echo Setup finished.

:run
start "" ".venv\Scripts\pythonw.exe" app.py %*
exit /b 0

rem ---- look for a working Python 3.10+; sets PY
:find
set "PY="
call :try "python"
call :try "py"
call :try "py -3"
call :tryexe "%LOCALAPPDATA%\Python\bin\python.exe"
call :tryexe "%LOCALAPPDATA%\Programs\Python\Python315\python.exe"
call :tryexe "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
call :tryexe "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
call :tryexe "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
exit /b 0

rem ---- a candidate counts only if it really runs and prints version 3.10 or newer
rem      (exit codes are not trusted: some launchers return odd ones on errors)
:try
if defined PY exit /b 0
set "_OUT="
for /f "usebackq delims=" %%v in (`%~1 -c "import sys;print('PYOK'+str(sys.version_info[0])+'.'+str(sys.version_info[1]))" 2^>nul`) do set "_OUT=%%v"
for %%m in (10 11 12 13 14 15 16 17 18 19) do if "%_OUT%"=="PYOK3.%%m" set "PY=%~1"
exit /b 0

:tryexe
if defined PY exit /b 0
if not exist "%~1" exit /b 0
set "_OUT="
for /f "usebackq delims=" %%v in (`"%~1" -c "import sys;print('PYOK'+str(sys.version_info[0])+'.'+str(sys.version_info[1]))" 2^>nul`) do set "_OUT=%%v"
for %%m in (10 11 12 13 14 15 16 17 18 19) do if "%_OUT%"=="PYOK3.%%m" set PY="%~1"
exit /b 0
