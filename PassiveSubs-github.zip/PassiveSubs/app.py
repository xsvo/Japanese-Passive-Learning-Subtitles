"""PassiveSubs desktop app: drop in a video (or Japanese subtitle file), click Convert,
get a passive-learning romaji karaoke .ass subtitle file next to it."""
import json
import os
import re
import queue
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from passive_subs.convert import Settings, convert, parse_names, glossary, LAST_REPORT, LAST_WARNINGS, LAST_UNKNOWN, LAST_AI_ERROR, export_csv, name_presets, read_preset  # noqa: E402
    from passive_subs.glossary import user_glossary_path, load_known_list, save_known_list  # noqa: E402
    from passive_subs.writer import EFFECTS  # noqa: E402
except Exception as _e:  # show setup problems instead of failing silently under pythonw
    _r = tk.Tk(); _r.withdraw()
    messagebox.showerror("PassiveSubs could not start",
                         "%s: %s\n\nDelete the .venv folder and run Start.bat again." % (type(_e).__name__, _e))
    raise

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND = True
except Exception:
    DND = False

APP_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "PassiveSubs")
SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
VIDEO_ONLY = [("Videos", "*.mkv *.mp4 *.webm *.avi *.mov *.m4v *.ts"), ("All files", "*.*")]
from passive_subs.subtitles import SUB_EXTS  # noqa: E402  every subtitle format the app reads
SUB_ONLY = [("Subtitles or song lyrics", " ".join("*" + e for e in sorted(SUB_EXTS | {".txt"}))), ("All files", "*.*")]


def load_settings():
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(d):
    os.makedirs(APP_DIR, exist_ok=True)
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)


class App:
    def __init__(self, root):
        self.root = root
        self.q = queue.Queue()
        self.last_output = None
        self.last_video = None
        s = load_settings()
        root.title("PassiveSubs - Japanese passive-learning subtitles")
        root.geometry("1280x920")
        root.minsize(640, 600)

        pad = {"padx": 12, "pady": 6}
        left = ttk.Frame(root)
        left.pack(side="left", fill="both", expand=True)
        right = ttk.LabelFrame(root, text="Words to learn: most frequent words you don't know yet")
        right.pack(side="left", fill="both", padx=(0, 12), pady=12)
        self._build_words_panel(right)
        ttk.Label(left, text="PassiveSubs", font=("Segoe UI", 18, "bold")).pack(anchor="w", padx=12, pady=(12, 0))
        ttk.Label(left, text="Japanese subtitles in, passive-learning karaoke subtitles out. "
                             "TRANSLATED WORDS UPPERCASE, grammar lowercase, Japanese word order.",
                  wraplength=720).pack(anchor="w", padx=12)

        # --- two drop boxes: the video, and (optionally) a Japanese subtitle file
        boxes = ttk.Frame(left)
        boxes.pack(fill="x", **pad)
        boxes.columnconfigure(0, weight=1, uniform="b")
        boxes.columnconfigure(1, weight=1, uniform="b")
        self.video, self.subtitle = None, None
        self.video_box = self._make_box(boxes, 0, "video")
        self.sub_box = self._make_box(boxes, 1, "subtitle")
        self._refresh_boxes()

        # --- timing
        tim = ttk.LabelFrame(left, text="Timing")
        tim.pack(fill="x", **pad)
        self.auto_align = tk.BooleanVar(value=s.get("auto_align", True))
        ttk.Checkbutton(tim, text="Auto-align the subtitle file to the video's speech\n"
                                  "(fixes missing intros / openings, removes subs that aren't in the video)",
                        variable=self.auto_align).grid(row=0, column=0, columnspan=4, sticky="w", padx=8, pady=4)
        ttk.Label(tim, text="Then shift by:").grid(row=1, column=0, sticky="w", padx=8, pady=(0, 6))
        self.shift = tk.DoubleVar(value=0.0)
        ttk.Spinbox(tim, from_=-600, to=600, increment=0.25, textvariable=self.shift, width=8)\
            .grid(row=1, column=1, sticky="w", pady=(0, 6))
        ttk.Label(tim, text="seconds  (+ later, - earlier; only if the preview is still a bit off)")\
            .grid(row=1, column=2, sticky="w", padx=6, pady=(0, 6))

        # --- options
        opt = ttk.LabelFrame(left, text="Options")
        opt.pack(fill="x", **pad)
        self.script = tk.StringVar(value=s.get("script", "romaji"))
        ttk.Label(opt, text="Untranslated words in:").grid(row=0, column=0, sticky="w", padx=8, pady=4)
        ttk.Radiobutton(opt, text="Romaji (wa, ni, -ta)", variable=self.script, value="romaji").grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(opt, text="Hiragana (は, に, -た)", variable=self.script, value="hiragana").grid(row=0, column=2, sticky="w")

        ttk.Label(opt, text="Karaoke effect:").grid(row=1, column=0, sticky="w", padx=8, pady=4)
        self.effect_names = {v: k for k, v in EFFECTS.items()}
        self.effect = tk.StringVar(value=EFFECTS.get(s.get("effect", "appear"), EFFECTS["appear"]))
        ttk.Combobox(opt, textvariable=self.effect, values=list(EFFECTS.values()), state="readonly", width=40)\
            .grid(row=1, column=1, columnspan=2, sticky="w")

        ttk.Label(opt, text="Particle を as:").grid(row=2, column=0, sticky="w", padx=8, pady=4)
        self.wo = tk.StringVar(value=s.get("wo", "o"))
        ttk.Radiobutton(opt, text="o", variable=self.wo, value="o").grid(row=2, column=1, sticky="w")
        ttk.Radiobutton(opt, text="wo", variable=self.wo, value="wo").grid(row=2, column=2, sticky="w")
        self.intro = tk.BooleanVar(value=False)   # the explanation lines at the start: off by default
        self.ruby = tk.BooleanVar(value=s.get("ruby", False))
        ttk.Checkbutton(opt, text="Show the Japanese pronunciation in small text above each English word",
                        variable=self.ruby).grid(row=3, column=0, columnspan=3, sticky="w", padx=8, pady=4)

        ttk.Label(opt, text="Character names:").grid(row=4, column=0, sticky="w", padx=8, pady=4)
        self.presets = name_presets()
        auto = "Automatic (from the file name)"
        self.preset_names = [auto] + list(self.presets) + ["None"]
        # a show picked last time isn't kept: the next video is often a different show
        self.preset = tk.StringVar(value="None" if s.get("preset") == "None" else auto)
        ttk.Combobox(opt, textvariable=self.preset, values=self.preset_names, state="readonly", width=30)\
            .grid(row=4, column=1, sticky="w", pady=4)
        ttk.Button(opt, text="Edit my glossary...", command=self.open_glossary)\
            .grid(row=4, column=2, sticky="w", pady=4)
        self.name_styles = {"name": "Name:  KAEDE", "both": "Name + meaning:  KAEDE (MAPLE)",
                            "meaning": "Meaning only:  (LEVER)"}
        style = s.get("name_style") or ("both" if s.get("name_meanings") else "name")
        self.name_style = tk.StringVar(value=self.name_styles.get(style, self.name_styles["name"]))
        ttk.Label(opt, text="Show names as:").grid(row=5, column=0, sticky="w", padx=8, pady=4)
        ttk.Combobox(opt, textvariable=self.name_style, values=list(self.name_styles.values()), state="readonly",
                     width=36).grid(row=5, column=1, columnspan=2, sticky="w", pady=4)

        ttk.Label(opt, text="Words I know\n(shown in Japanese, not English):").grid(row=6, column=0, sticky="nw", padx=8)
        self.known_words = load_known_list()
        self.known_count = tk.StringVar()
        ttk.Button(opt, text="Manage words I know...", command=self.open_known)\
            .grid(row=6, column=1, sticky="w", pady=(2, 6))
        ttk.Label(opt, textvariable=self.known_count).grid(row=6, column=2, sticky="w")
        self._update_known_count()
        root.protocol("WM_DELETE_WINDOW", self.close)

        # --- AI
        ai = ttk.LabelFrame(left, text="Smarter translations with Claude AI (optional)")
        ai.pack(fill="x", **pad)
        self.use_ai = tk.BooleanVar(value=s.get("use_ai", False))
        ttk.Checkbutton(ai, text="Use Claude to pick the right meaning of each word in context\n"
                                 "(needs an Anthropic API key; roughly a few cents per episode)",
                        variable=self.use_ai).grid(row=0, column=0, columnspan=2, sticky="w", padx=8, pady=4)
        ttk.Label(ai, text="API key:").grid(row=1, column=0, sticky="w", padx=8)
        self.api_key = tk.StringVar(value=s.get("api_key", os.environ.get("ANTHROPIC_API_KEY", "")))
        ttk.Entry(ai, textvariable=self.api_key, show="*", width=56).grid(row=1, column=1, sticky="w", pady=2)
        ttk.Button(ai, text="Check key", command=self.check_key).grid(row=1, column=2, sticky="w", padx=6)
        self.key_msg = tk.StringVar(value="")
        self.key_msg_l = tk.Label(ai, textvariable=self.key_msg, fg="#b03a2e", justify="left", wraplength=560)
        self.key_msg_l.grid(row=3, column=0, columnspan=3, sticky="w", padx=8)
        self.api_key.trace_add("write", lambda *_a: self.key_msg.set(""))
        ttk.Label(ai, text="Show (helps AI):").grid(row=2, column=0, sticky="w", padx=8)
        self.context = tk.StringVar(value="")
        ttk.Entry(ai, textvariable=self.context, width=56).grid(row=2, column=1, sticky="w", pady=(2, 6))

        # --- convert
        bar = ttk.Frame(left)
        bar.pack(fill="x", **pad)
        style = ttk.Style()
        style.configure("Big.TButton", font=("Segoe UI", 13, "bold"), padding=8)
        self.btn = ttk.Button(bar, text="Convert", style="Big.TButton", command=self.start)
        self.btn.pack(side="left")
        self.open_btn = ttk.Button(bar, text="Open output folder", command=self.open_folder, state="disabled")
        self.open_btn.pack(side="left", padx=10)
        self.vlc_btn = ttk.Button(bar, text="Preview in VLC", command=self.preview, state="disabled")
        self.vlc_btn.pack(side="left")
        ttk.Button(bar, text="Remove old subs", command=self.delete_old_subs).pack(side="left", padx=(10, 0))
        self.clean_btn = ttk.Button(bar, text="Clean video copy", command=self.clean_copy, state="disabled")
        self.clean_btn.pack(side="left", padx=(10, 0))
        self.prog = ttk.Progressbar(bar, mode="determinate", maximum=1.0)
        self.prog.pack(side="left", fill="x", expand=True, padx=(10, 0))

        self.log = tk.Text(left, height=8, font=("Consolas", 9), state="disabled", bg="#fbfbfb")
        self.log.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.write_log("Ready. Drop the video on the left. If it has no Japanese subtitles inside, drop a Japanese .ass/.srt on the right.")
        if not DND:
            self.write_log("(Drag-and-drop unavailable; click the boxes to choose files.)")
        root.after(100, self.poll)

    # ---------------------------------------------------------------
    def _make_box(self, parent, col, kind):
        frame = ttk.Frame(parent)
        frame.grid(row=0, column=col, sticky="nsew", padx=(0, 6) if col == 0 else (6, 0))
        lab = tk.Label(frame, relief="groove", bd=2, height=5, bg="#f4f6fb", font=("Segoe UI", 10),
                       cursor="hand2", wraplength=330, justify="center")
        lab.pack(fill="both", expand=True)
        lab.bind("<Button-1>", lambda e: self.pick(kind))
        ttk.Button(frame, text="Clear", width=7, command=lambda: self.set_file(kind, None)).pack(anchor="e", pady=(2, 0))
        if DND:
            lab.drop_target_register(DND_FILES)
            lab.dnd_bind("<<Drop>>", lambda e: self.on_drop(e, kind))
        return lab

    def _refresh_boxes(self):
        if self.video:
            self.video_box.config(text="VIDEO\n" + os.path.basename(self.video), bg="#e8f4ea")
        else:
            self.video_box.config(text="VIDEO\nDrop the episode here (or click)\n.mkv  .mp4  .webm", bg="#f4f6fb")
        if self.subtitle:
            self.sub_box.config(text="JAPANESE SUBTITLES\n" + os.path.basename(self.subtitle), bg="#e8f4ea")
        else:
            self.sub_box.config(text="JAPANESE SUBTITLES (optional)\nDrop a .ass / .srt here (or click)\n"
                                     "or a .txt of song lyrics. Leave empty to use the subtitles inside the video", bg="#f4f6fb")

    def set_file(self, kind, path):
        from passive_subs.subtitles import is_passivesubs_file
        if path and os.path.splitext(path)[1].lower() in SUB_EXTS and is_passivesubs_file(path):
            messagebox.showwarning("That's a PassiveSubs file", os.path.basename(path) + " is subtitles this app "
                                   "already made, not the original Japanese ones, so it can't be converted again.\n\n"
                                   "Drop the Japanese .ass/.srt you downloaded for this episode instead. If the "
                                   "video has Japanese subtitles inside it, leave this box empty.")
            return
        # files dropped on the wrong box go where they belong
        if path and os.path.splitext(path)[1].lower() in SUB_EXTS | {".txt"}:  # .txt = song lyrics
            kind = "subtitle"
        elif path:
            kind = "video"
        if kind == "video":
            self.video = path
        else:
            self.subtitle = path
        self._refresh_boxes()

    def on_drop(self, event, kind):
        for f in self.root.tk.splitlist(event.data):
            self.set_file(kind, f)

    def pick(self, kind):
        if kind == "video":
            f = filedialog.askopenfilename(title="Choose the video", filetypes=VIDEO_ONLY)
        else:
            f = filedialog.askopenfilename(title="Choose the Japanese subtitle file", filetypes=SUB_ONLY)
        if f:
            self.set_file(kind, f)

    def _update_known_count(self):
        n = len(self.known_words)
        self.known_count.set("%d word%s in your list" % (n, "" if n == 1 else "s"))

    def save_known(self):
        try:
            save_known_list(self.known_words)
        except Exception:
            pass
        return set(self.known_words)

    def close(self):
        self.save_known()
        self.root.destroy()

    def open_known(self):
        """A window to add words you know (checked against your list) and remove them again."""
        if getattr(self, "_known_win", None) and self._known_win.winfo_exists():
            self._known_win.lift()
            return
        win = self._known_win = tk.Toplevel(self.root)
        win.title("Words I know")
        win.geometry("620x580")
        ttk.Label(win, text="Words you already know are shown in Japanese instead of English, so you move\n"
                            "from learning the sound to reading the kanji. Type one or more words, separated\n"
                            "by spaces (normal or Japanese), and press Add. Conjugated forms like やめて also\n"
                            "match the other forms of the word (やめた, やめない ...).",
                  justify="left").pack(anchor="w", padx=10, pady=(10, 6))
        row = ttk.Frame(win)
        row.pack(fill="x", padx=10)
        entry = ttk.Entry(row, font=("Segoe UI", 11))
        entry.pack(side="left", fill="x", expand=True)
        status = tk.Text(win, height=5, wrap="word", font=("Segoe UI", 9), relief="flat",
                         background=win.cget("background"))
        count = tk.StringVar()
        mid = ttk.Frame(win)
        lb = tk.Listbox(mid, selectmode="extended", font=("Segoe UI", 11), activestyle="none")
        sb = ttk.Scrollbar(mid, orient="vertical", command=lb.yview)
        lb.config(yscrollcommand=sb.set)

        def refresh(select=()):
            lb.delete(0, "end")
            for w in self.known_words:
                lb.insert("end", w)
            for w in select:
                if w in self.known_words:
                    i = self.known_words.index(w)
                    lb.selection_set(i)
                    lb.see(i)
            count.set("%d words in your list" % len(self.known_words))
            self._update_known_count()

        def say(msg):
            status.config(state="normal")
            status.delete("1.0", "end")
            status.insert("1.0", msg)
            status.config(state="disabled")

        def add(_e=None):
            typed = [w for w in re.split(r"[\s\u3000,、，;；/]+", entry.get()) if w and not w.isascii()]
            new, already, seen = [], [], set()
            for w in typed:
                if w in seen:
                    continue
                seen.add(w)
                (already if w in self.known_words else new).append(w)
            self.known_words.extend(new)
            self.save_known()
            entry.delete(0, "end")
            parts = []
            if new:
                parts.append("Added %d new: %s" % (len(new), "  ".join(new)))
            if already:
                parts.append("Already in your list (%d): %s" % (len(already), "  ".join(already)))
            repeats = len([w for w in typed]) - len(seen)
            if repeats:
                parts.append("%d repeated in what you typed, added once." % repeats)
            notes = self._known_notes(new)
            if notes:
                parts.append("Matching: " + ";  ".join("%s = %s" % kv for kv in notes.items()))
            if not typed:
                parts.append("Type Japanese words first.")
            say("\n".join(parts))
            refresh(select=new + already)

        def remove():
            sel = [self.known_words[i] for i in lb.curselection()]
            if not sel:
                say("Click a word in the list (Ctrl+click for several), then Remove.")
                return
            self.known_words[:] = [w for w in self.known_words if w not in sel]
            self.save_known()
            say("Removed: " + "  ".join(sel))
            refresh()

        def find(*_a):
            q = entry.get().strip()
            if q in self.known_words:
                i = self.known_words.index(q)
                lb.selection_clear(0, "end")
                lb.selection_set(i)
                lb.see(i)

        ttk.Button(row, text="Add", command=add).pack(side="left", padx=(6, 0))
        entry.bind("<Return>", add)
        entry.bind("<KeyRelease>", find)
        status.pack(fill="x", padx=10, pady=6)
        ttk.Label(win, textvariable=count).pack(anchor="w", padx=10)
        mid.pack(fill="both", expand=True, padx=10, pady=4)
        lb.pack(side="left", fill="both", expand=True)
        sb.pack(side="left", fill="y")
        bottom = ttk.Frame(win)
        bottom.pack(fill="x", padx=10, pady=(4, 10))
        ttk.Button(bottom, text="Remove selected", command=remove).pack(side="left")
        lb.bind("<Delete>", lambda _e: remove())
        ttk.Button(bottom, text="Close", command=win.destroy).pack(side="right")
        refresh()
        say("Your list is saved for every show. Select words and press Remove (or Delete) to take them out.")
        entry.focus_set()

    def _build_words_panel(self, win):
        """Right-hand panel: the most frequent words in the last subtitles that aren't in Words I know."""
        ttk.Label(win, text="After you convert, the words that come up most in those subtitles are listed here, "
                            "most frequent first: learn the top ones first. Click the rows of words you know, "
                            "then 'Add ticked to Words I know': from then on they're shown in Japanese.",
                  justify="left", foreground="#444", wraplength=480).pack(anchor="w", padx=8, pady=(6, 4))
        mid = ttk.Frame(win)
        mid.pack(fill="both", expand=True, padx=8)
        cols = ("tick", "word", "reading", "english", "count")
        tv = self.words_tv = ttk.Treeview(mid, columns=cols, show="headings", selectmode="none")
        for c, title, w, anchor in (("tick", "Know it", 58, "center"), ("word", "Japanese", 100, "w"),
                                    ("reading", "Reading", 100, "w"), ("english", "English", 160, "w"),
                                    ("count", "Times", 50, "e")):
            tv.heading(c, text=title)
            tv.column(c, width=w, anchor=anchor, stretch=(c == "english"))
        ttk.Style().configure("Treeview", font=("Segoe UI", 11), rowheight=24)
        sb = ttk.Scrollbar(mid, orient="vertical", command=tv.yview)
        tv.config(yscrollcommand=sb.set)
        tv.pack(side="left", fill="both", expand=True)
        sb.pack(side="left", fill="y")
        self.word_rows, self.word_ticked = [], set()
        self.words_status = tk.StringVar(value="Convert something to see its words here.")
        tv.bind("<Button-1>", self._toggle_word)
        ttk.Label(win, textvariable=self.words_status, wraplength=470).pack(anchor="w", padx=8, pady=4)
        bottom = ttk.Frame(win)
        bottom.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(bottom, text="Add ticked to Words I know", command=self._add_ticked).pack(side="left")
        ttk.Button(bottom, text="Export (CSV for Anki / Excel)...", command=self._export_words)\
            .pack(side="left", padx=8)
        ttk.Button(win, text="Study these words with flashcards...",
                   command=self.open_flashcards).pack(fill="x", padx=8, pady=(0, 8))

    def refresh_words(self):
        self.word_rows = [r for r in LAST_UNKNOWN if r["word"] not in self.known_words]
        self.word_ticked.clear()
        self._fill_words()

    def _fill_words(self, msg=None):
        tv = self.words_tv
        tv.delete(*tv.get_children())
        for i, r in enumerate(self.word_rows):
            tv.insert("", "end", iid=str(i), values=("☑" if i in self.word_ticked else "☐", r["word"],
                                                     r["reading"], r["english"], r["count"]))
        self.words_status.set(msg or "%d words you don't know yet, %d ticked" %
                              (len(self.word_rows), len(self.word_ticked)))

    def _toggle_word(self, event):
        iid = self.words_tv.identify_row(event.y)
        if not iid:
            return
        i = int(iid)
        self.word_ticked.symmetric_difference_update({i})
        self.words_tv.set(iid, "tick", "☑" if i in self.word_ticked else "☐")
        self.words_status.set("%d words you don't know yet, %d ticked" % (len(self.word_rows), len(self.word_ticked)))

    def _add_ticked(self):
        words = [self.word_rows[i]["word"] for i in sorted(self.word_ticked)]
        if not words:
            self.words_status.set("Click the rows of the words you know first.")
            return
        new = [w for w in words if w not in self.known_words]
        self.known_words.extend(new)
        self.save_known()
        self._update_known_count()
        self.word_rows = [r for i, r in enumerate(self.word_rows) if i not in self.word_ticked]
        self.word_ticked.clear()
        self._fill_words("Added to Words I know: %s  (used from the next conversion)" % "  ".join(new))

    def check_key(self):
        from passive_subs.convert import check_api_key
        self.key_msg_l.config(fg="#555")
        self.key_msg.set("Checking the key...")
        key = self.api_key.get()

        def run():
            why = check_api_key(key)
            self.q.put(("keymsg", why))
        threading.Thread(target=run, daemon=True).start()

    def open_flashcards(self):
        from passive_subs import flashcards
        if getattr(self, "_cards_win", None) and self._cards_win.winfo_exists():
            self._cards_win.destroy()

        def known(word):
            if word not in self.known_words:
                self.known_words.append(word)
                self.save_known()
                self._update_known_count()
            self.word_rows = [r for r in self.word_rows if r["word"] != word]
            self.word_ticked.clear()
            self._fill_words()
        show = os.path.splitext(os.path.basename(self.last_video or self.last_output or ""))[0]
        try:
            self._cards_win = flashcards.open_window(self.root, rows=self.word_rows, show=show,
                                                     known=self.known_words, on_known=known,
                                                     api_key=self.api_key.get().strip())
        except Exception as e:
            messagebox.showerror("Flashcards", "Couldn't open the flashcards: %s" % e)

    def _export_words(self):
        if not self.word_rows:
            self.words_status.set("Nothing to export yet: convert something first.")
            return
        from tkinter import filedialog
        base = os.path.splitext(self.last_output or "words")[0]
        path = filedialog.asksaveasfilename(parent=self.root, defaultextension=".csv",
                                            initialfile=os.path.basename(base) + ".words.csv",
                                            initialdir=os.path.dirname(base) or None,
                                            filetypes=[("CSV (Excel, Anki)", "*.csv")])
        if path:
            export_csv(self.word_rows, path)
            self.words_status.set("Saved %d words to %s" % (len(self.word_rows), path))

    def _known_notes(self, words):
        """How conjugated / multi-word entries will be matched, e.g. やめて = every form of やめる."""
        try:
            from passive_subs.analyzer import expand_known
            from passive_subs.tokenizer import get_tagger
            return expand_known(words, get_tagger())[2]
        except Exception:
            return {}

    def open_glossary(self):
        p = user_glossary_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        if not os.path.exists(p):
            with open(p, "w", encoding="utf-8") as f:
                f.write("# My glossary: names and words, used for every conversion. One per line:\n"
                        "# Japanese = HOW-TO-SHOW-IT\n# 春香 = HARUKA\n# 楓 = KAEDE\n# 俺 = ME\n")
        if os.name == "nt":
            os.startfile(p)
        else:
            messagebox.showinfo("Glossary", p)

    def open_folder(self):
        if self.last_output and os.name == "nt":
            os.system('explorer /select,"%s"' % os.path.normpath(self.last_output))

    def delete_old_subs(self):
        """Move every PassiveSubs .ass made for the video in the VIDEO box out of the way."""
        from passive_subs.convert import retire_old_outputs, OLD_DIR
        video = self.video or self.last_video
        if not video:
            messagebox.showinfo("No video", "Put the video in the VIDEO box first.")
            return
        moved = retire_old_outputs(video, log=self.write_log, protect=[self.subtitle])
        if self.last_output and not os.path.exists(self.last_output):
            self.last_output = None
            self.vlc_btn.config(state="disabled")
        if moved:
            messagebox.showinfo("Old subtitles removed", "Moved into the '%s' folder next to the video:\n\n%s\n\n"
                                "The video plays with no PassiveSubs subtitles now. Convert again to make new ones."
                                % (OLD_DIR, "\n".join(moved)))
        else:
            messagebox.showinfo("Nothing to remove", "There are no PassiveSubs subtitle files for this video "
                                "next to it. The video itself never has PassiveSubs subtitles inside it.")

    def clean_copy(self):
        """A copy of the video whose only subtitle track is the PassiveSubs one (built-in tracks removed)."""
        video, ass = self.last_video, self.last_output
        if not (video and ass and os.path.exists(ass)):
            messagebox.showinfo("Convert first", "Convert the video first, then make the clean copy.")
            return
        out = os.path.splitext(video)[0] + ".PassiveSubs.mkv"
        if not messagebox.askyesno("Make a clean copy?",
                                   "This makes a new video file:\n%s\n\nIt has the same picture and sound, but the "
                                   "subtitle tracks built into the video are left out and your PassiveSubs subtitles "
                                   "are its only track, switched on. It takes about a minute and uses as much disk "
                                   "space as the video. Your original video is not changed; delete it yourself "
                                   "afterwards if you like." % os.path.basename(out)):
            return
        self.clean_btn.config(state="disabled")
        self.write_log("Making a clean copy of %s..." % os.path.basename(video))

        def work():
            from passive_subs.subtitles import make_clean_copy
            try:
                self.q.put(("log", "  Saved %s (only subtitle track: PassiveSubs)" % make_clean_copy(video, ass, out)))
                self.q.put(("cleaned", out))
            except Exception as e:
                self.q.put(("log", "  Clean copy FAILED: %s" % e))
                self.q.put(("cleaned", None))
        threading.Thread(target=work, daemon=True).start()

    def _find_vlc(self):
        vlc = None
        for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                     os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
            cand = os.path.join(base, "VideoLAN", "VLC", "vlc.exe")
            if os.path.exists(cand):
                vlc = cand
                break
        return vlc or shutil.which("vlc")

    def play(self, video, subs=None):
        vlc = self._find_vlc()
        if not vlc:
            messagebox.showinfo("VLC not found", "Install VLC (videolan.org), or open this in your player:\n" + video)
            return
        args = [vlc, "--no-sub-autodetect-file"] + (["--sub-file=" + subs] if subs else []) + [video]
        subprocess.Popen(args)

    def preview(self):
        """Open the video with the new subtitles in VLC."""
        vlc = self._find_vlc()
        if not vlc:
            messagebox.showinfo("VLC not found", "Install VLC (videolan.org) to preview, or open the video "
                                                 "in your player and add the subtitle file:\n" + str(self.last_output))
            return
        if not self.last_video:
            messagebox.showinfo("No video", "Put the video in the VIDEO box to preview it.")
            return
        # only this file: don't let VLC also pick up older .ass files next to the video
        self.play(self.last_video, self.last_output)

    def write_log(self, msg):
        self.log.config(state="normal")
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        self.log.config(state="disabled")

    def settings(self):
        d = {"script": self.script.get(), "effect": self.effect_names.get(self.effect.get(), "appear"),
             "wo": self.wo.get(), "intro": self.intro.get(), "preset": self.preset.get(),
             "name_style": {v: k for k, v in self.name_styles.items()}.get(self.name_style.get(), "name"),
             "use_ai": self.use_ai.get(), "api_key": self.api_key.get().strip(),
             "auto_align": self.auto_align.get(), "ruby": self.ruby.get()}
        try:
            shift = float(self.shift.get())
        except Exception:
            shift = 0.0
        try:
            save_settings(d)
        except Exception:
            pass
        return Settings(script=d["script"], effect=d["effect"], wo=d["wo"], intro=d["intro"],
                        names={}, preset=d["preset"], name_style=d["name_style"], use_ai=d["use_ai"], api_key=d["api_key"],
                        show_context=self.context.get().strip(), auto_align=d["auto_align"], shift_s=shift,
                        known=self.save_known(), ruby=d["ruby"])

    def start(self):
        if not self.video and not self.subtitle:
            messagebox.showinfo("Nothing to convert", "Drop the video (and, if it has no Japanese subtitles "
                                                      "inside, a Japanese .ass/.srt file) into the boxes first.")
            return
        st = self.settings()
        if st.use_ai and not st.api_key:
            messagebox.showwarning("API key needed", "Paste an Anthropic API key, or untick the Claude AI option.")
            return
        self.btn.config(state="disabled")
        self.prog["value"] = 0
        self.last_video = self.video
        threading.Thread(target=self.work, args=([(self.video, self.subtitle)], st), daemon=True).start()

    def choose_stream(self, streams):
        """Called from the worker thread when no track is tagged Japanese."""
        ev, box = threading.Event(), {}

        def ask():
            opts = "\n".join("%d: %s %s %s" % (i, s["lang"] or "?", s["codec"], s["title"]) for i, s in enumerate(streams))
            from tkinter import simpledialog
            r = simpledialog.askinteger("Which subtitle track is Japanese?", opts, parent=self.root,
                                        minvalue=0, maxvalue=len(streams) - 1)
            box["s"] = streams[r] if r is not None else None
            ev.set()
        self.root.after(0, ask)
        ev.wait()
        return box.get("s")

    def work(self, files, st):
        log = lambda m: self.q.put(("log", m))
        ok = 0
        try:
            log("Loading dictionary...")
            glossary()
        except Exception as e:
            log("Could not load the dictionary: %s" % e)
        for i, (video, sub) in enumerate(files):
            try:
                out = convert(video, st, subtitle=sub, log=log, choose_stream=self.choose_stream,
                              progress=lambda p, i=i: self.q.put(("prog", (i + p) / len(files))))
                self.q.put(("done", out))
                ok += 1
            except Exception as e:
                log("  FAILED: %s" % e)
        self.q.put(("finish", (ok, len(files))))

    def poll(self):
        try:
            while True:
                kind, v = self.q.get_nowait()
                if kind == "log":
                    self.write_log(v)
                elif kind == "prog":
                    self.prog["value"] = v
                elif kind == "done":
                    self.last_output = v
                    self.open_btn.config(state="normal")
                    self.vlc_btn.config(state="normal" if self.last_video else "disabled")
                    self.clean_btn.config(state="normal" if self.last_video else "disabled")
                elif kind == "keymsg":
                    self.key_msg_l.config(fg="#1d5c2e" if not v else "#b03a2e")
                    self.key_msg.set("The API key works." if not v else v)
                elif kind == "cleaned":
                    self.clean_btn.config(state="normal")
                    if v and messagebox.askyesno(
                            "Clean copy ready", "Made " + os.path.basename(v) + "\n\nThat's the file to watch: its only "
                            "subtitles are the PassiveSubs ones. (The original video still has its other languages.)"
                            "\n\nPlay it in VLC now?"):
                        self.play(v)
                elif kind == "finish":
                    ok, n = v
                    self.btn.config(state="normal")
                    self.prog["value"] = 1.0
                    self.write_log("Finished: %d of %d converted. Click 'Preview in VLC', or load the .ass file "
                                   "in your player (VLC: Subtitle > Add Subtitle File)." % (ok, n))
                    if ok:
                        self.refresh_words()
                    if LAST_AI_ERROR:
                        self.key_msg_l.config(fg="#b03a2e")
                        self.key_msg.set(LAST_AI_ERROR[0] + " This conversion used the offline dictionary.")
                    if ok and LAST_WARNINGS:
                        messagebox.showwarning("Subtitles may not match the video", "\n\n".join(LAST_WARNINGS) +
                                               "\n\nThe .ass file was still saved. Preview it in VLC to check.")
                    elif ok and LAST_REPORT:
                        messagebox.showinfo("Subtitles finished", "\n\n".join(LAST_REPORT) +
                                            "\n\nPreview it in VLC. If it's still a little early or late, set "
                                            "'Then shift by' and click Convert again.")
        except queue.Empty:
            pass
        self.root.after(100, self.poll)


def main():
    if len(sys.argv) > 1 and sys.argv[1] != "--gui":
        from passive_subs.convert import main as cli
        return cli(sys.argv[1:])
    root = TkinterDnD.Tk() if DND else tk.Tk()
    try:
        ttk.Style().theme_use("vista" if os.name == "nt" else "clam")
    except Exception:
        pass
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
