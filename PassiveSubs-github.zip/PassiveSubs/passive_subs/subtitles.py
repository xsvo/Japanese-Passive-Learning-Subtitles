"""Reading subtitles: from .ass/.ssa/.srt/.vtt files, or extracted from a video with ffmpeg."""
import os
import re
import shutil
import subprocess
import tempfile

import pysubs2

from .kana import has_japanese

# text formats (read directly, or converted by ffmpeg) plus picture formats (.sup Blu-ray, .idx/.sub DVD)
TEXT_SUB_EXTS = {".ass", ".ssa", ".srt", ".vtt", ".webvtt", ".smi", ".sami", ".ttml", ".dfxp", ".xml", ".sbv",
                 ".lrc", ".sub", ".txt", ".mpl", ".json", ".aqt", ".jss", ".js", ".pjs", ".rt", ".stl", ".scc",
                 ".vpl", ".usf"}
PICTURE_SUB_EXTS = {".sup", ".idx"}
SUB_EXTS = TEXT_SUB_EXTS | PICTURE_SUB_EXTS
TEXT_CODECS = {"ass", "ssa", "subrip", "srt", "mov_text", "webvtt", "text"}
IMAGE_CODECS = {"hdmv_pgs_subtitle", "dvd_subtitle", "dvb_subtitle", "xsub", "pgssub", "vobsub"}


class SubtitleError(Exception):
    pass


def ffmpeg_exe():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        exe = shutil.which("ffmpeg")
        if exe:
            return exe
    raise SubtitleError("ffmpeg was not found. Run Start.bat again to install it, or install ffmpeg.")


def _run(args):
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
    return subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace", **kw)


def video_duration_ms(video):
    """Length of the video in ms, read from ffmpeg's header info (None if unknown)."""
    r = _run([ffmpeg_exe(), "-hide_banner", "-i", video])
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr or "")
    if not m:
        return None
    h, mi, sec = m.groups()
    return int((int(h) * 3600 + int(mi) * 60 + float(sec)) * 1000)


def make_clean_copy(video, ass=None, out=None):
    """Copy the video without its built-in subtitle tracks, adding the PassiveSubs .ass as its only
    (default) subtitle track. The picture and sound are copied as they are (no re-encoding), so it's
    quick. Always written as .mkv, the only common format that keeps karaoke subtitle styling.
    The original video is not changed. Returns the new file's path."""
    base = os.path.splitext(video)[0]
    out = out or base + ".PassiveSubs.mkv"
    if os.path.abspath(out) == os.path.abspath(video):
        raise SubtitleError("The clean copy would overwrite the video itself.")
    args = [ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y", "-i", video]
    if ass:
        args += ["-i", ass]
    args += ["-map", "0:v", "-map", "0:a?", "-map", "0:t?"]   # keep picture, all audio, embedded fonts
    if ass:
        args += ["-map", "1:0", "-metadata:s:s:0", "language=jpn", "-metadata:s:s:0", "title=PassiveSubs",
                 "-disposition:s:0", "default"]
    args += ["-c", "copy", out]
    r = _run(args)
    if r.returncode != 0 or not os.path.exists(out):
        raise SubtitleError("ffmpeg couldn't make the copy: " + (r.stderr or "")[-400:])
    return out


def list_subtitle_streams(video):
    """Returns [{index, lang, codec, title, default}] for every subtitle stream in the video."""
    r = _run([ffmpeg_exe(), "-hide_banner", "-i", video])
    streams = []
    cur = None
    for line in r.stderr.splitlines():
        m = re.match(r"\s*Stream #0:(\d+)(?:\[0x[0-9a-f]+\])?(?:\((\w+)\))?: Subtitle: (\w+)(.*)", line)
        if m:
            cur = {"index": int(m.group(1)), "lang": (m.group(2) or "").lower(), "codec": m.group(3),
                   "title": "", "default": "(default)" in m.group(4)}
            streams.append(cur)
            continue
        if re.match(r"\s*Stream #", line):
            cur = None
            continue
        if cur is not None:
            t = re.match(r"\s+title\s*:\s*(.*)", line)
            if t:
                cur["title"] = t.group(1).strip()
    return streams


def _looks_japanese(st):
    t = st["title"].lower()
    return st["lang"] in ("jpn", "ja", "jp") or "japanese" in t or "日本" in t or "jpn" in t


LANG_NAMES = {"eng": "English", "ara": "Arabic", "fra": "French", "fre": "French", "deu": "German",
              "ger": "German", "ita": "Italian", "por": "Portuguese", "rus": "Russian", "spa": "Spanish",
              "chi": "Chinese", "zho": "Chinese", "kor": "Korean", "ind": "Indonesian", "tha": "Thai",
              "vie": "Vietnamese", "msa": "Malay", "may": "Malay", "pol": "Polish", "tur": "Turkish",
              "hin": "Hindi"}


def pick_japanese_stream(streams):
    text = [s for s in streams if s["codec"] in TEXT_CODECS or s["codec"] not in IMAGE_CODECS]
    jp = [s for s in text if _looks_japanese(s)]
    if not jp:   # Blu-ray picture subtitles in Japanese: read into text by ocr.py
        jp = [s for s in streams if s["codec"] in ("hdmv_pgs_subtitle", "pgssub", "dvd_subtitle") and _looks_japanese(s)]
    if jp:
        # prefer full dialogue tracks over "signs/songs" tracks
        jp.sort(key=lambda s: (any(k in s["title"].lower() for k in ("sign", "song", "forced")), not s["default"]))
        return jp[0]
    untagged = [s for s in text if s["lang"] in ("", "und")]
    if len(untagged) == 1:
        return untagged[0]
    return None


def extract_stream(video, stream, out_dir=None):
    if stream["codec"] in IMAGE_CODECS:
        raise SubtitleError(
            "The Japanese subtitles in this video are pictures (%s), not text, so they can't be read. "
            "Find a text .srt/.ass Japanese subtitle file for it instead." % stream["codec"])
    out_dir = out_dir or tempfile.mkdtemp(prefix="passivesubs_")
    ext = ".ass" if stream["codec"] in ("ass", "ssa") else ".srt"
    out = os.path.join(out_dir, "track%d%s" % (stream["index"], ext))
    r = _run([ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y", "-i", video,
              "-map", "0:%d" % stream["index"], "-c:s", "ass" if ext == ".ass" else "srt", out])
    if r.returncode != 0 or not os.path.exists(out):
        raise SubtitleError("ffmpeg could not extract the subtitles:\n" + r.stderr[-800:])
    return out


def find_sidecar(video):
    """A Japanese subtitle file sitting next to the video (Movie.ja.srt, Movie.jpn.ass, Movie.srt)."""
    base, _ = os.path.splitext(video)
    folder = os.path.dirname(video) or "."
    stem = os.path.basename(base)
    cands = []
    for fn in os.listdir(folder):
        b, e = os.path.splitext(fn)
        if e.lower() in (".srt", ".ass", ".ssa", ".vtt", ".smi", ".ttml", ".dfxp", ".sbv", ".lrc") and b.startswith(stem) and ".passive" not in b.lower():
            tag = b[len(stem):].lower()
            score = 2 if re.search(r"(ja|jp|jpn|japanese)", tag) else (1 if tag == "" else 0)
            cands.append((score, os.path.join(folder, fn)))
    cands.sort(reverse=True)
    for score, path in cands:
        if score > 0:
            return path
    return None


_OPEN, _CLOSE = "（(［[〈【", "）)］]〉】"
_KANA = r"[\u3041-\u3096\u30a1-\u30faー・]"
_KANJI_WORD = r"[\u3400-\u9fff々ヶ]+"
FURIGANA_RE = re.compile("((?:(?<![\u3400-\u9fff々ヶ])[\u3400-\u9fff々ヶ]{1,4}[ \u3000])?%s)[（(](%s+)[）)]([\u3041-\u3096]{0,2})"
                         % (_KANJI_WORD, _KANA))   # 鈴木 一郎(すずきいちろう): a full name split by a space


def find_furigana(t: str):
    """'春香(はるか)' -> [('春香', 'はるか')]: readings the subtitle author wrote for names."""
    return [(w, r + ("|" + after if after else "")) for w, r, after in FURIGANA_RE.findall(re.sub(r"\{[^}]*\}", "", t))]


SOUND_RE = re.compile(r"(音|声|込み|息|ぼえ|吠え|さえずり|ため息|拍手|足音|悲鳴|BGM|♪|ざわめき|どよめき|うめき|ベル|チャイム"
                      r"|ブザー|アラーム|サイレン|着信|物音)$")
# styles that are never dialogue: ruby/furigana layers (注音), staff credits, fansub logos
SKIP_STYLE_RE = re.compile(r"注音|ルビ|ruby|furigana|staff|credit|logo|スタッフ", re.I)
_CJK = re.compile(r"[\u4e00-\u9fff]")


def is_chinese_line(t: str) -> bool:
    """Fansub credit lines in Chinese (本字幕由…字幕组制作): kanji Japanese text can't use."""
    odd = 0
    for ch in _CJK.findall(t):
        try:
            ch.encode("cp932")
        except UnicodeEncodeError:
            odd += 1
    return odd >= 3 or (odd >= 2 and not re.search(r"[\u3041-\u3096]", t))


def _clean_piece(p: str) -> str:
    # a whole line that only describes a sound: （ドアが閉まる音） （犬の鳴き声） -> dropped
    m = re.fullmatch(r"\s*[（(]([^（）()]{1,25})[）)]\s*", p)
    if m and SOUND_RE.search(m.group(1)):
        return ""
    # stretched words: みた～い -> みたい, ち～っと -> ちっと (so the word is recognised)
    p = re.sub(r"(?<=[\u3041-\u3096])[～〜~]+(?=[\u3041-\u3096])", "", p)
    p = re.sub(r"(?<=[\u30a1-\u30fa])[～〜]+(?=[\u30a1-\u30fa])", "", p)     # ダ〜メ -> ダメ
    # furigana after kanji: 春香(はるか) -> 春香
    p = re.sub("(?<=[\u3400-\u9fff々ヶ])[（(]%s+[）)]" % _KANA, "", p)
    # speaker label at the start of a line: （春香）聞いてくれ -> 聞いてくれ
    p = re.sub(r"^\s*[（(［\[〈【][^（）()［］\[\]〈〉【】]{1,15}[）)］\]〉】]\s*(?=\S)", "", p)
    # a piece that is only a short bracketed name or sound with no hiragana: （春香） / （爆発音）
    if re.fullmatch(r"\s*[（(［\[〈【][^\u3041-\u3096（）()［］\[\]〈〉【】]{1,15}[）)］\]〉】]\s*", p):
        return ""
    # mid-line names / sound effects (no hiragana): 聞いて（爆発音）くれ -> 聞いてくれ
    p = re.sub(r"[（(［\[〈【][^\u3041-\u3096（）()［］\[\]〈〉【】]{1,15}[）)］\]〉】]", "", p)
    # any other bracket pair: keep what's inside (thoughts, whispers), drop the brackets
    p = re.sub(r"[（(［\[〈【]([^（）()［］\[\]〈〉【】]*)[）)］\]〉】]", r"\1", p)
    # unmatched leftovers
    p = re.sub(r"[（）()［］\[\]〈〉【】]", "", p)
    return p.strip()


_LABEL_RE = re.compile(r"^\s*[（(［\[〈【]([^（）()［］\[\]〈〉【】、。！？!?…\s]{1,8})[）)］\]〉】]")


def _label_of(p, alone=False):
    m = _LABEL_RE.match(p)
    if not m or (alone and p[m.end():].strip()):
        return None
    return m.group(1)


def find_labels(texts):
    """Bracketed names used two or more times at the start of a line: the file's speaker labels."""
    count = {}
    for t in texts:
        for p in re.split(r"\\N|\\n|\n", re.sub(r"\{[^}]*\}|[\u202a-\u202e\u2066-\u2069]", "", t)):
            k = _label_of(p)
            if k:
                count[k] = count.get(k, 0) + 1
    return {k for k, n in count.items() if n >= 2 and not SOUND_RE.search(k)}


def clean_text(t: str, labels=None) -> str:
    t = re.sub(r"\{[^}]*\}", "", t)               # ASS override tags
    t = re.sub(r"<[^>]+>", "", t)                  # html-ish tags in srt/vtt
    t = re.sub(r"[\u2066-\u2069\u200b\u200e\u200f\u202a-\u202e\ufeff]", "", t)   # invisible direction marks
    t = t.replace("\uff65", "・")                    # half-width ･ in names: エル･プサイ -> エル・プサイ
    pieces = [p.replace("\\h", " ") for p in re.split(r"\\N|\\n|\n", t)]   # each line may have its own label
    if len(pieces) > 1 and labels:
        # a piece that is only a speaker label: （はるか）\Nタイトルは -> タイトルは
        pieces = [p for p in pieces if _label_of(p, alone=True) not in labels]
    t = " ".join(_clean_piece(p) for p in pieces)
    t = re.sub(r"\s+", " ", t)
    return t.strip()


SONG_RE = re.compile(r"(^|[^a-z])(op|ed)([^a-z]|$)|song|lyric|kara|insert|theme|opening|ending|歌|主題", re.I)


def is_passivesubs_file(path):
    """True for a karaoke .ass this app made (its own output must never be used as the input)."""
    if ".passive" in os.path.basename(path).lower() and path.lower().endswith(".ass"):
        return True
    try:
        with open(path, "rb") as f:
            return b"Generated by PassiveSubs" in f.read(600)
    except OSError:
        return False


ENCODINGS = ("utf-8", "utf-16", "cp932", "euc_jp", "gb18030", "big5", "euc_kr", "shift_jis_2004")
_KANA_CH = re.compile(r"[\u3041-\u3096\u30a1-\u30fa]")
_CJK = re.compile(r"[\u4e00-\u9fff]")
_ODD = re.compile(r"[^\x00-\x7f\u3000-\u300f\u3012-\u30ff\u4e00-\u9fff\uff00-\uffef\u2010-\u2026\u2190-\u2193\u25a0-\u25cf\u2605\u2606\u266a\u266b\u2661\u2665\u00a0\u00d7]")


def read_text(path):
    """A subtitle file's text, whatever encoding it was saved in (Japanese, Chinese and Korean fansub
    files use many). Every candidate that decodes cleanly is scored by how Japanese the result looks."""
    with open(path, "rb") as f:
        raw = f.read()
    for bom, enc in ((b"\xef\xbb\xbf", "utf-8-sig"), (b"\xff\xfe", "utf-16"), (b"\xfe\xff", "utf-16")):
        if raw.startswith(bom):
            try:
                return raw.decode(enc), enc
            except UnicodeDecodeError:
                pass
    cands = list(ENCODINGS)
    if raw[:200].count(b"\x00") > 20:   # UTF-16 without a byte-order mark
        cands = ["utf-16-le", "utf-16-be"] + cands
    best = None
    for enc in cands:
        try:
            t = raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
        if "\x00" in t:
            continue
        odd = len(_ODD.findall(t))    # symbols a wrong guess produces: ∈ ∷ 〖 and accented Latin
        score = 3 * len(_KANA_CH.findall(t)) + len(_CJK.findall(t)) - 5 * odd - 50 * t.count("\ufffd")
        if enc == "utf-8":
            score += 1   # tie-break: plain ASCII files
        if best is None or score > best[0]:
            best = (score, t, enc)
    if best is None:
        raise SubtitleError(
            "Couldn't read the text of %s: it isn't saved in any text encoding the app knows. Try opening it in "
            "Notepad and saving it again with Encoding: UTF-8." % os.path.basename(path))
    return best[1], best[2]


def _ts(t):
    """'1:02:03.45', '02:03,450', '123.4' -> ms"""
    parts = re.split(r"[:]", t.strip().replace(",", "."))
    sec = 0.0
    for p in parts:
        sec = sec * 60 + float(p or 0)
    return int(round(sec * 1000))


def _parse_sbv(text):
    """YouTube .sbv: '0:00:01.000,0:00:03.500' then the text, blank line between."""
    subs = pysubs2.SSAFile()
    for block in re.split(r"\n\s*\n", text.replace("\r", "")):
        lines = block.strip().split("\n")
        m = re.match(r"^\s*([\d:.]+)\s*,\s*([\d:.]+)\s*$", lines[0]) if lines else None
        if m and len(lines) > 1:
            subs.append(pysubs2.SSAEvent(start=_ts(m.group(1)), end=_ts(m.group(2)), text="\\N".join(lines[1:])))
    return subs


def _parse_lrc(text):
    """Lyrics .lrc: '[mm:ss.xx]text'. A line lasts until the next one (at most 6 s)."""
    items = []
    for line in text.replace("\r", "").split("\n"):
        tags = re.findall(r"\[(\d+:\d+(?:[.:]\d+)?)\]", line)
        words = re.sub(r"\[[^\]]*\]|<\d+:\d+(?:[.:]\d+)?>", "", line).strip()
        for t in tags:
            mm, rest = t.split(":", 1)
            items.append((int(mm) * 60000 + int(round(float(rest.replace(":", ".")) * 1000)), words))
    items.sort()
    subs = pysubs2.SSAFile()
    for i, (t, w) in enumerate(items):
        nxt = items[i + 1][0] if i + 1 < len(items) else t + 4000
        if w:
            subs.append(pysubs2.SSAEvent(start=t, end=min(nxt, t + 6000), text=w))
    return subs


def _via_ffmpeg(path, text):
    """Formats only ffmpeg knows (SubViewer, AQTitle, JACOsub, PJS, RealText, Spruce STL, SCC, VPlayer,
    MPlayer...): convert to .ass with ffmpeg, from a UTF-8 copy so the encoding is already sorted out."""
    d = tempfile.mkdtemp(prefix="passivesubs_")
    src = os.path.join(d, "in" + os.path.splitext(path)[1].lower())
    with open(src, "w", encoding="utf-8") as f:
        f.write(text)
    out = os.path.join(d, "out.ass")
    r = _run([ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y", "-sub_charenc", "UTF-8", "-i", src, out])
    if r.returncode != 0 or not os.path.exists(out):
        raise SubtitleError((r.stderr or "ffmpeg couldn't read it").strip()[-200:])
    return pysubs2.load(out, encoding="utf-8")


def parse_subtitle_file(path, fps=23.976):
    """Any text subtitle file -> pysubs2.SSAFile, whatever its format and encoding."""
    text, _enc = read_text(path)
    ext = os.path.splitext(path)[1].lower()
    head = text.lstrip()[:400].lower()
    attempts = []
    if ext == ".sbv" or re.match(r"^\d+:\d\d:\d\d\.\d+,\d+:\d\d:\d\d\.\d+\s*\n", text.lstrip()):
        attempts.append(lambda: _parse_sbv(text))
    if ext == ".lrc" or re.match(r"^(\[[a-z]+:[^\]]*\]\s*)*\[\d+:\d+[.:]\d+\]", head):
        attempts.append(lambda: _parse_lrc(text))
    if ext in (".ttml", ".dfxp", ".xml") or "<tt" in head:
        attempts.append(lambda: pysubs2.SSAFile.from_string(text, format_="ttml"))
    if ext in (".smi", ".sami") or "<sami" in head:
        attempts.append(lambda: pysubs2.SSAFile.from_string(text, format_="sami"))
    attempts.append(lambda: pysubs2.SSAFile.from_string(text, fps=fps))     # autodetect: ass/srt/vtt/microdvd/...
    attempts.append(lambda: _via_ffmpeg(path, text))
    errors = []
    for attempt in attempts:
        try:
            subs = attempt()
            if any(not e.is_comment and e.text.strip() for e in subs):
                return subs
        except Exception as e:
            errors.append(str(e)[:120])
    raise SubtitleError("Couldn't read %s as a subtitle file. The app reads .ass .ssa .srt .vtt .smi .ttml .dfxp "
                        ".sbv .lrc .sub and more; this one may be damaged or in a rare format. (%s)"
                        % (os.path.basename(path), errors[-1] if errors else "no subtitles found"))


def load_lines(path, song_flags=None, furigana=None):
    """Returns [(start_ms, end_ms, text)] for every Japanese dialogue line, sorted by time.

    If song_flags is a list, it is filled (in the same order) with True for opening/ending/insert
    song lyrics, detected from the line's style/actor name or a ♪."""
    if is_passivesubs_file(path):
        raise SubtitleError(
            "%s is a file PassiveSubs made (already converted karaoke subtitles), not Japanese subtitles. "
            "Drop the original Japanese .ass/.srt in the JAPANESE SUBTITLES box instead."
            % os.path.basename(path))
    subs = parse_subtitle_file(path)
    lines = []
    seen = set()
    labels = find_labels(ev.text for ev in subs if not ev.is_comment)
    for ev in subs:
        if ev.is_comment or SKIP_STYLE_RE.search(ev.style or ""):
            continue
        if furigana is not None:
            for word, reading in find_furigana(ev.text):
                furigana.setdefault(word, reading)
        txt = clean_text(ev.text, labels)
        if not txt or not has_japanese(txt) or is_chinese_line(txt):
            continue
        key = (ev.start, ev.end, txt)
        if key in seen:
            continue
        seen.add(key)
        song = bool(SONG_RE.search(ev.style or "") or SONG_RE.search(ev.name or "") or "♪" in ev.text)
        lines.append((ev.start, ev.end, txt, song))
    lines.sort()
    # The same line split into back-to-back pieces (done where speakers overlap) becomes one line:
    # otherwise each piece restarts the karaoke and they flicker on top of each other.
    merged, last = [], {}
    for st, en, txt, song in lines:
        k = last.get(txt)
        if k is not None and merged[k][1] >= st - 150:
            merged[k] = (merged[k][0], max(merged[k][1], en), txt, merged[k][3])
            continue
        last[txt] = len(merged)
        merged.append((st, en, txt, song))
    lines = merged
    if song_flags is not None:
        song_flags[:] = [l[3] for l in lines]
    lines = [l[:3] for l in lines]
    if not lines:
        raise SubtitleError("No Japanese text found in %s. Drop a Japanese .ass/.srt file into the Japanese subtitles box." % os.path.basename(path))
    return lines


def get_japanese_subtitles(path, choose_stream=None):
    """Accepts a subtitle file or a video. Returns (subtitle_path, description).

    choose_stream(streams) -> stream may be given to let the user pick when it's ambiguous."""
    ext = os.path.splitext(path)[1].lower()
    if ext in SUB_EXTS:
        return path, "subtitle file"
    side = find_sidecar(path)
    if side:
        return side, "subtitle file next to the video (%s)" % os.path.basename(side)
    streams = [x for x in list_subtitle_streams(path) if x.get("title") != "PassiveSubs"]  # our own track
    if not streams:
        raise SubtitleError("This video has no Japanese subtitle tracks inside it (a PassiveSubs track doesn't count). Drop a Japanese .ass/.srt file into the Japanese subtitles box.")
    st = pick_japanese_stream(streams)
    tagged = [x for x in streams if x["lang"] not in ("", "und")]
    if st is None and streams and len(tagged) == len(streams):
        langs = ", ".join(sorted({LANG_NAMES.get(x["lang"], x["lang"]) for x in streams}))
        raise SubtitleError(
            "This video has subtitles in %s, but not in Japanese. Download a Japanese .srt/.ass for this "
            "episode and drop it in the JAPANESE "
            "SUBTITLES box. The app lines it up with the video for you." % langs)
    if st is None:
        # no language tags: try each text track and keep the first one with Japanese in it
        for cand in streams:
            if cand["codec"] in IMAGE_CODECS:
                continue
            try:
                p = extract_stream(path, cand)
                load_lines(p)
                return p, "track #%d (detected Japanese text)" % cand["index"]
            except SubtitleError:
                continue
        if choose_stream:
            st = choose_stream(streams)
    if st is None:
        st = streams[0]
    if st["codec"] == "dvd_subtitle":
        # DVD picture subtitles: copy them out as a DVD stream (.sub) plus their colours (.idx)
        d = tempfile.mkdtemp(prefix="passivesubs_")
        out = os.path.join(d, "track%d.sub" % st["index"])
        r = _run([ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y", "-i", path,
                  "-map", "0:%d" % st["index"], "-c:s", "copy", "-f", "vob", out])
        if r.returncode != 0 or not os.path.exists(out):
            raise SubtitleError("Couldn't copy the DVD subtitles out of the video: " + (r.stderr or "")[-300:])
        mk = os.path.join(d, "pal.mkv")      # the colour palette travels in the track's header
        _run([ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y", "-i", path,
              "-map", "0:%d" % st["index"], "-c:s", "copy", "-t", "1", mk])
        try:
            with open(mk, "rb") as f:
                m = re.search(rb"palette:[ 0-9a-fA-F,]+", f.read(200000))
            if m:
                with open(os.path.splitext(out)[0] + ".idx", "w", encoding="ascii") as f:
                    f.write(m.group(0).decode("ascii") + "\n")
        except OSError:
            pass
        return out, "track #%d (%s, DVD picture subtitles)" % (st["index"], st["lang"] or "no language tag")
    if st["codec"] in ("hdmv_pgs_subtitle", "pgssub"):
        # Blu-ray picture subtitles: copy them out as a .sup; convert() has them read into text
        out = os.path.join(tempfile.mkdtemp(prefix="passivesubs_"), "track%d.sup" % st["index"])
        r = _run([ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y", "-i", path,
                  "-map", "0:%d" % st["index"], "-c:s", "copy", out])
        if r.returncode != 0 or not os.path.exists(out):
            raise SubtitleError("Couldn't copy the picture subtitles out of the video: " + (r.stderr or "")[-300:])
        return out, "track #%d (%s, picture subtitles)" % (st["index"], st["lang"] or "no language tag")
    sub = extract_stream(path, st)
    desc = "track #%d (%s%s)" % (st["index"], st["lang"] or "no language tag", ", " + st["title"] if st["title"] else "")
    return sub, desc
