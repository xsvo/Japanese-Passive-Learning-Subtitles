"""Optional: ask Claude for context-aware glosses (better than first-dictionary-sense).

Needs an Anthropic API key (https://console.anthropic.com). Without one the app uses the
offline dictionary only. Any error here falls back to the dictionary glosses.
"""
import json
import re
from concurrent.futures import ThreadPoolExecutor

MODEL = "claude-opus-5-5"
BATCH = 40

SYSTEM = """You help make "passive learning" Japanese subtitles. Each subtitle keeps Japanese word order; \
meaning-carrying words are replaced by a short UPPERCASE English gloss while grammar stays in romaji.

For each listed word you get its id, the Japanese word as written, and a first-guess dictionary gloss. \
Return the best gloss FOR THIS SENTENCE'S CONTEXT:
- 1 to 3 English words, UPPERCASE, joined with hyphens (e.g. GET-SERIOUS, PET-BOTTLE, OLDER-SISTER).
- Translate only the word itself, not the surrounding grammar. Verbs: plain verb (DECIDE, not DECIDED).
- Character / place names: romanized name in UPPERCASE (HARUKA, KAEDE), no translation.
- If the tokenizer split ONE word or name into several listed pieces (e.g. 春 + 香 = the name Haruka), \
give the whole gloss on the FIRST piece and an empty string "" for the following pieces.
- If the dictionary gloss is already right, return it unchanged.
Return every id exactly once."""

REVIEW_SYSTEM = """You are proofreading "passive learning" Japanese subtitles before they are saved. \
Each subtitle keeps Japanese word order; meaning-carrying words are UPPERCASE English glosses, grammar stays \
lowercase romaji. This is intended to read oddly: never reorder, never translate the grammar, never smooth it.

For each sentence you get the Japanese line, the lines before and after it for context, and the current \
glosses as id=GLOSS(japanese). Check every gloss against the whole sentence and the neighbouring lines:
- wrong sense for this context (e.g. 想い as THINKING where it means FEELINGS)
- a word the tokenizer glued or split wrongly (e.g. 5年越し glossed NEW-YEAR'S-EVE: it is 5-YEAR THROUGHOUT)
- a character or place name translated literally (春香 as SPRING-FRAGRANCE: it is HARUKA)
Return ONLY the glosses that are wrong, with the corrected gloss (1 to 3 UPPERCASE English words joined \
with hyphens, or "" if this piece belongs to the previous piece's word) and a 2-6 word reason. \
If everything is right, return an empty list. Do not change glosses that are acceptable."""

REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "fixes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"id": {"type": "string"}, "gloss": {"type": "string"},
                               "reason": {"type": "string"}},
                "required": ["id", "gloss", "reason"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["fixes"],
    "additionalProperties": False,
}

GLOSS_OK = re.compile(r"^[A-Z0-9][A-Z0-9'.&-]*$")


def clean_gloss(g):
    """Force the house style on a gloss: UPPERCASE, words joined with hyphens, no stray punctuation."""
    g = (g or "").strip().upper()
    g = re.sub(r"\([^)]*\)", "", g)
    g = re.sub(r"^(TO|THE|A|AN) ", "", g)
    g = re.sub(r"[\s_/]+", "-", g)
    g = re.sub(r"[^A-Z0-9'&.-]", "", g)
    g = re.sub(r"-{2,}", "-", g).strip("-.")
    return g


def check_format(analyzed):
    """Local check of every line (free, no AI): glosses are UPPERCASE English joined with hyphens, with
    nothing Japanese or stray punctuation in them. Word order and grammar are never touched.
    Returns the number of fixes."""
    fixed = 0
    for _jp, syls in analyzed:
        for s in syls:
            if s.core and not GLOSS_OK.match(s.core):
                new = clean_gloss(s.core)
                if new and new != s.core:
                    s.text = s.text.replace(s.core, new, 1)
                    s.core = new
                    fixed += 1
    return fixed


SCHEMA = {
    "type": "object",
    "properties": {
        "glosses": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"id": {"type": "string"}, "gloss": {"type": "string"}},
                "required": ["id", "gloss"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["glosses"],
    "additionalProperties": False,
}


class AIGlosser:
    def __init__(self, api_key, log=print, show_context=""):
        import anthropic  # imported lazily so the app works without it
        self.anthropic = anthropic
        self.client = anthropic.Anthropic(api_key=api_key or None)
        self.log = log
        self.show_context = show_context

    def _call(self, system, schema, prompt, max_tokens=16000):
        resp = self.client.beta.messages.create(
            model=MODEL,
            max_tokens=max_tokens,
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            system=system,
            output_config={"effort": "low", "format": {"type": "json_schema", "schema": schema}},
            messages=[{"role": "user", "content": prompt}],
        )
        if resp.stop_reason == "refusal":
            raise RuntimeError("Claude declined this batch")
        return json.loads(next(b.text for b in resp.content if b.type == "text"))

    def _review(self, items):
        lines = []
        for li in items:
            words = ", ".join("%s=%s(%s)" % (wid, g, jp) for wid, jp, g in li["words"])
            lines.append("Sentence %d: %s\n  Before: %s\n  After: %s\n  Glosses: %s"
                         % (li["n"], li["japanese"], li["before"] or "-", li["after"] or "-", words))
        prompt = ("Show / context: %s\n\n" % self.show_context if self.show_context else "") + "\n".join(lines)
        data = self._call(REVIEW_SYSTEM, REVIEW_SCHEMA, prompt, max_tokens=8000)
        return {f["id"]: f["gloss"] for f in data["fixes"]}, {f["id"]: f["reason"] for f in data["fixes"]}

    def _ask(self, items):
        lines = []
        for li in items:
            words = ", ".join('%s="%s" (dict: %s)' % (wid, jp, g) for wid, jp, g in li["words"])
            lines.append("Sentence %d: %s\n  (before: %s | after: %s)\n  Words: %s"
                         % (li["n"], li["japanese"], li["before"] or "-", li["after"] or "-", words))
        prompt = ("Show / context: %s\n\n" % self.show_context if self.show_context else "") + "\n".join(lines)
        return {g["id"]: g["gloss"] for g in self._call(SYSTEM, SCHEMA, prompt)["glosses"]}

    def _items(self, analyzed):
        items = []
        for n, (jp, syls) in enumerate(analyzed):
            words = [("%d.%d" % (n, k), s.jp, s.core) for k, s in enumerate(syls) if s.core]
            if words:
                items.append({"n": n, "japanese": jp, "words": words,
                              "before": analyzed[n - 1][0] if n > 0 else "",
                              "after": analyzed[n + 1][0] if n + 1 < len(analyzed) else ""})
        return items

    def _run_batches(self, fn, items, progress, offset, total):
        batches = [items[i:i + BATCH] for i in range(0, len(items), BATCH)]
        results = []

        def run(b):
            try:
                return fn(b)
            except self.anthropic.AuthenticationError:
                raise
            except Exception as e:  # network, rate limit, parse error: keep what we have
                self.log("  AI batch failed (%s); kept the words it had." % type(e).__name__)
                return None

        done = 0
        with ThreadPoolExecutor(max_workers=4) as ex:
            for r in ex.map(run, batches):
                if r is not None:
                    results.append(r)
                done += 1
                if progress:
                    progress(offset + done / max(len(batches), 1), total)
        return results

    def improve(self, analyzed, progress=None, review=True):
        """analyzed: list of (japanese_text, [Syl]). Edits the Syl objects in place.
        Pass 1 picks a gloss per word in context; pass 2 (review) proofreads every line again and only
        returns what is still wrong, so it costs little. Then a local format check runs."""
        total = 2 if review else 1
        results = {}
        for r in self._run_batches(self._ask, self._items(analyzed), progress, 0, total):
            results.update(r)
        changed = self._apply(analyzed, results)
        self.log("  AI pass 1: chose context meanings, changed %d dictionary words" % len(changed))

        if review:
            self.log("  AI pass 2: double-checking every line against its sentence and neighbours...")
            fixes, reasons = {}, {}
            for f, why in self._run_batches(self._review, self._items(analyzed), progress, 1, total):
                fixes.update(f)
                reasons.update(why)
            changed = self._apply(analyzed, fixes)
            self.log("  Review corrected %d words" % len(changed))
            for gid, jp, old, new in changed[:40]:
                self.log("    %s: %s -> %s (%s)" % (jp, old, new or "(joined to previous)", reasons.get(gid, "")))
            if len(changed) > 40:
                self.log("    ... and %d more" % (len(changed) - 40))


    def _apply(self, analyzed, results):
        """Apply {id: gloss}; returns [(id, japanese, old, new)] for what changed."""
        changed = []
        for n, (jp, syls) in enumerate(analyzed):
            removed = []
            for k, s in enumerate(syls):
                gid = "%d.%d" % (n, k)
                if not s.core or gid not in results:
                    continue
                new = clean_gloss(results[gid]) if results[gid].strip() else ""
                if new == "" and k > 0:
                    removed.append(k)
                    changed.append((gid, s.jp, s.core, ""))
                elif new and new != s.core:
                    changed.append((gid, s.jp, s.core, new))
                    s.text = s.text.replace(s.core, new, 1)
                    s.core = new
            for k in reversed(removed):  # merge split pieces into the previous syllable
                gone = syls.pop(k)
                prev = syls[k - 1]
                prev.moras += gone.moras
                prev.jp += gone.jp
                tail = gone.text.lstrip("-").replace(gone.core, "", 1) if gone.core else ""
                prev.text += tail
                prev.space = gone.space
        return changed
