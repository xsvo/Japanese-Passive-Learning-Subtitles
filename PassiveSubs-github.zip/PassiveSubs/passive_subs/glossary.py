"""English glosses for Japanese words (JMdict-based, offline) plus user overrides."""
import gzip
import json
import os
import re
import unicodedata

from .kana import has_kanji

from .kana import kata_to_hira

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
DICT_PATH = os.path.join(DATA_DIR, "jmdict_gloss.json.gz")
BUILTIN_OVERRIDES = os.path.join(DATA_DIR, "overrides.txt")
BUILTIN_PHRASES = os.path.join(DATA_DIR, "phrases.txt")


def user_glossary_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "PassiveSubs", "my_glossary.txt")


def known_words_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "PassiveSubs", "known_words.txt")


def parse_known(text):
    """'猫 犬、食べる' / one per line -> {'猫', '犬', '食べる'} (lines starting with # are ignored)."""
    words = set()
    for line in (text or "").splitlines():
        line = line.split("#", 1)[0]
        for w in re.split(r"[\s\u3000,、，;；/]+", line):
            w = w.strip("=")
            if w and not w.isascii():
                words.add(w.split("=")[0].strip())
    return words


def load_known_list():
    """Saved known words, in the order they were added (no repeats)."""
    out = []
    for line in load_known_text().splitlines():
        line = line.split("#", 1)[0].strip()
        for w in re.split(r"[\s\u3000,、，;；/]+", line):
            if w and not w.isascii() and w not in out:
                out.append(w)
    return out


def save_known_list(words):
    save_known_text("\n".join(words))


def load_known_text():
    try:
        with open(known_words_path(), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ""


def save_known_text(text):
    p = known_words_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(text.strip() + "\n")


def _load_overrides(path):
    d = {}
    if not os.path.exists(path):
        return d
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            line = line.split("#", 1)[0].strip()
            if "=" not in line:
                continue
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip()
            if k:
                d[k] = v
    return d


def format_gloss(g: str) -> str:
    g = re.sub(r"\([^)]*\)", "", g)
    g = re.sub(r"^(to|the|a|an) ", "", g.strip(), flags=re.I)
    g = re.sub(r";.*$", "", g)
    g = re.sub(r"(?<!\d),.*$", "", g)
    g = unicodedata.normalize("NFKD", g)
    g = "".join(c for c in g if not unicodedata.combining(c))   # Shōwa -> SHOWA
    g = g.strip(" .!?'\"-")
    g = re.sub(r"\s+", "-", g)
    return g.upper()


class Glossary:
    def __init__(self, extra_override_files=()):
        with gzip.open(DICT_PATH, "rt", encoding="utf-8") as f:
            self.d = json.load(f)
        self.builtin = _load_overrides(BUILTIN_OVERRIDES)
        # multi-word phrases the splitter cuts wrongly; keys keep their case-sensitive gloss
        self.phrases = {k: v for k, v in _load_overrides(BUILTIN_PHRASES).items()}
        self.overrides = dict(self.builtin)
        # user words (names, slang, your own preferred glosses) win over everything
        self.user_words = {}
        for p in (user_glossary_path(), *extra_override_files):
            self.user_words.update(_load_overrides(p))
        self.overrides.update(self.user_words)
        self.permanent = dict(self.user_words)
        self.name_meanings = {}

    def set_session_words(self, mapping):
        """Words for this conversion only (names box, show name lists): replaces the previous ones."""
        # a name list entry may carry its meaning: かえで = KAEDE | MAPLE
        self.name_meanings = {k: v.split("|", 1)[1].strip(" -") for k, v in mapping.items() if "|" in v}
        mapping = {k: v.split("|", 1)[0].strip(" -") for k, v in mapping.items()}
        self.user_words = {**self.permanent, **mapping}
        # a name that is also an everyday word (なる NARU, 新 ARATA, 円 MADOKA) is matched only where it
        # stands alone (analyzer), so it must not replace the word's meaning everywhere else
        name = re.compile(r"^(?:[KGSZTDNHBPMYRWFJCV]{0,3}[AIUEO]|N|-)+$")
        clash = {k for k, v in mapping.items() if name.match(v.strip(" -")) and (
            (re.fullmatch(r"[\u3041-\u3096]+", k) and (k in self.d or len(k) <= 2))
            or (re.search(r"[\u3400-\u9fff]", k) and (len(k) == 1 or k in self.d)))}
        self.overrides = {**self.builtin, **{k: v for k, v in self.user_words.items() if k not in clash}}

    def add_user_words(self, mapping):
        self.user_words.update(mapping)
        self.overrides.update(mapping)

    def override(self, *keys):
        for k in keys:
            if k and k in self.overrides:
                return self.overrides[k]
        return None

    def kanji(self, ch):
        """(MEANING, reading) for a single kanji from KANJIDIC, or None."""
        e = self.d.get("#" + ch)
        if not e:
            return None
        return format_gloss(e[0][2]), (e[0][1][0] if e[0][1] else "")

    def lookup(self, keys, reading=None):
        """keys: candidate headwords (lemma, base form, surface). reading: kana reading."""
        for k in keys:
            if k and k in self.overrides:
                return self.overrides[k]
        rh = kata_to_hira(reading) if reading else None
        for k in keys:
            if not k:
                continue
            ents = self.d.get(k)
            if not ents:
                continue
            if rh:
                for score, readings, gloss, _flags in ents:
                    if rh in [kata_to_hira(r) for r in readings]:
                        return format_gloss(gloss)
            if not has_kanji(k):
                # a kana headword: the sense usually written in kana is the one meant (いつか SOMETIME,
                # not 五日 FIFTH-DAY)
                uk = [e for e in ents if "uk" in (e[3] or "")]
                if uk and uk[0][0] >= ents[0][0] - 2:   # but not なら OAK over なら IF
                    return format_gloss(uk[0][2])
            return format_gloss(ents[0][2])
        return None
