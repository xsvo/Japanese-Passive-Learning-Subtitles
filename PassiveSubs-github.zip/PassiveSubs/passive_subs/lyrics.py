"""Lyrics mode: a plain .txt of Japanese lyrics (no timing) + the video -> timed lines.

How it works, all offline after a one-time model download (~230 MB, saved in %APPDATA%\\PassiveSubs\\models):
  1. The singer's voice is separated from the music (UVR MDX-Net vocal model, via sherpa-onnx).
  2. A Japanese speech recogniser (SenseVoice) listens to the vocals and gives each sung character a time.
  3. The recognised characters are matched against your lyrics (they don't have to agree exactly), so every
     lyrics character gets a time. Lines start when their first character is sung.
The result is saved (in a "PassiveSubs lyrics timing" folder next to the video) as an .srt plus "<srt>.times.json" (per-character times, used for the
karaoke timing inside each line), and then converted like any other Japanese subtitle file.
"""
import json
import os
import re
import subprocess
import tarfile
import urllib.request

import numpy as np

RELEASES = "https://github.com/k2-fsa/sherpa-onnx/releases/download/"
VOCAL_MODEL = ("UVR-MDX-NET-Voc_FT.onnx", RELEASES + "source-separation-models/UVR-MDX-NET-Voc_FT.onnx")
ASR_DIR = "sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17"
ASR_MODEL = (ASR_DIR, RELEASES + "asr-models/" + ASR_DIR + ".tar.bz2")
MAX_LINE = 22          # longer lyric lines are split at their spaces
_SKIP = re.compile(r"[\s　、。，．,.!?！？「」『』（）()…・〜~♪ー-]")


def models_dir():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "PassiveSubs", "models")


def is_lyrics_file(path):
    """A .txt of Japanese text with no subtitle timing in it."""
    if os.path.splitext(path)[1].lower() != ".txt":
        return False
    try:
        from .subtitles import read_text
        text = read_text(path)[0]
    except Exception:
        return False
    if re.search(r"\d+:\d\d[:.,]\d\d|-->|\{\d+\}\{\d+\}|^\[\d+:\d\d", text, re.M):
        return False      # it has times: a subtitle format
    return bool(re.search(r"[぀-ヿ一-鿿]", text))


def read_lyrics(path, swaps=None):
    """Lyric lines, long ones split at their spaces so each fits on screen."""
    from .subtitles import read_text
    from .kana import fix_lookalikes
    out = []
    for raw in read_text(path)[0].splitlines():
        line, sw = fix_lookalikes(raw.strip().strip("﻿"))
        if swaps is not None:
            swaps.extend(sw)
        if not line or not re.search(r"[぀-ヿ一-鿿]", line):
            continue
        parts = [p for p in re.split(r"[ 　]+", line) if p]
        cur = ""
        for p in parts:
            if cur and len(_SKIP.sub("", cur + p)) > MAX_LINE:
                out.append(cur)
                cur = p
            else:
                cur = (cur + "　" + p) if cur else p
        if cur:
            out.append(cur)
    return out


def _download(name, url, log, extract=False):
    d = models_dir()
    os.makedirs(d, exist_ok=True)
    target = os.path.join(d, name)
    if os.path.exists(target):
        return target
    log("  Downloading %s (one time only)..." % name)
    tmp = target + (".tar.bz2" if extract else "") + ".part"
    with urllib.request.urlopen(url, timeout=60) as r, open(tmp, "wb") as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
    if extract:
        with tarfile.open(tmp, "r:bz2") as t:
            t.extractall(d)
        os.remove(tmp)
    else:
        os.replace(tmp, target)
    return target


def _audio(video, rate, channels):
    from .subtitles import ffmpeg_exe
    from .sync import _no_window
    cmd = [ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-i", video, "-vn", "-ac", str(channels),
           "-ar", str(rate), "-f", "f32le", "-"]
    p = subprocess.run(cmd, capture_output=True, **_no_window())
    if p.returncode != 0 or not p.stdout:
        raise RuntimeError("could not read the video's audio: " + p.stderr.decode("utf-8", "replace")[-300:])
    return np.frombuffer(p.stdout, dtype=np.float32).reshape(-1, channels).T.copy()


def _vocals(video, log, threads):
    import sherpa_onnx as so
    model = _download(*VOCAL_MODEL, log=log)
    mix = _audio(video, 44100, 2)
    log("  Separating the singing from the music (takes about half the song's length)...")
    cfg = so.OfflineSourceSeparationConfig(model=so.OfflineSourceSeparationModelConfig(
        uvr=so.OfflineSourceSeparationUvrModelConfig(model=model), num_threads=threads))
    out = so.OfflineSourceSeparation(cfg).process(44100, mix)
    stems = [np.array(s.data, dtype=np.float32).mean(axis=0) for s in out.stems]

    def quiet(a):   # the vocal stem has pauses between lines; the music keeps playing
        fr = a[: len(a) // 4410 * 4410].reshape(-1, 4410)
        rms = np.sqrt((fr ** 2).mean(axis=1))
        return float((rms < 0.25 * rms.mean()).mean())
    voc = max(stems, key=quiet)
    n = int(len(voc) * 16000 / out.sample_rate)
    x = np.interp(np.linspace(0, len(voc) - 1, n), np.arange(len(voc)), voc).astype(np.float32)
    return x / (np.abs(x).max() + 1e-9)


def _segments(x, hop=160):
    """Sung stretches of the vocal track (frames of 10 ms), long ones split at their quietest point."""
    fr = x[: len(x) // hop * hop].reshape(-1, hop)
    rms = np.sqrt((fr ** 2).mean(axis=1))
    thr = max(0.02, 0.15 * float(np.median(rms[rms > 0.01])) if (rms > 0.01).any() else 0.02)
    on = rms > thr
    segs, st, gap, en = [], None, 0, 0
    for i, v in enumerate(on):
        if v:
            st = i if st is None else st
            gap, en = 0, i
        elif st is not None:
            gap += 1
            if gap > 35:
                segs.append([st, en])
                st = None
    if st is not None:
        segs.append([st, en])
    segs = [s for s in segs if s[1] - s[0] > 30]
    smooth = np.convolve(rms, np.ones(15) / 15, mode="same")
    out = []
    while segs:
        a, b = segs.pop(0)
        if b - a > 1500:                       # > 15 s: cut at the quietest moment in the middle part
            lo, hi = a + 400, b - 400
            cut = lo + int(np.argmin(smooth[lo:hi]))
            segs[:0] = [[a, cut], [cut, b]]
        else:
            out.append((a, b))
    return out


def _recognise(x, log, threads):
    import sherpa_onnx as so
    d = _download(*ASR_MODEL, log=log, extract=True)
    rec = so.OfflineRecognizer.from_sense_voice(model=os.path.join(d, "model.int8.onnx"),
                                                tokens=os.path.join(d, "tokens.txt"),
                                                language="ja", num_threads=threads)
    chars = []
    segs = _segments(x)
    log("  Listening to the singing (%d sung parts)..." % len(segs))
    for a, b in segs:
        lo, hi = max(0, a - 20) * 160, min(len(x), (b + 20) * 160)
        s = rec.create_stream()
        s.accept_waveform(16000, x[lo:hi])
        rec.decode_stream(s)
        r = s.result
        for tok, t in zip(r.tokens, r.timestamps):
            for c in tok:
                if not _SKIP.match(c):
                    chars.append((c, int((t + lo / 16000) * 1000)))
    return chars


def _norm(c):
    from .kana import kata_to_hira
    return kata_to_hira(c)


def _align(lyric_chars, heard):
    """Edit-distance alignment of the lyrics' characters to the heard ones -> time (ms or None) per lyric char."""
    n, m = len(lyric_chars), len(heard)
    a = [_norm(c) for c in lyric_chars]
    b = [_norm(c) for c, _t in heard]
    INF = 10 ** 9
    cost = np.full((n + 1, m + 1), INF, dtype=np.int64)
    move = np.zeros((n + 1, m + 1), dtype=np.int8)
    cost[0, :] = np.arange(m + 1) * 0          # heard sounds before the first lyric are free (ad-libs)
    cost[:, 0] = np.arange(n + 1)
    for i in range(1, n + 1):
        ci = a[i - 1]
        row_prev, row = cost[i - 1], cost[i]
        for j in range(1, m + 1):
            sub = row_prev[j - 1] + (0 if ci == b[j - 1] else 1)
            dele = row_prev[j] + 1                  # lyric char not heard
            ins = row[j - 1] + 1                    # heard char not in the lyrics
            if sub <= dele and sub <= ins:
                row[j], move[i, j] = sub, 0
            elif dele <= ins:
                row[j], move[i, j] = dele, 1
            else:
                row[j], move[i, j] = ins, 2
    j = int(np.argmin(cost[n]))                    # heard sounds after the last lyric are free too
    times, matched = [None] * n, 0
    i = n
    while i > 0 and j > 0:
        mv = move[i, j]
        if mv == 0:
            times[i - 1] = heard[j - 1][1]
            matched += a[i - 1] == b[j - 1]
            i, j = i - 1, j - 1
        elif mv == 1:
            i -= 1
        else:
            j -= 1
    return times, matched


def _fill(times):
    """Characters with no time get one by interpolating between their neighbours."""
    known = [(i, t) for i, t in enumerate(times) if t is not None]
    if not known:
        return None
    idx, ts = zip(*known)
    ts = np.maximum.accumulate(np.array(ts, dtype=np.float64))   # keep time moving forward
    return np.interp(np.arange(len(times)), idx, ts).astype(int).tolist()


def _ts(ms):
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def lyrics_to_srt(video, txt, log=print, out=None, threads=None):
    """Times the lyrics in txt against the singing in video. Writes out (an .srt) + out.times.json
    and returns (srt_path, report)."""
    try:
        import sherpa_onnx  # noqa: F401
    except ImportError:
        raise RuntimeError("Lyrics mode needs the sherpa-onnx package. Run Start.bat again to install it.")
    threads = threads or max(1, min(8, (os.cpu_count() or 2) - 1))
    out = out or os.path.splitext(video)[0] + ".lyrics.ja.srt"
    swaps = []
    lines = read_lyrics(txt, swaps)
    if swaps:
        log("  Fixed %d katakana/kanji lookalike%s in the lyrics (they look the same, e.g. ロ and 口): %s" % (
            len(swaps), "" if len(swaps) == 1 else "s", "; ".join(swaps[:5])))
    if not lines:
        raise RuntimeError("No Japanese lyrics found in %s" % os.path.basename(txt))
    log("  %d lyric lines" % len(lines))
    x = _vocals(video, log, threads)
    heard = _recognise(x, log, threads)
    flat, owner = [], []
    for k, l in enumerate(lines):
        for c in l:
            if not _SKIP.match(c):
                flat.append(c)
                owner.append(k)
    times, matched = _align(flat, heard)
    got = sum(t is not None for t in times)
    full = _fill(times)
    if full is None or matched < 0.1 * len(flat):
        raise RuntimeError("The singing didn't match these lyrics (only %d of %d characters heard). "
                           "Check it's the right song." % (matched, len(flat)))
    starts, last, anchors = [], [], []
    for k in range(len(lines)):
        ix = [i for i, o in enumerate(owner) if o == k]
        ts = [full[i] for i in ix]
        heard_here = sum(times[i] is not None for i in ix)
        starts.append(ts[0] if ts else None)
        last.append(ts[-1] if ts else None)
        anchors.append({"times": ts, "heard": heard_here, "chars": len(ix)})
    # lines nobody sings in this video (a TV-size opening with the full song's lyrics, or a verse it skips):
    # a run of unheard lines with no room for them in the song between the sung lines around it
    dur_ms = int(len(x) / 16)
    unheard = [a["chars"] > 0 and a["heard"] < 0.3 * a["chars"] for a in anchors]
    if sum(not u for u in unheard) < 2:
        raise RuntimeError("The singing didn't match these lyrics. Check it's the right song.")
    keep = [True] * len(lines)
    k = 0
    while k < len(lines):
        if not unheard[k]:
            k += 1
            continue
        j = k
        while j < len(lines) and unheard[j]:
            j += 1
        prev_end = last[k - 1] if k > 0 else 0
        next_start = starts[j] if j < len(lines) else dur_ms
        need = 110 * sum(anchors[i]["chars"] for i in range(k, j))     # fast singing: ~9 sounds a second
        if next_start - prev_end < 0.6 * need:
            for i in range(k, j):
                keep[i] = False
        k = j
    left_out = [lines[k] for k in range(len(lines)) if not keep[k]]
    kept_chars = sum(a["chars"] for a, kp in zip(anchors, keep) if kp)
    kept_matched = sum(a["heard"] for a, kp in zip(anchors, keep) if kp)
    if kept_matched < 0.4 * kept_chars:
        raise RuntimeError("The singing didn't match these lyrics well (only %d of %d characters heard). "
                           "Check it's the right song." % (matched, len(flat)))
    idx = [k for k in range(len(lines)) if keep[k]]
    timed = []
    for n_, k in enumerate(idx):
        l = lines[k]
        s = max(0, starts[k] - 150)
        nxt = starts[idx[n_ + 1]] - 150 if n_ + 1 < len(idx) else dur_ms
        e = last[k] + 700                               # the last note is held a little
        if nxt - e < 1500:
            e = nxt - 50                                # short gap: keep the line up until the next one
        e = max(min(e, nxt - 50), s + 600)
        timed.append((s, e, l))
    anchors = [anchors[k] for k in idx]
    with open(out, "w", encoding="utf-8") as f:
        for n, (s, e, l) in enumerate(timed, 1):
            f.write("%d\n%s --> %s\n%s\n\n" % (n, _ts(s), _ts(e), l))
    with open(out + ".times.json", "w", encoding="utf-8") as f:
        json.dump({"lines": [{"text": l, "start": s, "end": e, "char_times": a["times"]}
                             for (s, e, l), a in zip(timed, anchors)]}, f, ensure_ascii=False)
    weak = [l for (_s, _e, l), a in zip(timed, anchors) if a["chars"] and a["heard"] < 0.5 * a["chars"]]
    report = ("Lyrics timed from the singing: %d of %d lines, %d%% of their characters matched what was sung"
              % (len(timed), len(lines), round(100 * min(matched, kept_chars) / max(1, kept_chars))))
    if left_out:
        report += (". %d line%s aren't sung in this video, so they were left out (the lyrics are probably for "
                   "the full song and this is the shorter TV version): %s" % (
                       len(left_out), "" if len(left_out) == 1 else "s", " / ".join(left_out[:3]) +
                       (" ..." if len(left_out) > 3 else "")))
    if weak:
        report += "; %d line%s placed by guesswork (couldn't hear them clearly): %s" % (
            len(weak), "" if len(weak) == 1 else "s", " / ".join(weak[:3]))
    log("  " + report)
    return out, report


def char_anchors(srt_path):
    """{line start ms: [char time ms...]} from a lyrics .times.json, for karaoke timing inside each line."""
    try:
        with open(srt_path + ".times.json", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    return {d["start"]: d["char_times"] for d in data.get("lines", [])}
