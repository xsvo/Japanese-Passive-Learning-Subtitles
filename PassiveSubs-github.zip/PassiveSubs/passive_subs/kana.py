"""Kana helpers: katakana/hiragana conversion, Hepburn romaji, mora counting."""
import re

_KATA_START, _KATA_END = 0x30A1, 0x30F6


def kata_to_hira(s: str) -> str:
    return "".join(chr(ord(c) - 0x60) if _KATA_START <= ord(c) <= _KATA_END else c for c in s)


def hira_to_kata(s: str) -> str:
    return "".join(chr(ord(c) + 0x60) if 0x3041 <= ord(c) <= 0x3096 else c for c in s)


KANJI_RE = re.compile(r"[㐀-䶿一-鿿豈-﫿々〆ヵヶ]")
HIRA_RE = re.compile(r"[ぁ-ゖゝゞ]")
KATA_RE = re.compile(r"[ァ-ヺヽヾｦ-ﾝ]")
JP_RE = re.compile(r"[ぁ-ゖァ-ヺ㐀-䶿一-鿿々ー]")


def has_kanji(s):
    return bool(KANJI_RE.search(s))


def has_katakana(s):
    return bool(KATA_RE.search(s))


def is_hiragana_only(s):
    return bool(s) and all(HIRA_RE.match(c) or c in "ー〜" for c in s)


def has_japanese(s):
    return bool(JP_RE.search(s))


_DIGRAPHS = {
    "きゃ": "kya", "きゅ": "kyu", "きょ": "kyo", "しゃ": "sha", "しゅ": "shu", "しょ": "sho",
    "ちゃ": "cha", "ちゅ": "chu", "ちょ": "cho", "にゃ": "nya", "にゅ": "nyu", "にょ": "nyo",
    "ひゃ": "hya", "ひゅ": "hyu", "ひょ": "hyo", "みゃ": "mya", "みゅ": "myu", "みょ": "myo",
    "りゃ": "rya", "りゅ": "ryu", "りょ": "ryo", "ぎゃ": "gya", "ぎゅ": "gyu", "ぎょ": "gyo",
    "じゃ": "ja", "じゅ": "ju", "じょ": "jo", "ぢゃ": "ja", "ぢゅ": "ju", "ぢょ": "jo",
    "びゃ": "bya", "びゅ": "byu", "びょ": "byo", "ぴゃ": "pya", "ぴゅ": "pyu", "ぴょ": "pyo",
    "しぇ": "she", "ちぇ": "che", "じぇ": "je", "てぃ": "ti", "でぃ": "di", "とぅ": "tu",
    "どぅ": "du", "ふぁ": "fa", "ふぃ": "fi", "ふぇ": "fe", "ふぉ": "fo", "ふゅ": "fyu",
    "うぃ": "wi", "うぇ": "we", "うぉ": "wo", "ゔぁ": "va", "ゔぃ": "vi", "ゔぇ": "ve",
    "ゔぉ": "vo", "つぁ": "tsa", "つぃ": "tsi", "つぇ": "tse", "つぉ": "tso", "いぇ": "ye",
    "でゅ": "dyu", "てゅ": "tyu", "くぁ": "kwa", "ぐぁ": "gwa",
}
_MONO = dict(zip(
    "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわゐゑをん"
    "がぎぐげござじずぜぞだぢづでどばびぶべぼぱぴぷぺぽゔぁぃぅぇぉゃゅょゎ",
    ["a", "i", "u", "e", "o", "ka", "ki", "ku", "ke", "ko", "sa", "shi", "su", "se", "so",
     "ta", "chi", "tsu", "te", "to", "na", "ni", "nu", "ne", "no", "ha", "hi", "fu", "he", "ho",
     "ma", "mi", "mu", "me", "mo", "ya", "yu", "yo", "ra", "ri", "ru", "re", "ro", "wa", "i", "e",
     "o", "n", "ga", "gi", "gu", "ge", "go", "za", "ji", "zu", "ze", "zo", "da", "ji", "zu", "de",
     "do", "ba", "bi", "bu", "be", "bo", "pa", "pi", "pu", "pe", "po", "vu", "a", "i", "u", "e",
     "o", "ya", "yu", "yo", "wa"],
))
_PUNCT = {"。": ".", "、": ",", "！": "!", "？": "?", "「": '"', "」": '"', "『": '"', "』": '"',
          "…": "...", "‥": "..", "・": " ", "〜": "~", "～": "~", "（": "(", "）": ")", "：": ":",
          "；": ";", "，": ",", "．": ".", "　": " ", "♪": "♪", "―": "-", "─": "-", "→": "->",
          "【": "[", "】": "]", "〈": "<", "〉": ">", "《": '"', "》": '"', "＆": "&", "％": "%"}


def punct_to_ascii(s: str) -> str:
    out = []
    for c in s:
        if c in _PUNCT:
            out.append(_PUNCT[c])
        elif 0xFF01 <= ord(c) <= 0xFF5E:  # full-width ASCII
            out.append(chr(ord(c) - 0xFEE0))
        else:
            out.append(c)
    return "".join(out)


def to_romaji(kana: str, long_vowels: str = "double") -> str:
    """Hepburn-style romaji. long_vowels: 'double' writes ー as a repeated vowel."""
    s = kata_to_hira(kana)
    out = []
    i = 0
    sokuon = False
    prev_n = False
    while i < len(s):
        c = s[i]
        two = s[i:i + 2]
        if c == "っ":
            sokuon = True
            i += 1
            continue
        if two in _DIGRAPHS:
            r = _DIGRAPHS[two]
            i += 2
        elif c in _MONO:
            r = _MONO[c]
            i += 1
        elif c == "ー":
            prev = next((ch for ch in reversed("".join(out)) if ch in "aeiou"), "")
            r = prev if long_vowels == "double" else "-"
            i += 1
        else:
            r = punct_to_ascii(c)
            i += 1
        if sokuon:
            if r and r[0] in "bcdfghjkmpqrstvwxyz":
                r = ("t" if r.startswith("ch") else r[0]) + r
            elif not r or not r[0].isalpha():
                out.append("")  # trailing small tsu (e.g. あっ!) is dropped
            sokuon = False
        if prev_n and r and r[0] in "aeiouy":
            out[-1] = "n'"
        prev_n = (c == "ん" and r == "n")
        out.append(r)
    return "".join(out)


_SMALL = set("ゃゅょぁぃぅぇぉゎャュョァィゥェォヮ")


def mora_count(kana: str) -> int:
    n = 0
    for c in kana:
        if c in _SMALL:
            continue
        if HIRA_RE.match(c) or KATA_RE.match(c) or c in "ーっッ":
            n += 1
    return max(n, 0)


# Katakana and kanji that look the same. Lyrics sites and OCR mix them up: ロ for 口 (mouth), カ for 力 (power).
_LOOK_K2J = {"ロ": "口", "カ": "力", "エ": "工", "ニ": "二", "タ": "夕", "ー": "一"}   # (ト/卜: 卜 is too rare to guess)
_LOOK_J2K = {v: k for k, v in _LOOK_K2J.items()}
_KATA = re.compile(r"[ァ-ヺー]")
_HIRA = re.compile(r"[ぁ-ゖ]")


def fix_lookalikes(text):
    """Swap katakana / kanji lookalikes into what they must be from the letters around them:
    a lone ロ next to kanji or hiragana is 口, and 力 inside a katakana word (力ード) is カ.
    Returns (fixed text, ["ロ→口 in ...", ...])."""
    chars, swaps = list(text), []

    def ctx(i):
        prev = chars[i - 1] if i > 0 else ""
        nxt = chars[i + 1] if i + 1 < len(chars) else ""
        return (prev, nxt, bool(KANJI_RE.match(prev)), bool(KANJI_RE.match(nxt)),
                bool(_KATA.match(prev)), bool(_KATA.match(nxt)))

    def swap(i, new):
        swaps.append("%s→%s in %s" % (chars[i], new, text.strip()[:30]))
        chars[i] = new

    # 1. kanji inside a katakana word: 力ード -> カード, 口ボット -> ロボット, カ一ド -> カード
    for i, c in enumerate(chars):
        if c in _LOOK_J2K:
            prev, nxt, p_k, n_k, p_kata, n_kata = ctx(i)
            # only when katakana follows (タメ口, アニメ化: katakana + a real kanji, are left alone)
            # (a long-vowel mark or small kana after a kanji is impossible, so that always means katakana)
            if n_kata and (nxt in "ーァィゥェォャュョッ" or (not p_k and not _HIRA.match(prev or " "))) and \
                    (c != "一" or p_kata):
                swap(i, _LOOK_J2K[c])
    # 2. a lone katakana letter among kanji / hiragana: ロが -> 口が, エ場 -> 工場, 第ー話 -> 第一話
    for i, c in enumerate(chars):
        if c in _LOOK_K2J:
            prev, nxt, p_k, n_k, p_kata, n_kata = ctx(i)
            if p_kata or n_kata:
                continue
            if c == "ー":           # long-vowel mark: only between two kanji
                ok = p_k and n_k
            else:
                ok = p_k or n_k or bool(_HIRA.match(prev or " ")) or bool(_HIRA.match(nxt or " "))
            if ok:
                swap(i, _LOOK_K2J[c])
    return "".join(chars), swaps
