"""Blu-ray picture subtitles (.sup, "PGS").

A .sup file holds each subtitle as a picture, not text. This reads the pictures and their timing
so they can be turned into Japanese text (see ocr.py).

Returns events as [(start_ms, end_ms, image)] where image is a greyscale numpy array of the text:
dark text on white, cropped, which is what OCR reads best. png() turns one into a PNG file's bytes
(no image library needed).
"""
import struct
import zlib

import numpy as np

PCS, WDS, PDS, ODS, END = 0x16, 0x17, 0x14, 0x15, 0x80


def _segments(data):
    i, n = 0, len(data)
    while i + 13 <= n:
        if data[i:i + 2] != b"PG":
            # not aligned: look for the next segment header
            j = data.find(b"PG", i + 1)
            if j < 0:
                return
            i = j
            continue
        pts = struct.unpack(">I", data[i + 2:i + 6])[0]
        typ = data[i + 10]
        size = struct.unpack(">H", data[i + 11:i + 13])[0]
        yield pts // 90, typ, data[i + 13:i + 13 + size]
        i += 13 + size


def _rle(buf, w, h):
    """PGS run-length decoding into an array of palette indexes."""
    out = np.zeros(w * h, dtype=np.uint8)
    pos, i, n = 0, 0, len(buf)
    row = 0
    while i < n and row < h:
        b = buf[i]
        i += 1
        if b:
            if pos < w * h:
                out[pos] = b
            pos += 1
            continue
        b2 = buf[i]
        i += 1
        if b2 == 0:                     # end of line
            row += 1
            pos = row * w
            continue
        flag = b2 & 0xC0
        if flag == 0x00:
            length, color = b2 & 0x3F, 0
        elif flag == 0x40:
            length, color = ((b2 & 0x3F) << 8) | buf[i], 0
            i += 1
        elif flag == 0x80:
            length, color = b2 & 0x3F, buf[i]
            i += 1
        else:
            length, color = ((b2 & 0x3F) << 8) | buf[i], buf[i + 1]
            i += 2
        end = min(pos + length, w * h)
        out[pos:end] = color
        pos += length
    return out.reshape(h, w)


def _render(objs, comps, palette):
    """Paint the shown objects onto one picture: dark text on white, cropped to the text."""
    pieces = []
    for oid, x, y in comps:
        if oid not in objs:
            continue
        w, h, idx = objs[oid]
        pieces.append((x, y, w, h, idx))
    if not pieces:
        return None
    x0 = min(p[0] for p in pieces)
    y0 = min(p[1] for p in pieces)
    x1 = max(p[0] + p[2] for p in pieces)
    y1 = max(p[1] + p[3] for p in pieces)
    canvas = np.full((y1 - y0, x1 - x0), 255, dtype=np.uint8)
    lum = np.full(256, 255, dtype=np.float32)
    alpha = np.zeros(256, dtype=np.float32)
    for k, (Y, A) in palette.items():
        lum[k], alpha[k] = Y, A / 255.0
    for x, y, w, h, idx in pieces:
        a = alpha[idx]
        Y = lum[idx]
        # Subtitles are usually white letters with a dark outline. Keep the letters' fill:
        # bright and opaque pixels become black ink, everything else stays paper-white.
        ink = (a > 0.5) & (Y > 128)
        region = canvas[y - y0:y - y0 + h, x - x0:x - x0 + w]
        region[ink] = 0
    if (canvas == 0).sum() < 20:
        # no bright fill found (dark letters with a light edge): use the darkest opaque pixels instead
        for x, y, w, h, idx in pieces:
            a, Y = alpha[idx], lum[idx]
            ink = (a > 0.5) & (Y <= 128)
            canvas[y - y0:y - y0 + h, x - x0:x - x0 + w][ink] = 0
    # a white margin helps OCR
    return np.pad(canvas, 20, constant_values=255)


def png(a, max_w=1600, max_h=1200):
    """Greyscale array -> PNG bytes, shrunk by a whole factor if it's very large."""
    f = max(1, -(-a.shape[1] // max_w), -(-a.shape[0] // max_h))
    if f > 1:
        h, w = a.shape[0] // f * f, a.shape[1] // f * f
        a = a[:h, :w].reshape(h // f, f, w // f, f).min(axis=(1, 3))   # keep thin strokes dark
    h, w = a.shape
    raw = b"".join(b"\x00" + a[y].tobytes() for y in range(h))

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def read_sup(path):
    """[(start_ms, end_ms, picture array)] for every subtitle picture in a .sup file."""
    with open(path, "rb") as f:
        data = f.read()
    events = []
    palette, objs, pending = {}, {}, {}
    shown = None          # (start_ms, comps) currently on screen
    comps = []
    for t, typ, seg in _segments(data):
        if typ == PCS:
            n_obj = seg[10]
            comps = []
            p = 11
            for _ in range(n_obj):
                oid = struct.unpack(">H", seg[p:p + 2])[0]
                cropped = seg[p + 3] & 0x80
                x, y = struct.unpack(">HH", seg[p + 4:p + 8])
                comps.append((oid, x, y))
                p += 16 if cropped else 8
            state = seg[7] >> 6
            if state:          # epoch start / acquisition point: fresh objects
                pass
            pcs_time = t
        elif typ == PDS:
            p = 2
            while p + 5 <= len(seg):
                k, Y, Cr, Cb, A = seg[p:p + 5]
                palette[k] = (Y, A)
                p += 5
        elif typ == ODS:
            oid = struct.unpack(">H", seg[0:2])[0]
            flags = seg[3]
            if flags & 0x80:   # first piece: carries the size
                w, h = struct.unpack(">HH", seg[7:11])
                pending[oid] = [w, h, bytearray(seg[11:])]
            elif oid in pending:
                pending[oid][2] += seg[4:]
            if flags & 0x40 and oid in pending:   # last piece
                w, h, buf = pending.pop(oid)
                objs[oid] = (w, h, _rle(bytes(buf), w, h))
        elif typ == END:
            if shown is not None:
                start, img = shown
                if img is not None and pcs_time > start:
                    events.append((start, pcs_time, img))
                shown = None
            if comps:
                shown = (pcs_time, _render(objs, comps, palette))
    if shown is not None and shown[1] is not None:
        events.append((shown[0], shown[0] + 3000, shown[1]))
    return events
