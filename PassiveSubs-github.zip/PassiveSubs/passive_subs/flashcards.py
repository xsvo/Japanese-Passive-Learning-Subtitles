"""Flashcards for the words to learn, to study before watching an episode.

Each card plays a short clip cut from the video where the word is said. You guess the meaning, then say
whether you remembered it. Remember a word LEARN_STEPS times in a row and it moves to a test: a sentence
with the word left out, and you pick the right kana from four. Pass and it goes to Words I know.
Everything is saved in %APPDATA%\\PassiveSubs\\flashcards (deck.json + the audio clips)."""

import hashlib
import json
import os
import random
import re
import subprocess
import sys
import time

LEARN_STEPS = 3          # remembered this many times in a row -> the card moves to the test
NEW_PER_SESSION = 20     # words added from an episode at a time (most frequent first)
FALLBACK_KANA = ["たべる", "みる", "いく", "かえる", "はなす", "まつ", "あそぶ", "しごと", "がっこう", "ともだち",
                 "でんしゃ", "やくそく", "てがみ", "せかい", "じかん", "こころ", "そら", "ゆめ", "ちから", "ことば",
                 "あたらしい", "うつくしい", "さびしい", "つよい", "はやい", "おもい", "しずか", "げんき"]


def deck_dir():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "PassiveSubs", "flashcards")


def kana_of(card):
    """The answer for the test: the word's reading in hiragana (the word itself if it's already kana)."""
    from .kana import kata_to_hira, has_kanji
    r = card.get("reading") or ("" if has_kanji(card["word"]) else card["word"])
    return kata_to_hira(r)


class Deck:
    def __init__(self, path=None):
        self.path = path or os.path.join(deck_dir(), "deck.json")
        self.cards = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                self.cards = json.load(f).get("cards", {})
        except (OSError, ValueError):
            pass

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"version": 1, "cards": self.cards}, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    def add(self, rows, show="", known=(), limit=NEW_PER_SESSION):
        """Add words-to-learn rows (from the last conversion) that aren't cards or known words yet."""
        new = []
        for r in rows:
            w = r["word"]
            if w in self.cards or w in known or not kana_of(r):
                if w in self.cards and r.get("media") and not self.cards[w].get("media"):
                    self.cards[w].update({k: r[k] for k in ("media", "start", "end", "line_start", "line_end",
                                                            "surface", "passive", "example") if k in r})
                continue
            if len(new) >= limit:
                break
            c = {k: r.get(k, "") for k in ("word", "reading", "english", "example", "passive", "surface", "media")}
            c.update({k: r.get(k, 0) for k in ("start", "end", "line_start", "line_end")})
            c.update(show=show, stage="learn", streak=0, seen=0, fails=0, tests_failed=0, added=time.time())
            self.cards[w] = c
            new.append(w)
        self.save()
        return new

    def active(self, show=None):
        """Cards still to study: this show's first, then the rest, each most-failed first."""
        cs = [c for c in self.cards.values() if c["stage"] in ("learn", "test")]
        cs.sort(key=lambda c: (c.get("show") != show, c["stage"] != "test", -c.get("fails", 0), c.get("added", 0)))
        return cs

    def counts(self):
        n = {"learn": 0, "test": 0, "known": 0}
        for c in self.cards.values():
            n[c["stage"]] = n.get(c["stage"], 0) + 1
        return n

    def remembered(self, card, yes):
        card["seen"] = card.get("seen", 0) + 1
        if yes:
            card["streak"] = card.get("streak", 0) + 1
            if card["streak"] >= LEARN_STEPS:
                card["stage"] = "test"
        else:
            card["streak"] = 0
            card["fails"] = card.get("fails", 0) + 1
        card["last"] = time.time()
        self.save()

    def tested(self, card, passed):
        if passed:
            card["stage"] = "known"
            card["known_at"] = time.time()
        else:   # back to learning, but one remember away from another try
            card["stage"] = "learn"
            card["streak"] = LEARN_STEPS - 1
            card["tests_failed"] = card.get("tests_failed", 0) + 1
        card["last"] = time.time()
        self.save()


class Session:
    """The order cards come up in: a failed card comes back after a few others, a remembered one later."""

    def __init__(self, cards):
        self.queue = list(cards)

    def next(self):
        return self.queue[0] if self.queue else None

    def done(self, card, again_after=None):
        if self.queue and self.queue[0] is card:
            self.queue.pop(0)
        if again_after is not None:
            self.queue.insert(min(again_after, len(self.queue)), card)


def again_after(card, failed):
    if failed:
        return 3
    if card["stage"] == "test":
        return 2
    return 4 + 3 * card.get("streak", 0)


# --- audio clips --------------------------------------------------------------------------------------

def clip_path(card, whole_line=False):
    """Cut (once) a short .wav from the video: the word with a little either side, or the whole line."""
    media = card.get("media")
    if not media or not os.path.exists(media):
        return None
    if whole_line:
        a, b = card["line_start"] - 200, min(card["line_end"] + 250, card["line_start"] + 12000)
    else:
        # without the recogniser the word's time is estimated from the line's length, so it drifts later
        # in long lines: allow for it
        drift = 0 if card.get("heard") else max(0, card["start"] - card.get("line_start", card["start"]))
        a = card["start"] - 350 - int(0.1 * drift)
        b = min(card["end"] + 450 + int(0.3 * drift), max(card.get("line_end", 0) + 300, card["end"] + 450))
    a = max(0, a)
    if b <= a:
        return None
    key = hashlib.sha1(("%s|%d|%d|%d" % (media, os.path.getsize(media), a, b)).encode("utf-8")).hexdigest()[:16]
    out = os.path.join(deck_dir(), "audio", key + ".wav")
    if os.path.exists(out) and os.path.getsize(out) > 1000:
        return out
    os.makedirs(os.path.dirname(out), exist_ok=True)
    from .subtitles import ffmpeg_exe
    cmd = [ffmpeg_exe(), "-v", "error", "-y", "-ss", "%.3f" % (a / 1000), "-t", "%.3f" % ((b - a) / 1000),
           "-i", media, "-vn", "-ac", "1", "-ar", "22050", "-af", "afade=t=in:d=0.04,areverse,"
           "afade=t=in:d=0.08,areverse", out]
    flags = 0x08000000 if sys.platform == "win32" else 0   # no console window
    try:
        subprocess.run(cmd, check=True, capture_output=True, timeout=60, creationflags=flags)
    except Exception:
        return None
    return out if os.path.exists(out) else None


_REC = {}


def _recognizer(download=True, log=lambda m: None):
    """The Japanese speech recogniser from lyrics mode (downloaded once if needed), or None."""
    if "rec" in _REC:
        return _REC["rec"]
    rec = None
    try:
        import sherpa_onnx as so
        from . import lyrics
        d = os.path.join(lyrics.models_dir(), lyrics.ASR_DIR)
        if not os.path.exists(os.path.join(d, "model.int8.onnx")):
            if not download:
                return None
            d = lyrics._download(*lyrics.ASR_MODEL, log=log, extract=True)
        rec = so.OfflineRecognizer.from_sense_voice(model=os.path.join(d, "model.int8.onnx"),
                                                    tokens=os.path.join(d, "tokens.txt"), language="ja",
                                                    num_threads=2)
    except Exception:
        rec = None
    _REC["rec"] = rec
    return rec


def _audio16(media, a, b):
    import numpy as np
    from .subtitles import ffmpeg_exe
    flags = 0x08000000 if sys.platform == "win32" else 0
    r = subprocess.run([ffmpeg_exe(), "-v", "error", "-ss", "%.3f" % (a / 1000), "-t", "%.3f" % ((b - a) / 1000),
                        "-i", media, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                       capture_output=True, timeout=60, creationflags=flags)
    return np.frombuffer(r.stdout, np.int16).astype(np.float32) / 32768


def refine(card, rec=None):
    """Listen to the line and find the moment the word is really said (the subtitle only gives the line).
    Updates card start/end and sets card['heard'] True when found."""
    if card.get("refined") or not card.get("media") or not os.path.exists(card["media"]):
        return card.get("heard", False)
    rec = rec or _recognizer(download=False)
    if rec is None:
        return False
    from .kana import kata_to_hira
    a = max(0, card["line_start"] - 400)
    b = card["line_end"] + 400
    try:
        x = _audio16(card["media"], a, b)
        st = rec.create_stream()
        st.accept_waveform(16000, x)
        rec.decode_stream(st)
        toks, times = st.result.tokens, st.result.timestamps
    except Exception:
        return False
    chars, ct = [], []
    for tok, t in zip(toks, times):
        for c in tok:
            chars.append(c)
            ct.append(t)
    heard = "".join(chars)
    hira = kata_to_hira(heard)
    card["refined"] = True
    for form in (card.get("surface"), card["word"], kana_of(card)[:max(2, len(kana_of(card)) - 1)],
                 re.sub(r"[ぁ-ゖ]+$", "", card.get("surface") or "")):
        if not form:
            continue
        k = heard.find(form)
        if k < 0:
            k = hira.find(kata_to_hira(form))
        if k >= 0:
            j = min(len(ct) - 1, k + len(form))
            t0 = a + int(ct[k] * 1000)
            t1 = a + int(ct[j] * 1000) + (0 if j > k + len(form) - 1 else 250)
            card.update(start=t0, end=max(t1, t0 + 300), heard=True)
            return True
    card["heard"] = False
    return False


def play(path):
    if not path:
        return False
    if sys.platform == "win32":
        import winsound
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        return True
    for player in (["afplay"], ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"], ["aplay", "-q"]):
        try:
            subprocess.Popen(player + [path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except OSError:
            continue
    return False


# --- the test -----------------------------------------------------------------------------------------

def options(card, pool, n=4):
    """The right kana and n-1 others of similar length from your other words."""
    right = kana_of(card)
    others = []
    for k in pool:
        if k and k != right and k not in others and re.fullmatch(r"[ぁ-ゖー]+", k):
            others.append(k)
    for k in FALLBACK_KANA:
        if k != right and k not in others:
            others.append(k)
    random.shuffle(others)
    others.sort(key=lambda k: abs(len(k) - len(right)) + (0 if k[:1] == right[:1] else 0.5))
    picks = others[:n - 1] + [right]
    random.shuffle(picks)
    return picks, right


def claude_sentence(card, api_key):
    """A new short sentence using the word, written by Claude. Returns (sentence, word_as_written) or None."""
    if not api_key:
        return None
    try:
        from .ai_gloss import AIGlosser
        schema = {"type": "object", "additionalProperties": False, "required": ["sentence", "word_as_written"],
                  "properties": {"sentence": {"type": "string"}, "word_as_written": {"type": "string"}}}
        d = AIGlosser(api_key, log=lambda m: None)._call(
            "You write practice sentences for a learner of Japanese who watches anime.", schema,
            "Write one short, natural Japanese sentence (under 25 characters, everyday anime-style speech) that "
            "uses the word %s (%s, meaning %s), in kanji as usual. word_as_written is the word exactly as it "
            "appears in your sentence (conjugated if it is)." % (card["word"], kana_of(card), card.get("english", "")),
            max_tokens=1000)
        if d["word_as_written"] and d["word_as_written"] in d["sentence"]:
            return d["sentence"], d["word_as_written"]
    except Exception:
        pass
    return None


def blank(sentence, card):
    """The sentence with the word replaced by a gap, and whether the gap was found."""
    for form in (card.get("surface"), card["word"], re.sub(r"[ぁ-ゖ]+$", "", card["word"])):
        if form and form in sentence:
            return sentence.replace(form, "＿＿", 1), True
    return sentence, False


# --- the window ---------------------------------------------------------------------------------------

def open_window(root, rows=None, show="", known=None, on_known=None, api_key=""):
    """rows: the last conversion's words to learn (added to the deck). on_known(word) adds to Words I know."""
    import threading
    import tkinter as tk
    from tkinter import ttk

    deck = Deck()
    added = deck.add(rows or [], show=show, known=set(known or ()))
    sess = Session(deck.active(show))
    pool = [kana_of(c) for c in deck.cards.values()] + [kana_of(r) for r in (rows or []) if r.get("word")]

    win = tk.Toplevel(root)
    win.title("Flashcards - learn the words before you watch")
    win.geometry("760x600")
    win.minsize(600, 500)
    big, mid, small = ("Segoe UI", 34), ("Segoe UI", 16), ("Segoe UI", 12)
    jfont = ("Yu Gothic UI", 16)

    status = tk.StringVar()
    ttk.Label(win, textvariable=status, font=small, foreground="#444").pack(anchor="w", padx=14, pady=(10, 0))
    ttk.Label(win, text="Keys: Space = show answer / next,  1 = failed,  2 = remembered,  1-4 = pick in the test,  "
                        "R = play again", foreground="#888").pack(anchor="w", padx=14)
    card_f = tk.Frame(win, bg="white", bd=1, relief="solid")
    card_f.pack(fill="both", expand=True, padx=14, pady=10)
    head = tk.Label(card_f, bg="white", font=small, fg="#777")
    head.pack(pady=(14, 0))
    word_l = tk.Label(card_f, bg="white", font=big)
    word_l.pack(pady=(6, 0))
    sub_l = tk.Label(card_f, bg="white", font=mid, fg="#555")
    sub_l.pack()
    answer_l = tk.Label(card_f, bg="white", font=("Segoe UI", 24, "bold"), fg="#1d5c2e")
    answer_l.pack(pady=(10, 0))
    text = tk.Text(card_f, height=4, wrap="word", bd=0, bg="white", font=jfont, padx=20)
    text.tag_configure("hl", foreground="#c0392b", font=jfont + ("bold",))
    text.tag_configure("en", foreground="#333", font=("Segoe UI", 12))
    text.tag_configure("c", justify="center")
    text.pack(fill="x", padx=10, pady=8)
    opts_f = tk.Frame(card_f, bg="white")
    opts_f.pack(pady=6)
    audio_f = ttk.Frame(win)
    audio_f.pack(fill="x", padx=14)
    btn_f = ttk.Frame(win)
    btn_f.pack(fill="x", padx=14, pady=(6, 12))
    note = tk.StringVar()
    ttk.Label(audio_f, textvariable=note, foreground="#777").pack(side="right")

    state = {"card": None, "phase": None, "right": None}

    def set_text(parts):
        text.config(state="normal")
        text.delete("1.0", "end")
        for t, tags in parts:
            text.insert("end", t, tags + ("c",))
        text.config(state="disabled")

    def example_parts(c, hide=False):
        ex = c.get("example", "")
        f = c.get("surface") or c["word"]
        parts = []
        if f and f in ex:
            a, _, b = ex.partition(f)
            parts = [(a, ()), ("＿＿" if hide else f, ("hl",)), (b, ())]
        elif ex:
            parts = [(ex, ())]
        if c.get("passive") and not hide:
            parts.append(("\n" + c["passive"], ("en",)))
        return parts

    def refresh_status():
        n = deck.counts()
        status.set("Learning %d  ·  Ready for the test %d  ·  Known %d%s" % (
            n.get("learn", 0), n.get("test", 0), n.get("known", 0),
            ("  ·  %d new from this episode" % len(added)) if added else ""))

    def clear_buttons():
        for f in (btn_f, opts_f):
            for w in f.winfo_children():
                w.destroy()
        for w in audio_f.winfo_children():
            if isinstance(w, ttk.Button):
                w.destroy()

    def audio_buttons(c):
        if not c.get("media"):
            note.set("No audio: this word came from a subtitle file without its video.")
            return
        note.set("")
        ttk.Button(audio_f, text="▶ Play the word", command=lambda: say(c)).pack(side="left")
        ttk.Button(audio_f, text="▶ Play the whole line", command=lambda: say(c, True)).pack(side="left", padx=6)

    lock = threading.Lock()

    def prepare(c):
        """Find the word in the line's audio (once), then cut its clip."""
        with lock:
            if not c.get("refined") and c.get("media"):
                rec = _recognizer(download=True, log=lambda m: win.after(0, lambda: note.set(m.strip())))
                if refine(c, rec):
                    deck.save()
            return clip_path(c)

    def say(c, whole=False):
        def run():
            p = clip_path(c, True) if whole else prepare(c)
            if not p:
                win.after(0, lambda: note.set("Couldn't cut the audio (is the video still there?)"))
            elif not play(p):
                win.after(0, lambda: note.set("No sound player found on this computer."))
            else:
                win.after(0, lambda: note.set(""))
        threading.Thread(target=run, daemon=True).start()

    def show_next():
        clear_buttons()
        refresh_status()
        c = sess.next()
        state.update(card=c, right=None)
        answer_l.config(text="")
        if c is None:
            state["phase"] = "empty"
            head.config(text="")
            word_l.config(text="All done for now")
            sub_l.config(text="Convert another episode to add its words, or come back later.")
            set_text([])
            ttk.Button(btn_f, text="Close", command=win.destroy).pack(side="right")
            return
        if c["stage"] == "test":
            return show_test(c)
        state["phase"] = "front"
        head.config(text="What does it mean?  (remembered %d of %d)" % (c.get("streak", 0), LEARN_STEPS))
        word_l.config(text=c["word"])
        sub_l.config(text=kana_of(c) if kana_of(c) != c["word"] else "")
        set_text(example_parts(c, hide=False)[:3])
        audio_buttons(c)
        ttk.Button(btn_f, text="Show answer  (Space)", command=reveal).pack(side="right")
        say(c)

    def reveal():
        c = state["card"]
        if state["phase"] != "front":
            return
        state["phase"] = "back"
        answer_l.config(text=c.get("english", ""))
        set_text(example_parts(c))
        for w in btn_f.winfo_children():
            w.destroy()
        ttk.Button(btn_f, text="Remembered  (2)", command=lambda: grade(True)).pack(side="right")
        ttk.Button(btn_f, text="Failed  (1)", command=lambda: grade(False)).pack(side="right", padx=8)

    def grade(yes):
        c = state["card"]
        if state["phase"] != "back":
            return
        deck.remembered(c, yes)
        sess.done(c, again_after(c, not yes))
        show_next()

    def show_test(c):
        state["phase"] = "test-wait"
        head.config(text="Test: which word fills the gap?")
        word_l.config(text="")
        sub_l.config(text="")
        answer_l.config(text="")
        set_text([("Making a sentence...", ())])
        audio_buttons(c)

        def run():
            got = claude_sentence(c, api_key)
            win.after(0, lambda: put_test(c, got))
        threading.Thread(target=run, daemon=True).start()

    def put_test(c, got):
        if state["card"] is not c:
            return
        if got:
            sentence, form = got
            gap = sentence.replace(form, "＿＿", 1)
            parts = [(gap, ())]
        else:
            gap, found = blank(c.get("example", ""), c)
            parts = [(gap, ())] if found else [("(%s)" % c.get("english", ""), ())]
        parts.append(("\nThe missing word means: %s" % c.get("english", ""), ("en",)))
        set_text(parts)
        picks, right = options(c, pool)
        state.update(phase="test", right=right)
        for i, k in enumerate(picks):
            tk.Button(opts_f, text="%d.  %s" % (i + 1, k), font=("Yu Gothic UI", 18), width=12, relief="groove",
                      bg="#f4f6fb", command=lambda k=k: answer(k)).grid(row=i // 2, column=i % 2, padx=8, pady=6)

    def answer(k):
        c = state["card"]
        if state["phase"] != "test":
            return
        ok = k == state["right"]
        state["phase"] = "tested"
        for b in opts_f.winfo_children():
            t = b.cget("text").split(".  ", 1)[-1]
            b.config(state="disabled", bg="#c8ecd0" if t == state["right"] else ("#f6c6c0" if t == k else "#f4f6fb"))
        deck.tested(c, ok)
        if ok:
            if on_known:
                on_known(c["word"])
            answer_l.config(text="Right! %s is now in Words I know." % c["word"], fg="#1d5c2e")
            sess.done(c)
        else:
            answer_l.config(text="Not quite: it's %s (%s). Back to learning." % (state["right"], c["word"]),
                            fg="#a5281b")
            sess.done(c, again_after(c, True))
        ttk.Button(btn_f, text="Next  (Space)", command=show_next).pack(side="right")

    def key(e):
        ph = state["phase"]
        ch = (e.char or "").lower()
        if e.keysym == "space":
            if ph == "front":
                reveal()
            elif ph in ("tested",):
                show_next()
        elif ch in "12" and ch and ph == "back":
            grade(ch == "2")
        elif ch in "1234" and ch and ph == "test":
            btns = opts_f.winfo_children()
            i = int(ch) - 1
            if i < len(btns):
                answer(btns[i].cget("text").split(".  ", 1)[-1])
        elif ch == "r" and state["card"]:
            say(state["card"])

    def prefetch():
        for c in list(sess.queue[:12]):
            try:
                prepare(c)
            except Exception:
                pass
    threading.Thread(target=prefetch, daemon=True).start()

    win.bind("<Key>", key)
    win.focus_set()
    show_next()
    return win
