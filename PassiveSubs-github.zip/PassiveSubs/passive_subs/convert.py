"""One-call pipeline: video or Japanese subtitle file -> passive-learning romaji .ass file."""
import os
import re
from dataclasses import dataclass, field

from .analyzer import Analyzer, Options
from .glossary import Glossary
from .kana import has_japanese
from .subtitles import get_japanese_subtitles, load_lines
from .writer import write_ass

_glossary = None


def glossary():
    global _glossary
    if _glossary is None:
        _glossary = Glossary()
    return _glossary


@dataclass
class Settings:
    script: str = "romaji"        # romaji | hiragana
    effect: str = "appear"        # appear | wholeline | nofx
    wo: str = "o"
    intro: bool = False
    font_size: int = 20
    names: dict = field(default_factory=dict)  # extra words: {"春香": "HARUKA"}
    use_ai: bool = False
    api_key: str = ""
    show_context: str = ""        # e.g. "My Show episode 1" to help the AI
    output_dir: str = ""          # default: next to the input
    auto_align: bool = True       # line separate subtitle files up with the video's speech
    shift_s: float = 0.0          # extra manual shift in seconds (+ = later)
    known: set = None             # words I know -> shown in Japanese; None = read known_words.txt
    preset: str = "Automatic (from the file name)"  # show name list: automatic, a show's name, or "None"
    name_style: str = "name"      # names as: name HARUKA | both HARUKA (SPRING-FRAGRANCE) | meaning (SPRING-FRAGRANCE)
    ruby: bool = False            # small Japanese pronunciation above each English word


LAST_REPORT = []
LAST_WARNINGS = []  # "these subtitles may not belong to this video" warnings from the last conversion
LAST_UNKNOWN = []   # most frequent words you don't know yet, from the last conversion
LAST_AI_ERROR = []  # why Claude couldn't be used in the last conversion (e.g. the API key is invalid)


def ai_error_text(e):
    """A plain-English reason for an Anthropic API error."""
    name, msg = type(e).__name__, str(e)
    if name == "AuthenticationError" or "invalid x-api-key" in msg:
        return ("The API key is invalid (Anthropic refused it). Copy it again from console.anthropic.com > API Keys: "
                "it starts with sk-ant-.")
    if name == "PermissionDeniedError":
        return "This API key isn't allowed to use Claude (check the key's workspace on console.anthropic.com)."
    if name == "RateLimitError" or "credit balance" in msg:
        return "The API account is out of credit or over its limit (console.anthropic.com > Billing)."
    if name in ("APIConnectionError", "APITimeoutError"):
        return "Couldn't reach Anthropic (no internet connection?)."
    if name == "ModuleNotFoundError":
        return "The anthropic package isn't installed. Run Start.bat again."
    return "%s: %s." % (name, msg[:200])


def check_api_key(key):
    """'' if the key works, otherwise the reason it doesn't (a free call: it only lists the models)."""
    if not key.strip():
        return "No API key entered."
    try:
        import anthropic
        anthropic.Anthropic(api_key=key.strip()).models.list(limit=1)
        return ""
    except Exception as e:
        return ai_error_text(e)


def frequent_unknown(analyzed):
    """Rank the translated words (not names, not words you know) by how often they appear.
    Returns [{'word', 'reading', 'english', 'count', 'example'}], most frequent first."""
    from collections import Counter, defaultdict
    counts, glosses, readings, examples = Counter(), defaultdict(Counter), {}, {}
    for jp_line, syls in analyzed:
        for s in syls:
            if not s.core or s.known or s.name or not has_japanese(s.base or s.jp):
                continue
            w = s.base or s.jp
            counts[w] += 1
            glosses[w][s.core] += 1
            if s.reading and w not in readings:
                readings[w] = s.reading
            examples.setdefault(w, jp_line)
    return [{"word": w, "reading": readings.get(w, ""), "english": glosses[w].most_common(1)[0][0],
             "count": n, "example": examples[w]} for w, n in counts.most_common()]


def fix_line_lookalikes(lines):
    from .kana import fix_lookalikes
    out, swaps = [], []
    for start, end, text in lines:
        t, sw = fix_lookalikes(text)
        out.append((start, end, t))
        swaps.extend(sw)
    return out, swaps


def add_word_times(rows, out_lines, media):
    """Where each word to learn is first said (for the flashcards' audio clips): adds media, start, end
    (the word, ms), line_start, line_end, surface (as written in that line) and passive (the converted line)."""
    from .writer import allocate, allocate_sung
    from .analyzer import syllables_to_plain
    want = {r["word"]: r for r in rows}
    for start, end, syls, jp, sung in out_lines:
        if not want or end <= start or not syls:
            continue
        hit = [i for i, x in enumerate(syls) if x.core and not x.known and not x.name and (x.base or x.jp) in want]
        if not hit:
            continue
        durs = (allocate_sung(syls, start, end, jp, sung) if sung else None) or \
            allocate(syls, max(1, int(round((end - start) / 10))))
        for i in hit:
            w = syls[i].base or syls[i].jp
            r = want.pop(w, None)
            if r is None:
                continue
            t = start + 10 * sum(durs[:i])
            j, d = i + 1, durs[i]
            while j < len(syls) and syls[j].text.startswith("-"):    # its ending: TELL-ru
                d += durs[j]
                j += 1
            moras = sum(x.moras for x in syls[i:j])
            r.update(media=media, start=t, end=t + min(10 * d, 250 + 160 * moras), line_start=start,
                     line_end=end, surface=syls[i].jp, passive=syllables_to_plain(syls), example=jp)


def export_csv(rows, path):
    import csv
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["Japanese", "Reading", "English", "Count", "Example"])
        for r in rows:
            wr.writerow([r["word"], r["reading"], r["english"], r["count"], r["example"]])
VIDEO_EXTS = {".mkv", ".mp4", ".webm", ".avi", ".mov", ".m4v", ".ts", ".flv", ".wmv"}


NAMES_DIR = os.path.join(os.path.dirname(__file__), "data", "names")


MISMATCH = ("The subtitles don't seem to match this video, so the timing (and auto-align) "
            "may not work. ")


def _episode(name):
    """Episode number in a file name: 'Ep 1', 'E01', 'S01E01', '#3', '第3話', ' - 03 ' (None if unclear)."""
    n = os.path.splitext(os.path.basename(name))[0]
    for pat in (r"[Ss]\d+\s*[Ee](\d{1,3})", r"(?i)\bep(?:isode)?\.?\s*(\d{1,3})", r"(?i)(?<![a-z])e(\d{1,3})\b",
                r"第\s*(\d{1,3})\s*[話回]", r"#\s*(\d{1,3})\b", r"\s-\s(\d{1,3})(?:\s|$|[\[(v])"):
        m = re.search(pat, n)
        if m:
            return int(m.group(1))
    return None


def mismatch_warnings(video, sub_path, lines, video_ms):
    """Reasons to think the subtitle file belongs to a different video. [] when it looks fine."""
    out = []
    vname, sname = os.path.basename(video), os.path.basename(sub_path)
    squash = lambda t: re.sub(r"[^a-z0-9]", "", t.lower())
    generic = {"video", "episode", "movie", "anime", "com", "youtube", "web", "raw", "sub", "subs",
               "japanese", "mp4", "mkv", "hevc", "x264", "x265", "aac", "1080p", "720p", "480p", "2160p"}
    vwords = {w for w in re.findall(r"[a-z]{3,}", os.path.splitext(vname)[0].lower()) if w not in generic}
    if vwords:   # only when the video's name says what it is ("video.mp4" says nothing)
        for show in name_presets():
            k = squash(show)
            if k in squash(sname) and k not in squash(vname):
                out.append("The subtitle file's name says %s, but the video's name doesn't." % show)
    ev, es = _episode(vname), _episode(sname)
    if ev is not None and es is not None and ev != es:
        out.append("The video looks like episode %d, but the subtitles look like episode %d." % (ev, es))
    if video_ms and lines:
        sub_end = max(e for _, e, _ in lines)
        sub_start = min(s for s, _, _ in lines)
        span = sub_end - sub_start
        mins = lambda ms: "%d:%02d" % (ms // 60000, ms // 1000 % 60)
        if sub_end > video_ms + 120000 and span > video_ms + 60000:
            out.append("The subtitles run for %s, but the video is only %s long." % (mins(sub_end), mins(video_ms)))
        elif video_ms > 8 * 60000 and span < 0.5 * video_ms:
            out.append("The subtitles only cover %s of this %s video." % (mins(span), mins(video_ms)))
    return out


OLD_DIR = "Old PassiveSubs"


def retire_old_outputs(video, keep=None, log=print, protect=()):
    """Move the PassiveSubs .ass files made earlier for this video into an 'Old PassiveSubs' folder,
    so players (VLC loads every .ass whose name starts with the video's name) only find the new one.
    Nothing is deleted. Returns the moved file names."""
    base = os.path.splitext(os.path.basename(video))[0]
    folder = os.path.dirname(os.path.abspath(video))
    keep = os.path.abspath(keep) if keep else None
    protect = {os.path.abspath(p) for p in protect if p}
    moved = []
    for f in sorted(os.listdir(folder)):
        path = os.path.join(folder, f)
        if not (f.startswith(base + ".Passive") and f.lower().endswith(".ass")) or os.path.abspath(path) == keep:
            continue
        if os.path.abspath(path) in protect:
            log("  Kept %s: it's in the JAPANESE SUBTITLES box." % f)
            continue
        dest_dir = os.path.join(folder, OLD_DIR)
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, f)
        n = 2
        while os.path.exists(dest):
            dest = os.path.join(dest_dir, "%s (%d).ass" % (f[:-4], n))
            n += 1
        try:
            os.replace(path, dest)
            moved.append(f)
        except OSError as e:
            log("  Couldn't move %s (%s). Close VLC and try again." % (f, e))
    if moved:
        log("  Moved %d older subtitle file%s for this video into the '%s' folder: %s"
            % (len(moved), "" if len(moved) == 1 else "s", OLD_DIR, ", ".join(moved)))
    return moved


def name_presets():
    """{'Example Show': path} for the ready-made name lists in data/names."""
    out = {}
    if os.path.isdir(NAMES_DIR):
        for fn in sorted(os.listdir(NAMES_DIR)):
            if fn.endswith(".txt"):
                out[fn[:-4].replace("_", " ")] = os.path.join(NAMES_DIR, fn)
    return out


def preset_keys(show, path):
    """Squashed names a show goes by in file names: its list's name plus any '# also: A, B' line."""
    keys = {re.sub(r"[^a-z0-9]", "", show.lower())}
    try:
        with open(path, encoding="utf-8") as f:
            for l in f:
                m = re.match(r"#\s*also:\s*(.*)", l.strip(), re.I)
                if m:
                    for a in m.group(1).split(","):
                        k = re.sub(r"[^a-z0-9]", "", a.lower()) or a.strip()
                        if len(k) >= 3:
                            keys.add(k)
    except OSError:
        pass
    return keys


def preset_matches_text(preset, text):
    """True when the subtitles themselves use several of a list's names often (a show the file name hides)."""
    hits = {k: text.count(k) for k in preset if len(k) >= 2 and not re.fullmatch(r"[ぁ-ん]+", k)}
    found = [k for k, n in hits.items() if n]
    return len(found) >= 3 and sum(hits.values()) >= 8


def read_preset(path):
    with open(path, encoding="utf-8") as f:
        return "\n".join(l.strip() for l in f if l.strip() and not l.startswith("#"))


def names_from_furigana(furigana, g, long_vowels=False, known=None):
    """Subtitle authors write readings for names: 春香(はるか). Words like that which the
    dictionary doesn't know with that reading are treated as names -> HARUKA.
    A full name gets its two halves: 山田花子(やまだはなこ) -> YAMADA-HANAKO (and 花子 = HANAKO);
    a reading that only covers the end belongs to the end: 佐藤美咲(みさき) -> 美咲 = MISAKI."""
    from .kana import kata_to_hira, to_romaji
    from .tokenizer import get_tagger
    tagger = get_tagger()
    known = {k: v for k, v in (known or {}).items() if re.fullmatch(r"[A-Z-]+", v)}
    out = {}

    def roma(rh):
        r = to_romaji(rh)
        if not long_vowels:
            r = re.sub("ou", "o", r).replace("uu", "u")
        return r.upper()

    def dict_reads(word):
        return {kata_to_hira(r) for _s, rs, _g, _f in (g.d.get(word) or []) for r in rs}

    def readings_of(word):
        rs = set(dict_reads(word))
        if word in furigana:
            rs.add(kata_to_hira(furigana[word].partition("|")[0]))
        try:
            rs.add(kata_to_hira("".join((getattr(t.feature, "kana", "") or "") for t in tagger(word))))
        except Exception:
            pass
        return {r for r in rs if r}

    def is_word(word):
        return word in g.d or word in furigana or word in g.overrides

    for word, reading in furigana.items():
        if word in g.overrides or word in known:
            continue
        reading, _, after = reading.partition("|")
        if after and any(word + after[:n] in g.d for n in (1, 2)):
            continue   # 唆(そそ)る: kanji + okurigana is a verb or adjective, not a name
        if re.search(r"[\u30a1-\u30fa]", reading):
            continue   # 未来(フューチャー): a stylised loanword reading, not a name; keep the word's meaning
        rh = kata_to_hira(reading)
        if word in g.d and (rh.endswith("え") or after.startswith("え")):
            continue   # 痛(いて)えし, 絶対(ぜってえ): rough speech spelled out, not a name
        if rh in dict_reads(word):
            continue   # a normal word the dictionary knows (e.g. 硫酸 りゅうさん)
        if " " in word or "\u3000" in word:
            parts = re.split(r"[ \u3000]+", word)
            pre, suf = "".join(parts[:-1]), parts[-1]
            pr = next((r for r in sorted(readings_of(pre), key=len, reverse=True)
                       if rh.startswith(r) and len(rh) > len(r)), None)
            if pr is None:     # 私立 桜丘(さくらがおか): the reading is only for the last word
                word = suf
                if word in g.overrides or rh in dict_reads(word):
                    continue
            else:              # 鈴木 一郎(すずきいちろう): a full name split by a space
                out[word] = roma(pr) + "-" + roma(rh[len(pr):])
                for w, r in ((pre, pr), (suf, rh[len(pr):])):
                    if w not in g.d and w not in g.overrides:
                        out.setdefault(w, roma(r))
                continue
        cands = []
        for i in (range(len(word) - 1, 1, -1) if len(word) >= 3 else ()):
            pre, suf = word[:i], word[i:]
            if suf[:1] in "ヶ々" or pre[-1:] in "ヶ々":
                continue
            prs = sorted(readings_of(pre), key=len, reverse=True)
            if pre in known:
                kv = re.sub("OU", "O", known[pre].replace("-", "")).replace("UU", "U") if not long_vowels else known[pre]
                prs = [rh[:k] for k in range(1, len(rh)) if roma(rh[:k]) == kv] + prs
            for pr in prs:
                if rh.startswith(pr) and len(rh) > len(pr):
                    if rh[len(pr):] in dict_reads(suf) and pre in g.d and pre not in known:
                        continue   # 神仏 + 混淆: two ordinary words
                    solid = pre in known or is_word(pre) or len(list(tagger(pre))) == 1
                    cands.append((not solid, -i, pre, suf, pr))
                    break
        if cands:
            _x, _i, pre, suf, pr = min(cands)
            sr = rh[len(pr):]
            out[word] = roma(pr) + "-" + roma(sr)
            for w, r in ((pre, pr), (suf, sr)):
                if w not in g.d and w not in g.overrides and w not in known:
                    out.setdefault(w, roma(r))
            continue
        # the reading is only for the end: 東京千代田(ちよだ), 佐藤美咲(みさき)
        done = False
        for i in range(len(word) - 1, 1, -1):
            pre, suf = word[:i], word[i:]
            if suf[:1] in "ヶ々" or not (is_word(pre) or pre in known) or any(rh.startswith(r) for r in readings_of(pre)):
                continue
            if len(rh) <= 2 * len(suf) + 1:
                if rh not in dict_reads(suf) and suf not in g.overrides:
                    out.setdefault(suf, roma(rh))
                done = True
                break
        if done:
            continue
        out[word] = roma(rh)
    return out


def parse_names(text):
    """'春香=HARUKA, 楓=KAEDE' or one per line -> dict."""
    out = {}
    for part in re.split(r"[,\n、;]+", text or ""):
        if "=" in part:
            k, v = part.split("=", 1)
            k, v = k.strip(), v.strip().upper().replace(" ", "-")
            if k and v:
                out[k] = v
    return out


def output_path(src, settings: Settings):
    base = os.path.splitext(os.path.basename(src))[0]
    suffix = {"romaji": "PassiveRomaji", "hiragana": "PassiveHiragana"}[settings.script]
    if settings.effect == "nofx":
        suffix += "_NOFX"
    elif settings.effect == "wholeline":
        suffix += "_WholeLine"
    folder = settings.output_dir or os.path.dirname(os.path.abspath(src))
    return os.path.join(folder, "%s.%s.ass" % (base, suffix))


def convert(src, settings: Settings = None, log=print, progress=None, choose_stream=None, subtitle=None):
    """src: the video (or a subtitle file). subtitle: optional Japanese subtitle file to use instead
    of the video's own track. The output is named after src and saved next to it."""
    settings = settings or Settings()
    src = src or subtitle
    log("Reading %s" % os.path.basename(src))
    if subtitle:
        sub_path, desc = subtitle, "subtitle file %s" % os.path.basename(subtitle)
    else:
        sub_path, desc = get_japanese_subtitles(src, choose_stream=choose_stream)
    log("  Using %s" % desc)
    from .vobsub import is_vobsub
    if sub_path.lower().endswith(".sup") or is_vobsub(sub_path):
        from .ocr import sup_to_srt
        # read once, then reuse: next to a .sup file, or next to the video for a track from inside it
        cache = None if subtitle else os.path.splitext(src)[0] + ".ja.srt"
        sub_path = sup_to_srt(sub_path, settings.api_key, log=log, out=cache,
                              progress=(lambda p: progress(0.3 * p)) if progress else None)
    sung_times, lyrics_report = {}, ""
    from .lyrics import is_lyrics_file
    if is_lyrics_file(sub_path):
        # lyrics mode: a plain .txt of lyrics, timed by listening to the singing in the video
        if os.path.splitext(src)[1].lower() not in VIDEO_EXTS:
            raise RuntimeError("%s looks like plain lyrics with no timing. Add the video too, so the app can "
                               "listen to the singing and time them." % os.path.basename(sub_path))
        from .lyrics import lyrics_to_srt, char_anchors
        # saved in a subfolder so video players don't load it as a second (plain Japanese) subtitle track
        import hashlib
        with open(sub_path, "rb") as f:
            tag = hashlib.sha1(f.read()).hexdigest()[:8]
        cached = os.path.join(os.path.dirname(os.path.abspath(src)), "PassiveSubs lyrics timing",
                              "%s.%s.srt" % (os.path.splitext(os.path.basename(src))[0], tag))
        os.makedirs(os.path.dirname(cached), exist_ok=True)
        if os.path.exists(cached) and os.path.exists(cached + ".times.json") and \
                os.path.getmtime(cached) >= max(os.path.getmtime(sub_path), os.path.getmtime(src)):
            log("  Using the lyrics timing made earlier (%s)" % os.path.basename(cached))
            sub_path = cached
        else:
            sub_path, lyrics_report = lyrics_to_srt(src, sub_path, log=log, out=cached)
        sung_times = char_anchors(sub_path)
        desc = "track (lyrics timed to this video)"   # already matches the video: no auto-align
    elif os.path.exists(sub_path + ".times.json"):    # a lyrics timing file made earlier, given directly
        from .lyrics import char_anchors
        sung_times = char_anchors(sub_path)
        desc = "track (lyrics timed to this video)"
    song, furigana = [], {}
    lines = load_lines(sub_path, song, furigana)
    lines, swaps = fix_line_lookalikes(lines)
    if swaps:
        log("  Fixed %d katakana/kanji lookalike%s (they look the same, e.g. ロ and 口): %s" % (
            len(swaps), "" if len(swaps) == 1 else "s", "; ".join(swaps[:5]) + (" ..." if len(swaps) > 5 else "")))
    log("  %d Japanese lines found" % len(lines))
    g = glossary()
    # a ready-made name list whose show name is in the file name (e.g. "Example Show Ep 1.srt")
    found = {}
    key = re.sub(r"[^a-z0-9]", "", (os.path.basename(src) + " " + os.path.basename(sub_path)).lower())
    names_raw = (os.path.basename(src) + " " + os.path.basename(sub_path)).lower()
    all_text = "\n".join(t for _s, _e, t in lines)
    for show, path in name_presets().items():
        chosen = settings.preset == show
        if show.lower().startswith("example") and not chosen:
            continue   # the example list is a template: only used when picked by hand
        auto = settings.preset.startswith("Automatic")
        by_name = any(k in key or k in names_raw for k in preset_keys(show, path))
        preset = parse_names(read_preset(path))
        by_text = auto and not by_name and preset_matches_text(preset, all_text)
        if chosen or (auto and (by_name or by_text)):
            found.update({k: v for k, v in preset.items() if k not in settings.names})
            log("  Using the %s name list%s" % (show, "" if chosen else (" (from the file name)" if by_name
                                                                          else " (its names are in these subtitles)")))
            if chosen and re.sub(r"[^a-z0-9]", "", show.lower()) not in key:
                log("  Note: the file names don't mention %s. Set 'Character names' to Automatic for other shows."
                    % show)
    furi = names_from_furigana(furigana, g, known=found)
    found.update({k: v for k, v in furi.items() if k not in found and k not in settings.names})
    if furi:
        log("  Names found from the subtitles' readings: " + ", ".join("%s=%s" % kv for kv in furi.items()))
    LAST_REPORT.clear()
    LAST_AI_ERROR.clear()
    if lyrics_report:
        LAST_REPORT.append(lyrics_report)
    LAST_WARNINGS.clear()

    # subtitles that didn't come from inside this video may be timed for a different release
    is_video = os.path.splitext(src)[1].lower() in VIDEO_EXTS
    from_inside = desc.startswith("track")
    warn = []
    if is_video and not from_inside:
        try:
            from .subtitles import video_duration_ms
            warn = mismatch_warnings(src, sub_path, lines, video_duration_ms(src))
        except Exception as e:
            log("  Couldn't check the video's length (%s)" % e)
    if settings.auto_align and is_video and not from_inside:
        from .sync import auto_align
        try:
            n_before = len(lines)
            lines, report, info = auto_align(src, lines, log=log, song_flags=song)
            log("  " + report)
            LAST_REPORT.append(report)
            if n_before and info.get("dropped", 0) > 0.2 * n_before:
                warn.append("Auto-align had to remove %d of %d lines because they didn't fit the video."
                            % (info["dropped"], n_before))
            segs = info.get("segments", [])
            # Pieces whose shifts differ by under 1.5 s are the same piece with jitter (fast talk, a placeholder
            # intro before everything): only real jumps count. The right subtitles need 1-3 (a cut opening...).
            pieces = 1 + sum(1 for a, b in zip(segs, segs[1:]) if abs(a["offset_ms"] - b["offset_ms"]) >= 1500)
            n_seg_lines = sum(sg["last"] - sg["first"] + 1 for sg in segs) or 1
            main = max((sum(t["last"] - t["first"] + 1 for t in segs
                            if abs(t["offset_ms"] - sg["offset_ms"]) < 1500) for sg in segs), default=0)
            if pieces >= 6 and main < 0.6 * n_seg_lines:
                warn.append("Auto-align had to cut the subtitles into %d pieces to fit this video's speech."
                            % pieces)
            if not info.get("confident", True) and warn:
                warn.append("Auto-align couldn't find a clear match with the speech in the video.")
        except Exception as e:
            log("  Auto-align skipped (%s: %s)" % (type(e).__name__, e))
    if warn:
        msg = MISMATCH + "Check you picked the right subtitle file.\n- " + "\n- ".join(warn)
        log("  WARNING: " + msg.replace("\n", "\n    "))
        LAST_WARNINGS.append(msg)
    if settings.shift_s:
        d = int(round(settings.shift_s * 1000))
        lines = [(max(0, s + d), e + d, t) for s, e, t in lines if e + d > 0]
        msg = "Shifted all subtitles by %+.2f s (your setting)" % settings.shift_s
        log("  " + msg)
        LAST_REPORT.append(msg)

    g.set_session_words({**found, **settings.names})
    from .glossary import parse_known, load_known_text
    known = settings.known if settings.known is not None else parse_known(load_known_text())
    if known:
        log("  Words you know (kept in Japanese): %d" % len(known))
    romaji_name = re.compile(r"^(?:[KGSZTDNHBPMYRWFJCV]{0,3}[AIUEO]|N|-)+$")
    name_keys = {k for k, v in {**g.permanent, **found, **settings.names}.items()
                 if romaji_name.match(v.split("|")[0].strip(" -")) and len(v) > 2}
    an = Analyzer(g, Options(script=settings.script, wo=settings.wo, known=frozenset(known),
                             name_style=settings.name_style, name_keys=frozenset(name_keys)))
    from . import tokenizer
    log("  Word splitter: %s" % tokenizer.ENGINE)
    analyzed = []
    for i, (start, end, text) in enumerate(lines):
        analyzed.append((text, an.analyze(text)))
        if progress and i % 25 == 0:
            progress(i / len(lines) * (0.5 if settings.use_ai else 1.0))

    if settings.use_ai:
        log("  Asking Claude for context-aware translations...")
        from .ai_gloss import AIGlosser
        try:
            ai = AIGlosser(settings.api_key, log=log, show_context=settings.show_context)
            ai.improve(analyzed, progress=(lambda d, n: progress(0.5 + 0.5 * d / n)) if progress else None)
        except Exception as e:
            LAST_AI_ERROR[:] = [ai_error_text(e)]
            log("  AI translation unavailable: %s Using the offline dictionary." % LAST_AI_ERROR[0])

    from .ai_gloss import check_format
    n = check_format(analyzed)
    log("  Format check: %s" % ("all lines OK" if not n else "tidied %d words" % n))

    LAST_UNKNOWN[:] = frequent_unknown(analyzed)
    if LAST_UNKNOWN:
        log("  Most frequent words you don't know yet: " + ", ".join(
            "%s %s (%d)" % (r["word"], r["english"], r["count"]) for r in LAST_UNKNOWN[:8]))

    if settings.ruby:
        from .analyzer import add_ruby
        for _jp, syls in analyzed:
            add_ruby(syls, an.tagger, settings.script)
    out_lines = [(s, e, syls, jp, sung_times.get(s)) for (s, e, _), (jp, syls) in zip(lines, analyzed)]
    add_word_times(LAST_UNKNOWN, out_lines, src if os.path.splitext(src)[1].lower() in VIDEO_EXTS else "")
    out = output_path(src, settings)
    write_ass(out, out_lines, effect=settings.effect,
              title=os.path.splitext(os.path.basename(src))[0], intro=settings.intro,
              font_size=settings.font_size, ruby=settings.ruby)
    if os.path.splitext(src)[1].lower() in VIDEO_EXTS and os.path.dirname(os.path.abspath(out)) == \
            os.path.dirname(os.path.abspath(src)):
        try:
            retire_old_outputs(src, keep=out, log=log, protect=[subtitle])
        except OSError as e:
            log("  Couldn't tidy older subtitle files (%s)" % e)
    if progress:
        progress(1.0)
    log("  Saved %s" % out)
    return out


def main(argv=None):
    import argparse
    p = argparse.ArgumentParser(description="Convert Japanese subtitles (or a video with them) into "
                                            "passive-learning romaji karaoke subtitles (.ass).")
    p.add_argument("inputs", nargs="+", help="video files (.mkv/.mp4) or subtitle files (.ass/.srt/.vtt)")
    p.add_argument("--hiragana", action="store_true", help="write grammar in hiragana instead of romaji")
    p.add_argument("--effect", choices=["appear", "wholeline", "nofx"], default="appear")
    p.add_argument("--wo", choices=["o", "wo"], default="o", help="how to write the particle を")
    p.add_argument("--names", default="", help='extra words, e.g. "春香=HARUKA, 楓=KAEDE"')
    p.add_argument("--no-intro", action="store_true", help=argparse.SUPPRESS)   # the default now
    p.add_argument("--intro", action="store_true", help="add the explanation lines at the start")
    p.add_argument("--ai", action="store_true", help="use Claude for context-aware glosses (needs ANTHROPIC_API_KEY)")
    p.add_argument("--context", default="", help="show name to help the AI, e.g. 'My Show ep 1'")
    p.add_argument("-o", "--output-dir", default="")
    p.add_argument("--subs", default="", help="Japanese subtitle file to use with the video")
    p.add_argument("--no-align", action="store_true", help="don't auto-align --subs to the video's audio")
    p.add_argument("--known", default=None, help='words you know, kept in Japanese, e.g. "猫 食べる" '
                                                 '(default: your saved Words I know list)')
    p.add_argument("--words-csv", default="", help="also save the most frequent unknown words to this CSV")
    p.add_argument("--names-as", choices=["name", "both", "meaning"], default="name",
                   help="names as KAEDE, KAEDE (MAPLE), or just (MAPLE)")
    p.add_argument("--ruby", action="store_true", help="small Japanese pronunciation above each English word")
    p.add_argument("--shift", type=float, default=0.0, help="extra shift in seconds (+ = later)")
    a = p.parse_args(argv)
    st = Settings(script="hiragana" if a.hiragana else "romaji", effect=a.effect, wo=a.wo,
                  intro=a.intro and not a.no_intro, names=parse_names(a.names), use_ai=a.ai,
                  api_key=os.environ.get("ANTHROPIC_API_KEY", ""), show_context=a.context,
                  output_dir=a.output_dir, auto_align=not a.no_align, shift_s=a.shift,
                  name_style=a.names_as, ruby=a.ruby)
    if a.known is not None:
        from .glossary import parse_known
        st.known = parse_known(a.known)
    for f in a.inputs:
        convert(f, st, subtitle=a.subs or None)
        if a.words_csv:
            export_csv(LAST_UNKNOWN, a.words_csv)


if __name__ == "__main__":
    main()
