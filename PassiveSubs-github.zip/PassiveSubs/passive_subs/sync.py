"""Automatic subtitle-to-video alignment.

1. Listen to the video's audio and estimate, every 0.1 s, how much it sounds like speech
   (energy in the voice band that flickers at syllable rate, which music and silence don't do).
2. Score every possible time shift for every subtitle line by how much speech it would cover.
3. Pick the best shift per stretch of lines with dynamic programming. A new stretch may start
   anywhere (costing a penalty), which handles cut intros/openings/bumpers, not just one offset.
4. Lines that end up outside the video are removed.
"""
import subprocess
import os

import numpy as np

from .subtitles import ffmpeg_exe

SR = 8000           # audio sample rate used for analysis
HOP = 80            # 10 ms analysis hop
FPS = 10            # alignment resolution: 0.1 s
MAX_SHIFT_S = 600   # look up to 10 minutes either way
SMALL_SEGMENT = 15  # stretches shorter than this many lines must clearly beat staying with their neighbours


def _no_window():
    return {"creationflags": 0x08000000} if os.name == "nt" else {}


def load_audio(video):
    cmd = [ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-i", video, "-vn", "-ac", "1",
           "-ar", str(SR), "-f", "s16le", "-"]
    p = subprocess.run(cmd, capture_output=True, **_no_window())
    if p.returncode != 0 or not p.stdout:
        raise RuntimeError("could not read the video's audio: " + p.stderr.decode("utf-8", "replace")[-300:])
    return np.frombuffer(p.stdout, dtype=np.int16).astype(np.float32) / 32768.0


def speech_curve(audio):
    """Speech-likeness per 0.1 s frame, z-normalised (positive = probably speech)."""
    win = 200  # 25 ms
    n = (len(audio) - win) // HOP
    if n <= 0:
        return np.zeros(1, dtype=np.float32)
    freqs = np.fft.rfftfreq(win, 1.0 / SR)
    band = (freqs >= 300) & (freqs <= 3400)
    window = np.hanning(win).astype(np.float32)
    env = np.empty(n, dtype=np.float32)
    flat = np.empty(n, dtype=np.float32)
    chunk = 20000
    for s in range(0, n, chunk):
        idx = np.arange(s, min(n, s + chunk))[:, None] * HOP + np.arange(win)[None, :]
        spec = np.abs(np.fft.rfft(audio[idx] * window, axis=1)) ** 2
        b = spec[:, band] + 1e-10
        env[s:s + len(b)] = np.log(b.sum(axis=1))
        # spectral flatness in the voice band: speech is peaky (harmonics), noise is flat
        flat[s:s + len(b)] = np.exp(np.log(b).mean(axis=1)) / b.mean(axis=1)
    # Speech loudness rises and falls 2-8 times a second (syllables). Music and noise don't
    # concentrate their envelope changes there. Measure that over 1 s windows every 0.1 s.
    lin = np.sqrt(np.exp(env - env.max()))
    m = (len(lin) - 100) // 10
    if m <= 0:
        return np.zeros(1, dtype=np.float32)
    idx = np.arange(m)[:, None] * 10 + np.arange(100)[None, :]
    w = lin[idx]
    w = w - w.mean(axis=1, keepdims=True)
    P = np.abs(np.fft.rfft(w * np.hanning(100), axis=1)) ** 2     # bins are 1 Hz apart
    syll = P[:, 2:9].sum(axis=1)
    allm = P[:, 1:51].sum(axis=1) + 1e-12
    ratio = syll / allm
    # local loudness relative to the background of the surrounding ~10 s
    lw = env[idx].mean(axis=1)
    kern = np.ones(100, dtype=np.float32) / 100
    bg = np.convolve(lw, kern, mode="same")
    rel = np.clip(lw - bg + 1.0, 0, None)
    fl = flat[idx].mean(axis=1)
    s10 = ratio * rel * (1.0 - fl)
    pad = np.zeros(5, dtype=np.float32)
    s10 = np.concatenate([pad, s10])   # window centre alignment (0.5 s)
    s10 = (s10 - s10.mean()) / (s10.std() + 1e-9)
    return s10.astype(np.float32)


def align(lines, curve, split_penalty=None, max_shift_s=MAX_SHIFT_S):
    """lines: [(start_ms, end_ms, ...)] sorted by start. Returns (offsets_ms per line, info)."""
    n = len(lines)
    T = len(curve)
    M = int(max_shift_s * FPS)
    offs = np.arange(-M, M + 1)
    C = np.concatenate([[0.0], np.cumsum(curve, dtype=np.float64)])
    starts = np.array([int(l[0] / 100) for l in lines])
    ends = np.array([max(int(l[1] / 100), int(l[0] / 100) + 1) for l in lines])
    # L[i, o]: speech covered by line i shifted by offs[o]; out-of-video parts score a small penalty
    S = starts[:, None] + offs[None, :]
    E = ends[:, None] + offs[None, :]
    Sc, Ec = np.clip(S, 0, T), np.clip(E, 0, T)
    L = (C[Ec] - C[Sc]) - 0.3 * ((E - S) - (Ec - Sc))
    if split_penalty is None:
        split_penalty = 3.0 * float(np.median(ends - starts))  # ~ three well-matched lines
    # Dynamic programming over lines: each line keeps the previous line's shift, or jumps to a new
    # one (paying split_penalty). A jump may not put a line before the end of the previous line,
    # so the subtitles stay in order: a cut can only happen in a gap between lines.
    K = len(offs)
    ar = np.arange(K)
    tol = 2 * FPS
    dp = L[0].copy()
    choice = np.zeros((n, K), dtype=np.int32)
    choice[0] = ar
    for i in range(1, n):
        gap = int(starts[i] - ends[i - 1])
        pm = np.maximum.accumulate(dp)
        am = np.maximum.accumulate(np.where(dp >= pm, ar, 0))
        lim = np.clip(ar + gap + tol, 0, K - 1)
        jump_val = pm[lim] - split_penalty
        use_jump = jump_val > dp
        choice[i] = np.where(use_jump, am[lim], ar)
        dp = np.where(use_jump, jump_val, dp) + L[i]
    o = int(np.argmax(dp))
    path = np.empty(n, dtype=np.int64)
    for i in range(n - 1, -1, -1):
        path[i] = o
        o = choice[i][o]
    off_ms = offs[path] * 100
    # report
    zero = M
    covered_before = float(sum(L[i, zero] for i in range(n)))
    covered_after = float(sum(L[i, path[i]] for i in range(n)))
    segs = []
    for i in range(n):
        if not segs or segs[-1]["offset_ms"] != int(off_ms[i]):
            segs.append({"offset_ms": int(off_ms[i]), "first": i, "last": i})
        else:
            segs[-1]["last"] = i
    # tiny segments are usually noise: merge segments of < 3 lines into a neighbour
    merged = []
    for sg in segs:
        if merged and sg["last"] - sg["first"] < 2:
            merged[-1]["last"] = sg["last"]
        else:
            merged.append(sg)
    if len(merged) > 1 and merged[0]["last"] - merged[0]["first"] < 2:
        merged[1]["first"] = 0
        merged.pop(0)
    # A short stretch that jumps away from its neighbours needs strong evidence. Singing (an opening or
    # ending song) looks like speech to the detector, so a few lines can be pulled onto a song by mistake
    # (seen in testing: a few lines were pulled 46 s back onto the opening song).
    def seg_score(sg, o_ms):
        k = int(o_ms // 100) + M
        if not 0 <= k < K:
            return -1e9
        return float(L[sg["first"]:sg["last"] + 1, k].sum())
    for j, sg in enumerate(merged):
        if sg["last"] - sg["first"] + 1 >= SMALL_SEGMENT:
            continue
        nbs = {merged[q]["offset_ms"] for q in (j - 1, j + 1) if 0 <= q < len(merged)} - {sg["offset_ms"]}
        if not nbs:
            continue
        base = max(nbs, key=lambda o: seg_score(sg, o))
        if sg["offset_ms"] != 0 and seg_score(sg, 0) > seg_score(sg, base) + split_penalty:
            base = 0      # "no change" fits clearly better than following the neighbours
        if seg_score(sg, sg["offset_ms"]) - seg_score(sg, base) < 3 * split_penalty:
            sg["offset_ms"] = base
    joined = []
    for sg in merged:
        if joined and joined[-1]["offset_ms"] == sg["offset_ms"]:
            joined[-1]["last"] = sg["last"]
        else:
            joined.append(sg)
    merged = joined
    off_ms = np.empty(n, dtype=np.int64)
    for sg in merged:
        off_ms[sg["first"]: sg["last"] + 1] = sg["offset_ms"]
    covered_after = float(sum(L[i, int(off_ms[i] // 100) + M] for i in range(n)))
    gain = covered_after - covered_before
    info = {"segments": merged, "gain": gain,
            "confident": gain > 0.5 * split_penalty or all(abs(s["offset_ms"]) < 300 for s in merged)}
    return off_ms.tolist(), info


def auto_align(video, lines, log=print, song_flags=None):
    """Shift lines to match the video's speech. Returns (new_lines, report_text, info).

    Song lyrics (song_flags) aren't used for matching: they follow the dialogue around them, and
    are removed when they sit in a part of the video that was cut (e.g. a missing opening)."""
    log("  Listening to the video's audio to line the subtitles up...")
    audio = load_audio(video)
    dur_ms = int(len(audio) / SR * 1000)
    curve = speech_curve(audio)
    song = list(song_flags) if song_flags and len(song_flags) == len(lines) else [False] * len(lines)
    talk_idx = [i for i in range(len(lines)) if not song[i]]
    if len(talk_idx) < 5:  # almost everything is "song": don't trust the flags
        talk_idx, song = list(range(len(lines))), [False] * len(lines)
    talk_offsets, info = align([lines[i] for i in talk_idx], curve)
    offsets = [None] * len(lines)
    for k, i in enumerate(talk_idx):
        offsets[i] = talk_offsets[k]
    cut_songs = 0
    for i in range(len(lines)):
        if offsets[i] is not None:
            continue
        prev = next((offsets[j] for j in range(i - 1, -1, -1) if not song[j]), None)
        nxt = next((offsets[j] for j in range(i + 1, len(lines)) if not song[j]), None)
        if prev is not None and nxt is not None and nxt < prev - 2000:
            offsets[i] = "cut"   # lyrics inside a stretch the video doesn't have (e.g. its opening)
            cut_songs += 1
        else:
            offsets[i] = prev if prev is not None else (nxt or 0)
    out, dropped = [], 0
    for (s, e, *rest), o in zip(lines, offsets):
        if o == "cut":
            dropped += 1
            continue
        s2, e2 = s + o, e + o
        if e2 <= 0 or s2 >= dur_ms:
            dropped += 1
            continue
        out.append((max(0, s2), min(e2, dur_ms), *rest))
    parts = []
    for sg in info["segments"]:
        a, b = talk_idx[sg["first"]], talk_idx[sg["last"]]
        sec = sg["offset_ms"] / 1000.0
        what = "no change" if sg["offset_ms"] == 0 else ("moved %+.1f s" % sec)
        parts.append("lines %d-%d %s" % (a + 1, b + 1, what))
    report = "Auto-align: " + "; ".join(parts)
    if dropped:
        report += "; removed %d line%s not in this video" % (dropped, "" if dropped == 1 else "s")
        if cut_songs:
            report += " (incl. %d song line%s from a cut part)" % (cut_songs, "" if cut_songs == 1 else "s")
    if not info["confident"]:
        report += ". Low confidence: check it in VLC and adjust with 'Shift subtitles' if needed"
    info.update(dropped=dropped, video_ms=dur_ms)
    return out, report, info
