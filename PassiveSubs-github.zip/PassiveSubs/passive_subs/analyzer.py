"""Turn a Japanese subtitle line into passive-learning karaoke syllables.

Style (from the hand-made examples):
  * Japanese word order is kept.
  * Meaning-carrying words (kanji / katakana / content words) become UPPERCASE English.
  * Grammar (particles, auxiliaries, conjugation endings) stays as lowercase romaji
    (or hiragana in hiragana mode).
  * Conjugation endings attach to their word with a dash:  DECIDE-ta,  CHEERING-shi-te-iru
  * Every piece is its own karaoke syllable, so the line lights up as it is spoken.
"""
from dataclasses import dataclass
import re

from .tokenizer import get_tagger, _tok

from .glossary import format_gloss
from .kana import (has_kanji, has_katakana, has_japanese, is_hiragana_only, kata_to_hira, hira_to_kata,
                   mora_count, punct_to_ascii, to_romaji, KANJI_RE)

CONTENT_POS = {"名詞", "動詞", "形容詞", "副詞", "代名詞", "連体詞", "接続詞", "形状詞"}
# Words that stay lowercase romaji when written in kana (grammar-like / very common)
KANA_KEEP = {"為る", "呉れる", "仕舞う", "貰う", "物", "事", "様", "訳", "筈", "然う", "矢っ張り",
             "斯う", "如何", "一寸", "置く", "上げる", "遣る", "頂く", "下さる", "為さる", "御座る",
             "ちゃう", "じゃう", "とく", "とる", "てる", "もの", "こと", "ところ", "所", "方", "的"}
# Kana-written words that still get translated (they carry real meaning)
KANA_TRANSLATE = {"すべて", "とても", "成る", "有る", "居る", "来る", "行く", "見る", "言う", "良い", "無い", "分かる",
                  "凄い", "駄目", "皆", "未だ", "もう", "又", "全然", "本当", "大丈夫", "一緒"}
# kana words that stay as sounds even though the dictionary has them (grammar, very general words)
E_TO_U = {"え": "う", "け": "く", "げ": "ぐ", "せ": "す", "て": "つ", "ね": "ぬ", "べ": "ぶ", "め": "む", "れ": "る"}
# words the original creator's files leave as sounds (e.g. suki and yappari are kept as sounds)
KEEP_SOUND = {"好き", "すき", "やっぱり", "やっぱ", "矢っ張り", "なん", "まあ", "そりゃ", "こりゃ", "モノ", "クセ", "わっ",
              "やっぱし"}
PREFIX_GLOSS = {"元": "FORMER", "本": "THIS", "前": "FORMER", "現": "CURRENT", "新": "NEW", "旧": "OLD"}
# glosses for tokens the splitter fix-up relabels (see Analyzer._fix_tokens)
SPECIAL_GLOSS = {"もう+数": "MORE", "どうも+": "SOMEHOW", "以上+": "SINCE"}
KANA_GRAMMAR = {"とき", "ため", "まま", "うち", "ほう", "ほど", "くらい", "ぐらい", "はず", "わけ", "よう", "そう",
                "みたい", "なか", "あと", "ごと", "こと", "もの", "もん", "ところ", "とこ", "できる", "いる", "ある",
                "する", "なる", "おる", "くる", "いく", "みる", "しまう", "くれる", "くださる", "もらう", "あげる",
                "やる", "おく", "いう", "いい", "よい", "ない", "すぎる", "つもり", "たち", "がる", "らしい",
                "っぽい", "やすい", "にくい", "づらい", "ほしい", "いただく", "ござる", "たまえ", "たまる",
                "ちゃう", "じゃう", "ちまう", "おいて", "かけ", "ばかり", "だけ", "なんか", "なんて", "やつ",
                "あれ", "これ", "それ", "どれ", "ここ", "そこ", "あそこ", "どこ", "こちら", "そちら", "あちら",
                "みんな", "いける", "いかん", "とおり", "なれる", "いたい", "いたむ", "なさる", "おかげ", "おる", "いれる", "まじ", "ちょい", "しれる", "しれない", "かねる", "すむ", "ちゃん", "まくる", "いただける"}
HONORIFICS = {"さん", "様", "ちゃん", "君", "殿", "氏", "先輩", "達", "たち", "ら", "共", "め", "どの",
              "さま", "くん", "ども", "っち", "たん", "ぴょん", "等"}
# counters that the dictionary glues to the next word after a number: 5年越し -> 5-YEAR THROUGHOUT
COUNTERS = {"年": ("YEAR", 2), "日": ("DAY", 2), "回": ("TIME", 2), "人": ("PERSON", 2), "ヶ月": ("MONTH", 3),
            "か月": ("MONTH", 3), "カ月": ("MONTH", 3), "月": ("MONTH", 2), "時間": ("HOUR", 3),
            "分": ("MINUTE", 2), "秒": ("SECOND", 2), "週間": ("WEEK", 3), "歳": ("YEARS-OLD", 2),
            "才": ("YEARS-OLD", 2), "億": ("HUNDRED-MILLION", 2), "万": ("TEN-THOUSAND", 2), "年生": ("YEAR-STUDENT", 3),
            "回生": ("YEAR-STUDENT", 3), "号室": ("ROOM", 4), "度": ("TIME", 1),
            "倍": ("TIMES-AS-MUCH", 2), "つ": ("THING", 1), "話": ("EPISODE", 1), "首": ("POEM", 2),
            "泊": ("NIGHT", 2), "点": ("POINT", 2), "階": ("FLOOR", 2), "番": ("NUMBER", 2), "人分": ("SERVINGS", 3),
            "号機": ("UNIT", 3), "丁": ("ORDER", 2)}
# Counters with no English word (flat things, long things, animals...): kept as their sound,
# 銅貨10枚 -> COPPER-COIN 10-mai, so you hear and learn the counter itself.
SOUND_COUNTERS = {"枚": "マイ", "本": "ホン", "匹": "ヒキ", "個": "コ", "杯": "ハイ", "冊": "サツ", "台": "ダイ",
                  "着": "チャク", "軒": "ケン", "羽": "ワ", "頭": "トウ", "粒": "ツブ", "足": "ソク", "通": "ツウ",
                  "隻": "セキ", "名": "メイ", "件": "ケン", "品": "ヒン", "切れ": "キレ", "体": "タイ", "発": "ハツ",
                  "機": "キ", "基": "キ", "艘": "ソウ", "脚": "キャク", "膳": "ゼン", "錠": "ジョウ", "缶": "カン"}
COUNTER_TAIL = {"越し": ("THROUGHOUT", 2), "間": ("PERIOD", 2), "後": ("LATER", 2), "前": ("BEFORE", 2),
                "中": ("THROUGHOUT", 2), "ぶり": (None, 2), "目": (None, 1), "ごし": ("THROUGHOUT", 2)}

KANJI_ONLY = re.compile(r"[\u3400-\u9fff々]+")
CONJ_PARTICLES = {"て", "で", "ば", "ちゃ", "じゃ", "ても", "でも", "たり", "だり", "つつ", "ちゃあ"}
# Suffix glosses that differ from the stand-alone meaning: (lemma, reading) or lemma -> gloss
SUFFIX_GLOSS = {("中", "チュウ"): "IN-PROGRESS", ("中", "ジュウ"): "THROUGHOUT", "生": "STUDENT",
                "年": "YEAR", "人": "PERSON", "的": "LIKE", "目": "TH", "回": "TIMES", "歳": "YEARS-OLD",
                "時": "OCLOCK", "分": "MINUTE", "月": "MONTH", "日": "DAY", "円": "YEN", "屋": "SHOP",
                "家": "FAMILY", "性": "NATURE", "化": "IZATION", "者": "PERSON", "部": "CLUB",
                "式": "STYLE", "製": "MADE", "語": "LANGUAGE", "後": "AFTER", "前": "BEFORE",
                "間": "INTERVAL", "以上": "OR-MORE", "以下": "OR-LESS", "頃": "AROUND", "っぽい": "ISH",
                "流": "STYLE", "弁": "DIALECT"}
NUMBERS = {"一": "ONE", "二": "TWO", "三": "THREE", "四": "FOUR", "五": "FIVE", "六": "SIX",
           "七": "SEVEN", "八": "EIGHT", "九": "NINE", "十": "TEN", "百": "HUNDRED",
           "千": "THOUSAND", "万": "TEN-THOUSAND", "億": "HUNDRED-MILLION", "兆": "TRILLION",
           "零": "ZERO", "何": "WHAT"}


@dataclass
class Syl:
    text: str           # what is displayed for this karaoke syllable
    moras: int          # rough spoken length, used to estimate timing
    space: bool = True  # space after (end of a word)
    core: str = ""      # the UPPERCASE English part (empty for grammar pieces)
    jp: str = ""        # the Japanese it came from
    known: bool = False # a word from "Words I know", shown in Japanese
    base: str = ""      # dictionary form (食べる for 食べ), for the word-frequency list
    reading: str = ""   # hiragana reading of the dictionary form
    name: bool = False  # a person / place name (left out of the word-frequency list)
    ruby: str = ""      # small pronunciation shown above the English word (add_ruby)
    yomi: str = ""      # hiragana reading of jp, from the word splitter (yomi_jp = the jp it belongs to)
    yomi_jp: str = ""
    cut: int = 0        # kana at the end of jp that the next syllable shows (伝える -> TELL-ru: 1)


@dataclass
class Options:
    script: str = "romaji"          # "romaji" or "hiragana" for the untranslated parts
    wo: str = "o"                   # how to write the particle を in romaji ("o" or "wo")
    name_long_vowels: bool = False  # HARUKAA vs HARUKA for names
    known: frozenset = frozenset()  # words the learner knows: shown in Japanese (猫) instead of English
    name_style: str = "name"        # names as: "name" HARUKA | "both" HARUKA (SPRING-FRAGRANCE) | "meaning" (SPRING-FRAGRANCE)
    name_keys: frozenset = frozenset()  # names-list entries that are names (not custom English words)


def _f(w, name):
    if w is None:
        return ""
    v = getattr(w.feature, name, None)
    return "" if v in (None, "*") else v


def expand_known(words, tagger):
    """The learner types words as they know them (やめて, 助けて, ごめんなさい). Returns
    (forms, phrases, notes): forms = word forms matched token by token, including the dictionary form
    of a conjugated verb/adjective (やめて -> やめる, so やめた, やめない ... all match); phrases = multi-word
    entries matched as written (ごめんなさい, お兄さん); notes = {word: how it will be matched}."""
    forms, phrases, notes = set(), [], {}
    for w in words:
        forms.update((w, kata_to_hira(w), hira_to_kata(w)))
        toks = tagger(w)
        if not toks:
            continue
        f0 = toks[0].feature
        base = _f(toks[0], "orthBase") or toks[0].surface
        rest_grammar = all(_f(t, "pos1") in ("助詞", "助動詞") or
                           (_f(t, "pos1") == "動詞" and _f(t, "pos2") == "非自立可能") for t in toks[1:])
        if len(toks) == 1 or (_f(toks[0], "pos1") in ("動詞", "形容詞") and rest_grammar):
            for v in (_f(toks[0], "lemma"), base, toks[0].surface if len(toks) == 1 else ""):
                if v:
                    forms.update((v, kata_to_hira(v), hira_to_kata(v)))
            if base != w and _f(toks[0], "pos1") in ("動詞", "形容詞"):
                notes[w] = "every form of " + base
        else:
            phrases.append(w)
            notes[w] = "as written"
    return forms, phrases, notes


# Rough, casual speech where the ending melts into "ee" (うるさい -> うるせえ, すごい -> すげえ). The tokenizer
# can't read these, so they're matched first: (start, melted ending, dictionary word, gloss).
# Shown as the word's meaning plus the spoken ending: うるせえ -> NOISY-see, すげえ -> INCREDIBLE-gee.
CASUAL = [
    (r"(?:うるっ|うる|うっ|るっ|ウル|ウッ)", r"せ[えぇー]+", "うるさい", "NOISY"),
    (r"(?:すっ|す)", r"げ[えぇー]+", "凄い", "INCREDIBLE"),
    (r"(?:やっ|や)", r"べ[えぇー]+", "やばい", "DANGEROUS"),
    (r"(?:でっ|で)", r"け[えぇー]+", "でかい", "HUGE"),
    (r"ち", r"げ[えぇー]+", "違う", "DIFFERENT"),
    (r"(?:おっ|お)", r"せ[えぇー]+", "遅い", "SLOW"),
    (r"(?:いっ|い)", r"て[えぇー]+", "痛い", "PAINFUL"),
    (r"痛", r"[えぇー]+", "痛い", "PAINFUL"),
    (r"こ", r"え[えぇー]+", "怖い", "SCARY"),
    (r"あぶ", r"ね[えぇー]+", "危ない", "DANGEROUS"),
    (r"きた", r"ね[えぇー]+", "汚い", "DIRTY"),
    (r"く", r"せ[えぇー]+", "臭い", "STINKY"),
    (r"う", r"め[えぇー]+", "うまい", "DELICIOUS"),
    (r"つ", r"え[えぇー]+", "強い", "STRONG"),
    (r"よ", r"え[えぇー]+", "弱い", "WEAK"),
    (r"おもし", r"れ[えぇー]+", "面白い", "INTERESTING"),
    (r"つま", r"んね[えぇー]+", "つまらない", "BORING"),
    (r"わか", r"んね[えぇー]+", "分かる", "UNDERSTAND"),
    (r"(?:しょうが|しゃあ)", r"ね[えぇー]+", "しょうがない", "NO-CHOICE"),
    (r"しかた", r"ね[えぇー]+", "仕方ない", "NO-CHOICE"),
    (r"つめて", r"[えぇー]+", "冷たい", "COLD"),
    (r"ひで", r"[えぇー]+", "酷い", "TERRIBLE"),
    (r"唆", r"(?:る|った|られる|ら)", "唆る", "EXHILARATING"),
    (r"(?:ヤバ|やば)", r"(?:くね|く|かった|すぎ|い)", "やばい", "DANGEROUS"),
    (r"さみ", r"[いぃー]+", "寒い", "COLD"),
]
_CASUAL_RE = re.compile("|".join(
    "(?P<c%d>%s(?P<t%d>%s))" % (i, ("(?<![ぁ-ゖ一-龯々])" if len(re.sub(r"[^ぁ-んァ-ン一-龯]", "", a)) <= 2 else "") + a, i, t)
    for i, (a, t, _w, _g) in enumerate(CASUAL)))


def is_katakana_word(t):
    return bool(t) and all("\u30a1" <= c <= "\u30fa" or c == "ー" for c in t)


class Analyzer:
    def __init__(self, glossary, options: Options = None):
        self.tagger = get_tagger()
        self.g = glossary
        self.o = options or Options()
        # user words (names etc.) are matched before tokenizing, longest first
        self.known_forms, self.known_phrases, _ = expand_known(self.o.known, self.tagger)
        self.known_phrases = set(self.known_phrases)
        self.phrases, self._alone = {}, set()
        for k, v in getattr(self.g, "phrases", {}).items():
            if len(k) > 2 and k[0] == "<" and k[-1] == ">":   # <やだ>=NO-WAY: only as a word of its own
                k = k[1:-1]
                self._alone.add(k)
            if k not in self.g.user_words:
                self.phrases[k] = v
        words = sorted({k for k in self.g.user_words if len(k) >= 1 and has_japanese(k)} | self.known_phrases
                       | set(self.phrases),
                       key=len, reverse=True)
        self._user_re = re.compile("|".join(self._pattern(w) for w in words)) if words else None

    NAME_FOLLOW = ("は", "も", "の", "が", "に", "と", "って", "や", "ちゃん", "さん", "くん", "よ", "ね", "ぞ", "か", "を", "へ")

    def _pattern(self, w):
        """The regex for one phrase / name. Katakana keys don't match inside longer katakana words
        (ブレ is not in ラブレター); names that are also words don't match inside other words
        (なる the name, not なる BECOME; 新 ARATA, not 新聞)."""
        pat = re.escape(w)
        if w in self.known_phrases:
            return pat
        kata = r"[\u30a1-\u30faー]"
        if re.match(kata, w):
            pat = "(?<!%s)%s" % (kata, pat)
        hira = r"[\u3041-\u3096]"
        is_name = w in self.o.name_keys
        if w in self._alone:
            pat = "(?<!%s)%s(?!%s)" % (hira, pat, hira)
        elif is_name and is_hiragana_only(w) and (w in self.g.d or w in KANA_GRAMMAR or len(w) <= 2):
            pat = "(?<!%s)%s(?=%s|[^\u3041-\u3096]|$)" % (hira, pat, "|".join(self.NAME_FOLLOW))
        elif is_name and has_kanji(w) and (len(w) == 1 or w in self.g.d):
            pat = "(?<![\u3400-\u9fff々0-9０-９])%s(?:(?![\u3400-\u9fff々0-9０-９])|(?=%s))" % (
                pat, "|".join(("君", "様", "殿", "氏", "達", "先輩", "先生", "兄", "姉", "家", "さん", "ちゃん", "くん")))
        return pat

    def _unstretch(self, text):
        text = self._unstretch_hira(text)
        if "ー" in text and self.g.user_words:   # ターロー (calling out) -> タロー, a name from the list
            def fix(m):
                run = m.group(0)
                for k in [k for k, c in enumerate(run) if c == "ー"]:
                    cand = run[:k] + run[k + 1:]
                    if cand in self.g.user_words and run not in self.g.user_words:
                        return cand
                return run
            text = re.sub(r"[\u30a1-\u30faー]{3,}", fix, text)
        return text

    def _unstretch_hira(self, text):
        """すごーい -> すごい, いただきまーす -> いただきます: a long ー inside a hiragana word.
        Kept where it splits two words (ちーちゃん)."""
        if "ー" not in text:
            return text
        for m in reversed(list(re.finditer(r"(?<=[\u3041-\u3096])ー+(?=[\u3041-\u3096])", text))):
            a = m.start()
            while a > 0 and "\u3041" <= text[a - 1] <= "\u3096":
                a -= 1
            b = m.end()
            while b < len(text) and "\u3041" <= text[b] <= "\u3096":
                b += 1
            cand = text[a:m.start()] + text[m.end():b]
            cut, pos = m.start() - a, 0
            spans = False
            for t in self.tagger(cand):
                n = len(t.surface)
                if pos < cut < pos + n:
                    spans = True
                pos += n
            if spans:
                text = text[:m.start()] + text[m.end():]
        return text

    # --- helpers ---------------------------------------------------------
    def _lower(self, surface, reading, particle=False, pos2=""):
        """Representation of an untranslated (grammar) piece."""
        if self.o.script == "hiragana":
            return surface if not has_kanji(surface) and particle else kata_to_hira(reading or surface)
        if particle:
            if surface == "は" and pos2 != "格助詞":
                return "wa"
            if surface == "へ" and pos2 == "格助詞":
                return "e"
            if surface == "を":
                return self.o.wo
        return to_romaji(kata_to_hira(reading or surface))

    def _name(self, reading):
        r = to_romaji(kata_to_hira(reading))
        if not self.o.name_long_vowels:
            r = re.sub(r"ou", "o", r)
            r = re.sub(r"uu", "u", r)
        return r.upper()

    GLOSS_CUT = ("-SUCH-AS-", "-OF-THE-", "-IN-A-", "-WITH-ONE'S-", "-WITH-SOMEONE-", "-WITH-ONLY-", "-BY-",
                 "-USED-", "-THAT-", "-WHICH-", "-FOR-A-", "-IN-ORDER-")

    def _gloss(self, w, suffix=False):
        g = self._gloss_raw(w, suffix)
        if not g or g == g.lower():
            return g
        if g.startswith("COUNTER-FOR-"):
            g = g[12:]
        if len(g) > 26:                     # long dictionary glosses: keep the head of the meaning
            for sep in self.GLOSS_CUT:
                k = g.find(sep)
                if 3 <= k:
                    g = g[:k]
                    break
        return g

    def _gloss_raw(self, w, suffix=False):
        s, lemma = w.surface, _f(w, "lemma")
        if lemma in SPECIAL_GLOSS:
            return SPECIAL_GLOSS[lemma]
        if _f(w, "pos1") == "接頭辞" and s in PREFIX_GLOSS:
            return PREFIX_GLOSS[s]
        reading = _f(w, "lForm") or _f(w, "kanaBase") or _f(w, "kana")
        if suffix:
            v = SUFFIX_GLOSS.get((lemma, _f(w, "kana"))) or SUFFIX_GLOSS.get(lemma)
            if v:
                return v
        ov = self.g.override(lemma, s, _f(w, "orthBase"))
        if ov:
            return ov
        if lemma in NUMBERS or s in NUMBERS:
            return NUMBERS.get(lemma) or NUMBERS[s]
        if re.search(r"-[A-Za-z]", lemma):  # unidic loanword lemma: "プリンター-printer"
            jp, eng = lemma.split("-", 1)
            g = self.g.lookup([jp, s])
            return g or re.sub(r"\s+", "-", eng).upper()
        if has_katakana(s) and not has_kanji(s) and mora_count(s) < 2:
            return None  # single katakana sounds are almost never real words
        g = self.g.lookup([lemma, _f(w, "orthBase"), s], reading)
        if g:
            return g
        if "々" in s:     # 神々 -> 神神 GODS
            g = self.g.lookup([re.sub(r"(.)々", r"\1\1", s), re.sub(r"(.)々", r"\1\1", lemma or "")])
            if g:
                return g
        if _f(w, "pos1") == "動詞" and lemma and lemma.endswith("る") and lemma[-2:-1] in E_TO_U:
            # can-do form: 振り払える -> 振り払う SHAKE-OFF, 読める -> 読む
            g = self.g.lookup([lemma[:-2] + E_TO_U[lemma[-2]]])
            if g:
                return g
        if lemma and lemma.endswith("さ") and len(lemma) >= 2 and _f(w, "pos2") == "さ名詞":
            # adjective + さ: 優しさ -> KINDNESS-style noun from the adjective (TENDERNESS)
            g = self.g.override(lemma[:-1] + "い") or self.g.lookup([lemma[:-1] + "い"])
            if g:
                if "-" in g:
                    return g + "-NESS"     # LONGING-FOR-OTHERS-NESS
                return (g[:-1] + "INESS") if g.endswith("Y") else (g + "NESS")
        if has_kanji(s):  # unknown kanji word: glue together per-kanji meanings
            parts = [self.g.kanji(c) for c in s if KANJI_RE.match(c)]
            parts = [p for p in parts if p]
            if parts:
                return "-".join(p[0] for p in parts)
        return None

    def _base_reading(self, w, base, reading):
        """Hiragana reading of a word's dictionary form, for the frequency list."""
        if not has_kanji(base):
            return ""
        kb = _f(w, "kanaBase") if w is not None else ""
        if kb:
            return kata_to_hira(kb)
        if w is not None and base == w.surface and reading:
            return kata_to_hira(reading)
        ents = self.g.d.get(base)
        if ents and ents[0][1]:
            return kata_to_hira(ents[0][1][0])
        if len(base) == 1 and has_kanji(base):
            k = self.g.kanji(base)
            if k and k[1]:
                return kata_to_hira(k[1]).replace(".", "").replace("-", "")
        return kata_to_hira(base) if not has_kanji(base) else ""

    @staticmethod
    def _reading(w):
        r = _f(w, "kana")
        if r:
            return r
        s = w.surface
        return s if not has_kanji(s) else ""

    # --- main ------------------------------------------------------------
    def analyze(self, text):
        text = self._unstretch(text)
        out = []
        st = {"prefix": "", "prev": None, "attachable": False, "carry": "", "prefix_open": False}
        pos = 0
        if self._user_re:
            for m in self._user_re.finditer(text):
                rest = re.match(r"[\u30a1-\u30faー]+", text[m.end():]) if is_katakana_word(m.group(0)[-1:]) else None
                if rest and not (rest.group(0) in self.g.d or self.g.override(rest.group(0))):
                    continue   # ブレ is not in ラブレター (but バードマン+サークル is fine)
                self._analyze_chunk(text[pos:m.start()], out, st)
                if out and text[pos:m.start()][-1:].isspace() and out[-1].text[-1:].isalnum() and not st["prefix"]:
                    out[-1].text += ","   # a space before the name is a pause
                word = m.group(0)
                if word in self.phrases and word not in self.known_phrases:
                    v = self.phrases[word]
                    v, _bar, tail = v.partition("|")          # 身に付けよう = ACQUIRE|you: a gloss + a sound
                    if v == "~":   # keep the sound: みてえ -> mitee, 好き -> suki
                        rd = word if not has_kanji(word) else "".join(
                            (getattr(t.feature, "kana", "") or "") for t in self.tagger(word))
                        self._add(out, st, self._lower(word, rd or word), mora_count(rd or word) or 2, False)
                    elif v.islower():   # いただきます = itadakimasu: written as sounds, like the example files
                        shown = v
                        if self.o.script == "hiragana":
                            shown = word if not has_kanji(word) else kata_to_hira("".join(
                                (getattr(t.feature, "kana", "") or "") for t in self.tagger(word)))
                            tail = ""
                        self._add(out, st, shown, max(1, mora_count(word) - (len(tail) // 2 if tail else 0)), False)
                    else:
                        self._add(out, st, v.upper(), max(2, mora_count(word) or 2 * len(word)), False)
                        out[-1].core, out[-1].base, out[-1].jp = v.upper(), word, word
                    if tail:
                        t_txt = tail.strip().lower()
                        if self.o.script == "hiragana":      # the tail's sounds, as written at the end of the phrase
                            n = len(re.findall(r"[aiueo]|n(?![aiueoy])", t_txt)) or 1
                            t_txt = kata_to_hira(word)[-n:]
                        self._add(out, st, t_txt, max(1, len(tail) // 2), True)
                    out[-1].jp = word
                    st.update(prev=None, attachable=True, carry="", after_name=False, last_gloss_idx=-1, after_word=True,
                              after_phrase=not v.startswith("~"))
                elif word in self.known_phrases:
                    self._add(out, st, word, max(2, mora_count(word) or 2 * len(word)), False)
                    out[-1].jp, out[-1].known = word, True
                    st.update(prev=None, attachable=True, carry="", after_name=False)
                else:
                    shown = self.g.user_words[word]
                    if word in self.o.name_keys:
                        shown = self._with_meaning(shown, word)
                    self._add(out, st, shown, max(2, 2 * len(word)), False)
                    out[-1].jp = word
                    st.update(prev=None, attachable=True, carry="", after_name=True)
                pos = m.end()
        self._analyze_chunk(text[pos:], out, st)
        if st["prefix"] and out:
            out[-1].text += st["prefix"].strip()
        out = self._join_janai(out)
        if out:
            out[-1].space = False
        return out

    @staticmethod
    def _join_janai(out):
        """じゃ + ない is written as one word, like the example files: janai / じゃない."""
        res = []
        for s in out:
            if res and res[-1].text.lstrip("-") in ("ja", "じゃ"):
                nxt = s.text.lstrip("-")
                if nxt[:3] == "nai" or nxt[:2] == "ない":
                    res[-1].text += nxt
                    res[-1].moras += s.moras
                    res[-1].space = s.space
                    res[-1].jp += s.jp
                    continue
            res.append(s)
        return res

    def _add(self, out, st, text, moras, attach):
        if attach and out:
            out[-1].space = False
            text = "-" + text
        if st["prefix"]:
            text = st["prefix"] + text
            st["prefix"] = ""
        out.append(Syl(text, max(moras, 1)))

    def _analyze_chunk(self, text, out, st):
        if not text:
            return
        pieces = re.split(r"[\s\u3000]+", text)
        for i, piece in enumerate(pieces):
            if i > 0:
                st["num_open"] = False       # 101 103: two numbers, not 101103
            if i > 0 and out and has_japanese(piece[:1]):
                # a space inside a Japanese subtitle is a pause -> show it as a comma
                if out[-1].text[-1:].isalnum() and not st["prefix"]:
                    out[-1].text += ","
                st.update(attachable=False, carry="", after_name=False, prefix_open=False, num_open=False)
            pos = 0
            for m in _CASUAL_RE.finditer(piece):
                for w in self._words(piece[pos:m.start()]):
                    self._token(w, out, st)
                self._casual(m, out, st)
                pos = m.end()
            for w in self._words(piece[pos:]):
                self._token(w, out, st)

    I_TO_U = {"い": "う", "き": "く", "ぎ": "ぐ", "し": "す", "ち": "つ", "に": "ぬ", "び": "ぶ", "み": "む", "り": "る"}
    KANJI_NUM = {"〇": 0, "零": 0, "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    KANJI_UNIT = {"十": 10, "百": 100, "千": 1000}
    LAUGH_RE = re.compile(r"(?:[ウニイエムグ]?[ハヒフヘホ][ァィゥェォッー]*){2,}[ッー]?|[ハヒフヘホ][ァィゥェォー]+[ッ]?"
                          r"|[アイウエオニムグ]ッ?(?:[ハヒフヘホ][ァィゥェォッー]*)+")

    def _verb_of_stem(self, stem):
        """受け -> 受ける, 抱え -> 抱える, 探り -> 探る: the verb a 連用形 stem comes from (or None)."""
        for v in (stem + "る", stem[:-1] + self.I_TO_U.get(stem[-1:], "")):
            if len(v) > len(stem) - 1 and v != stem and v in self.g.d:
                return v
        return None

    @classmethod
    def _kanji_number(cls, s):
        """二百 -> 200, 三十一 -> 31, 三千万 -> 30000000 (None if it isn't a number)."""
        total, section, cur = 0, 0, None
        for ch in s:
            if ch in cls.KANJI_NUM:
                cur = cls.KANJI_NUM[ch] if cur is None else cur * 10 + cls.KANJI_NUM[ch]
            elif ch in cls.KANJI_UNIT:
                section += (1 if cur is None else cur) * cls.KANJI_UNIT[ch]
                cur = None
            elif ch in ("万", "億"):
                section += cur or 0
                total += (section or 1) * (10000 if ch == "万" else 100000000)
                section, cur = 0, None
            else:
                return None
        return total + section + (cur or 0)

    def _fix_tokens(self, toks):
        """Small repairs to the word splitter's output that the rules below rely on."""
        f = lambda t, k: getattr(t.feature, k, "") or ""
        out, i, n = [], 0, len(toks)
        sym = lambda t: t is None or f(t, "pos1") in ("補助記号", "記号", "空白") or not has_japanese(t.surface)
        while i < n:
            t = toks[i]
            s, p1 = t.surface, f(t, "pos1")
            prev = out[-1] if out else None
            nxt = toks[i + 1] if i + 1 < n else None
            # a short cry at the start of a line: おおっ, うわっ, なっ, いやっ, ひいっ (not a verb)
            if (prev is None or sym(prev)) and is_hiragana_only(s):
                j, w = i, ""
                while j < n and is_hiragana_only(toks[j].surface) and len(w + toks[j].surface) <= 4:
                    w += toks[j].surface
                    j += 1
                    if w.endswith("っ"):
                        break
                if w.endswith("っ") and len(w) >= 2 and (j >= n or sym(toks[j])):
                    out.append(_tok(w, "感動詞", "", w, hira_to_kata(w)))
                    i = j
                    continue
            # katakana pieces the splitter cut apart: パ+クリ -> パクリ, オー+クション -> オークション
            if is_katakana_word(s) and nxt is not None and is_katakana_word(nxt.surface):
                j, best = i + 1, None
                while j < n and is_katakana_word(toks[j].surface) and j - i < 4:
                    w = "".join(x.surface for x in toks[i:j + 1])
                    if w in self.g.d or self.g.override(w):
                        best = (j, w)
                    j += 1
                if best:
                    out.append(_tok(best[1], "名詞", "普通名詞", best[1], best[1]))
                    i = best[0] + 1
                    continue
            # laughs in hiragana: へへ, ふふっ, ひひ (not the particle へ)
            if is_hiragana_only(s) and (prev is None or sym(prev) or f(prev, "pos1") == "感動詞"):
                j, w = i, ""
                while j < n and is_hiragana_only(toks[j].surface) and len(w) < 8:
                    w += toks[j].surface
                    j += 1
                    if re.fullmatch(r"([はひふへほ])\1+っ?", w) and (j >= n or sym(toks[j])):
                        out.append(_tok(w, "感動詞", "", w, hira_to_kata(w)))
                        i = j
                        break
                else:
                    j = -1
                if j != -1 and i == j:
                    continue
            # laughs and breaths in katakana: フフフ, ハァ, ニヒヒ, ウフ -> sounds, not words
            if is_katakana_word(s) and self.LAUGH_RE.fullmatch(s) and not self.g.override(s) and (
                    s not in self.g.d or re.fullmatch(r"(.)\1+[ッー]?|(..)\2+[ッー]?", s)):
                out.append(_tok(s, "感動詞", "", s, s))
                i += 1
                continue
            # a character's verbal tic アル / アルヨ / アルネ (also glued to a word: シチュエーションアルネ)
            m = re.fullmatch(r"(.*?)(アル(?:ヨ|ネ|ヨー|ネー)?)", s) if is_katakana_word(s) else None
            if m and (not m.group(1) or m.group(1) in self.g.d) and s not in self.g.d:
                if m.group(1):
                    out.append(_tok(m.group(1), "名詞", "普通名詞", m.group(1), m.group(1)))
                out.append(_tok(m.group(2), "助動詞", "", m.group(2), m.group(2)))
                i += 1
                continue
            if s == "アル" and p1 != "助動詞" and prev is not None and not sym(prev):
                out.append(_tok(s, "助動詞", "", s, s))
                i += 1
                continue
            # は as a gasp or laugh: はあ, ははは, は？
            if s == "は" and (prev is None or sym(prev) or prev.surface in ("は", "あ")) and (
                    nxt is None or sym(nxt) or nxt.surface[:1] in "はあぁーっ"):
                out.append(_tok("は", "感動詞", "", "は", "ハ"))
                i += 1
                continue
            # や + がる -> やがる (rude verb ending): 何しやがる
            if s == "や" and nxt is not None and f(nxt, "lemma") == "がる" and prev is not None and not sym(prev):
                if f(prev, "pos1") == "名詞" and has_kanji(prev.surface) and self._verb_of_stem(prev.surface):
                    v = self._verb_of_stem(prev.surface)      # 待ち+やがれ: the verb 待つ, not WAITING
                    out[-1] = _tok(prev.surface, "動詞", "一般", v, f(prev, "kana"),
                                   "下一段" if v == prev.surface + "る" else "五段", "連用形-一般")
                out.append(_tok("や" + nxt.surface, "助動詞", "", "やがる", "ヤ" + (f(nxt, "kana") or ""),
                                f(nxt, "cType"), f(nxt, "cForm")))
                i += 2
                continue
            # いら/いり (要る NEED): いらない, いります
            if s[:2] in ("いら", "いり") and f(t, "lemma") in ("居る", "いる"):
                out.append(_tok(s, "動詞", "一般", "要る", f(t, "kana"), f(t, "cType"), f(t, "cForm")))
                i += 1
                continue
            # hiragana いい is the adjective (good), not 言う
            if s == "いい" and f(t, "lemma") == "言う" and not (prev is not None and prev.surface in ("と", "って")):
                out.append(_tok("いい", "形容詞", "非自立可能", "いい", "イイ", "形容詞", "終止形-一般"))
                i += 1
                continue
            # ってな+ん+だ -> って + なん + だ;  に+なるほど -> に + なる + ほど;  し+とこ (しとこう) -> grammar
            if s == "ってな" and nxt is not None and nxt.surface == "ん":
                out.append(_tok("って", "助詞", "副助詞", "って", "ッテ"))
                out.append(_tok("なん", "名詞", "普通名詞", "なん", "ナン"))
                i += 2
                continue
            if s == "なるほど" and prev is not None and prev.surface == "に":
                out.append(_tok("なる", "動詞", "非自立可能", "なる", "ナル", "五段-ラ行", "終止形-一般"))
                out.append(_tok("ほど", "助詞", "副助詞", "ほど", "ホド"))
                i += 1
                continue
            if s in ("とこ", "とこう") and prev is not None and f(prev, "pos1") == "動詞" and \
                    f(prev, "cForm").startswith("連用形") and (nxt is None or sym(nxt) or nxt.surface in ("う", "か", "よ")):
                out.append(_tok(s, "助動詞", "", "とく", hira_to_kata(s)))
                i += 1
                continue
            # いい+と+この -> いい+とこ+の (a good place's ...)
            if s == "と" and nxt is not None and nxt.surface == "この" and prev is not None and \
                    f(prev, "pos1") in ("形容詞", "動詞", "助動詞", "連体詞"):
                out.append(_tok("とこ", "名詞", "普通名詞", "とこ", "トコ"))
                out.append(_tok("の", "助詞", "格助詞", "の", "ノ"))
                i += 2
                continue
            # ては+ならない, なきゃ+いけない: grammar (must / must not), not BECOME / GO
            if prev is not None and prev.surface in ("は", "ちゃ", "じゃ", "きゃ", "なきゃ", "ければ", "くちゃ", "なくちゃ") \
                    and f(t, "lemma") in ("成る", "なる", "行ける", "いける", "行く", "いく") and s[:2] in ("なら", "なり", "いけ"):
                out.append(_tok(s, "助動詞", "", s, f(t, "kana"), f(t, "cType"), f(t, "cForm")))
                i += 1
                continue
            # じゃ + ない is grammar (janai), not じゃ THEN
            if s == "じゃ" and p1 == "接続詞" and nxt is not None and (nxt.surface[:1] == "な" or (
                    prev is not None and not sym(prev))):
                out.append(_tok("じゃ", "助動詞", "", "だ", "ジャ"))
                i += 1
                continue
            # adjective -ku before a verb: 強く+なり -> STRONG-ku BECOME (janome calls it 促音便)
            if p1 == "形容詞" and s.endswith("く") and f(t, "cForm") == "連用形-促音便" and not (
                    nxt is not None and f(nxt, "lemma") in ("無い", "ない")):     # but 悪く+ない stays BAD-kunai
                out.append(_tok(s, "形容詞", f(t, "pos2"), f(t, "lemma"), f(t, "kana"), f(t, "cType"), "連用形-一般"))
                i += 1
                continue
            # 来て+くるん(くるむ) -> くる + ん;  思って+たより -> た + より
            if prev is not None and prev.surface in ("て", "で") and s == "くるん" and f(t, "lemma") == "くるむ":
                out.append(_tok("くる", "動詞", "非自立可能", "来る", "クル", "カ行変格", "終止形-一般"))
                out.append(_tok("ん", "助詞", "準体助詞", "ん", "ン"))
                i += 1
                continue
            if prev is not None and prev.surface in ("て", "で") and s == "たより" and p1 == "名詞":
                out.append(_tok("た", "助動詞", "", "た", "タ", "助動詞-タ", "終止形-一般"))
                out.append(_tok("より", "助詞", "格助詞", "より", "ヨリ"))
                i += 1
                continue
            # 等 after a pronoun is ら (僕等 boku-ra)
            if s == "等" and prev is not None and f(prev, "pos1") == "代名詞":
                out.append(_tok("等", "接尾辞", "名詞的", "等", "ラ"))
                i += 1
                continue
            # もう + number = MORE (もう1回 ONE MORE TIME); どうも + a word = SOMEHOW; verb + 以上 = SINCE
            if s == "もう" and nxt is not None and (f(nxt, "pos2") == "数詞" or nxt.surface[:1].isdigit()) and \
                    i + 2 < n and toks[i + 2].surface[:1] in "回度杯個つ本枚人ちっ":
                out.append(_tok(s, "副詞", "一般", "もう+数", "モウ"))
                i += 1
                continue
            if s == "どうも" and nxt is not None and not sym(nxt) and f(nxt, "pos1") in ("形容詞", "動詞", "形状詞", "名詞") \
                    and f(nxt, "lemma") not in ("有難い", "ありがとう"):
                out.append(_tok(s, "副詞", "一般", "どうも+", "ドウモ"))
                i += 1
                continue
            if s == "以上" and prev is not None and (f(prev, "pos1") in ("動詞",) or prev.surface in ("た", "だ", "る")):
                out.append(_tok(s, "名詞", "普通名詞", "以上+", "イジョウ"))
                i += 1
                continue
            # 設計+図っ+て -> 設計図 + って (the noun, not 図る PLAN)
            if p1 == "名詞" and has_kanji(s) and nxt is not None and f(nxt, "pos1") == "動詞" and \
                    re.fullmatch(r"[\u4e00-\u9fff]っ", nxt.surface) and i + 2 < n and toks[i + 2].surface == "て" and \
                    (s + nxt.surface[0]) in self.g.d:
                word = s + nxt.surface[0]
                rd = self.g.d[word][0][1][0] if self.g.d[word][0][1] else ""
                out.append(_tok(word, "名詞", "普通名詞", word, hira_to_kata(rd)))
                out.append(_tok("って", "助詞", "副助詞", "って", "ッテ"))
                i += 3
                continue
            # a verb stem the splitter took for a noun: 受け+に+来る (come to take), 荷物を抱え
            if p1 == "名詞" and has_kanji(s) and re.search(r"[\u3041-\u3096]$", s) and f(t, "pos2") != "固有名詞":
                v = self._verb_of_stem(s)
                purpose = nxt is not None and nxt.surface == "に" and i + 2 < n and \
                    f(toks[i + 2], "lemma") in ("来る", "行く", "参る")
                after_o = prev is not None and prev.surface in ("を", "に", "が") and (
                    nxt is None or sym(nxt) or nxt.surface in ("て", "た"))
                if v and (purpose or after_o):
                    out.append(_tok(s, "動詞", "一般", v, f(t, "kana"), "下一段" if v == s + "る" else "五段",
                                    "連用形-一般"))
                    i += 1
                    continue
            # kanji numbers: 二+百 -> 200, 三+十+一 -> 31, １+万 -> 10000
            if f(t, "pos2") == "数詞" and s != "何":
                j, run = i, ""
                while j < n and f(toks[j], "pos2") == "数詞" and toks[j].surface != "何":
                    run += toks[j].surface
                    j += 1
                if re.search(r"[\u4e00-\u9fff]", run) and (j - i >= 2 or re.search(r"[十百千万億]", run) and len(run) >= 2):
                    num = self._kanji_number(re.sub(r"[0-9０-９]+", lambda m: "".join(
                        "〇一二三四五六七八九"[int(c)] for c in m.group(0)), run))
                    if num is not None:
                        if num >= 10 ** 9 and num % 10 ** 9 == 0:
                            shown = "%d-BILLION" % (num // 10 ** 9)
                        elif num >= 10 ** 6 and num % 10 ** 6 == 0:
                            shown = "%d-MILLION" % (num // 10 ** 6)
                        else:
                            shown = "{:,}".format(num) if num >= 10000 else str(num)
                        out.append(_tok(shown, "名詞", "数詞", shown, f(t, "kana")))
                        i = j
                        continue
            out.append(t)
            i += 1
        return out

    def _words(self, text):
        """The word splitter's tokens, with ordinary words it mistook for names put back together:
        janome reads 王都 (royal capital) as the name 王 + 都. Two to four name-tagged pieces whose kanji
        together make a dictionary word (and not a name you or a name list gave) become that word."""
        toks = self._fix_tokens(list(self.tagger(text)) if text else [])
        out, i = [], 0
        while i < len(toks):
            done = False
            if toks[i].feature.pos1 == "名詞":
                for n in (4, 3, 2):
                    run = toks[i:i + n]
                    if len(run) < n or any(t.feature.pos1 != "名詞" for t in run) or \
                            not any(t.feature.pos2 == "固有名詞" for t in run):
                        continue
                    word = "".join(t.surface for t in run)
                    if not has_kanji(word) or word in self.g.user_words or word not in self.g.d:
                        continue
                    reading = self.g.d[word][0][1][0] if self.g.d[word][0][1] else ""
                    kana = hira_to_kata(reading) if reading else "".join(t.feature.kana or "" for t in run)
                    out.append(_tok(word, "名詞", "普通名詞", word, kana))
                    i += n
                    done = True
                    break
            if not done and is_katakana_word(toks[i].surface):
                # a katakana name split into a loanword + leftover: フリーダ -> フリー + ダ
                j = i
                while j < len(toks) and toks[j].feature.pos1 == "名詞" and is_katakana_word(toks[j].surface):
                    if j > i and len(toks[j].surface) >= 3 and toks[j].surface in self.g.d:
                        break       # バードマン + サークル: the club stays CLUB
                    j += 1
                if j - i >= 2:
                    word = "".join(t.surface for t in toks[i:j])
                    if word not in self.g.d and not self.g.override(word) and \
                            any(t.feature.pos2 == "固有名詞" or t.surface not in self.g.d for t in toks[i:j]):
                        out.append(_tok(word, "名詞", "固有名詞", word, word))
                        i = j
                        done = True
            if done:
                continue
            t = toks[i]
            if not done and t.feature.pos1 == "接頭辞" and has_kanji(t.surface) and i + 1 < len(toks):
                # prefix + word the dictionary knows as one: 薄+汚れる -> 薄汚れる GRIMY, not LIGHT-GET-DIRTY
                n = toks[i + 1]
                whole = t.surface + (n.feature.lemma or n.surface)
                if n.feature.pos1 in ("動詞", "形容詞", "名詞", "形状詞") and has_kanji(n.surface) and \
                        (whole in self.g.d or self.g.override(whole)) and whole not in self.g.user_words:
                    ents = self.g.d.get(whole)
                    rd = ents[0][1][0] if ents and ents[0][1] else ""
                    kana = hira_to_kata(rd[:len(rd) - (len(whole) - len(t.surface + n.surface))]) if rd else ""
                    out.append(_tok(t.surface + n.surface, n.feature.pos1, n.feature.pos2, whole,
                                    kana or (t.feature.kana or "") + (n.feature.kana or ""),
                                    n.feature.cType, n.feature.cForm))
                    i += 2
                    continue
            if not done and i + 1 < len(toks) and toks[i + 1].surface == "々" and has_kanji(t.surface):
                word = t.surface + "々"        # 神 + 々 -> 神々 GODS
                out.append(_tok(word, t.feature.pos1, t.feature.pos2, word, ""))
                i += 2
                done = True
            if not done and is_katakana_word(t.surface) and len(t.surface) >= 6 and t.surface not in self.g.d \
                    and not self.g.override(t.surface):
                # an unknown katakana word ending in a known one: バードマン + サークル
                for k in range(2, len(t.surface) - 2):
                    tail = t.surface[k:]
                    if tail in self.g.d:
                        out.append(_tok(t.surface[:k], "名詞", "普通名詞", t.surface[:k], t.surface[:k]))
                        out.append(_tok(tail, "名詞", "普通名詞", tail, tail))
                        i += 1
                        done = True
                        break
            nxt = toks[i + 1] if i + 1 < len(toks) else None
            f = t.feature
            if not done and f.pos1 == "形容詞" and nxt is not None and nxt.surface == "さ" and \
                    nxt.feature.pos1 == "接尾辞":
                # adjective + さ is one noun: 優し+さ -> 優しさ, 強+さ -> 強さ STRENGTH
                word = t.surface + "さ"
                out.append(_tok(word, "名詞", "普通名詞" if word in self.g.d else "さ名詞", word,
                                (f.kana or "") + "サ"))
                i += 2
                continue
            if not done and f.pos1 == "動詞" and (f.cForm or "").startswith("連用形") and nxt is not None and \
                    nxt.feature.pos1 == "動詞" and nxt.feature.pos2 != "非自立可能":
                # two verbs the dictionary knows as one: やり+残す -> やり残す LEAVE-UNDONE, 膨れ+上がる
                whole = t.surface + (nxt.feature.lemma or nxt.surface)
                if whole not in self.g.d and is_hiragana_only(nxt.feature.lemma or "x") and f.kana:
                    alt = kata_to_hira(f.kana) + nxt.feature.lemma     # 棲み+つく -> すみつく SETTLE
                    if alt in self.g.d and len(alt) >= 4:
                        whole = alt
                if (has_kanji(whole) or whole != t.surface + (nxt.feature.lemma or "")) and \
                        (whole in self.g.d or self.g.override(whole)) and whole not in self.g.user_words:
                    out.append(_tok(t.surface + nxt.surface, "動詞", "一般", whole,
                                    (f.kana or "") + (nxt.feature.kana or ""), nxt.feature.cType,
                                    nxt.feature.cForm))
                    i += 2
                    continue
            if not done and f.pos1 == "動詞" and (f.cForm or "") == "連用形-一般" and has_kanji(t.surface) and \
                    t.surface in self.g.d and t.surface != f.lemma and (
                        (nxt is not None and nxt.surface in ("は", "が", "を", "の", "も", "と", "だ", "です")) or
                        (out and out[-1].surface == "の" and (nxt is None or nxt.feature.pos1 in ("補助記号", "記号")
                                                              or nxt.surface in ("で", "と", "や", "へ", "まで", "から")))):
                # a verb stem used as a noun: 夢の続き -> CONTINUATION (not CONTINUE-ki)
                out.append(_tok(t.surface, "名詞", "普通名詞", t.surface, f.kana or ""))
                i += 1
                continue
            if not done:
                out.append(t)
                i += 1
        return out

    def name_meaning(self, word):
        """Literal meaning of a name's kanji: 大樹 -> LARGE-TREE, 春香 -> SPRING-FRAGRANCE."""
        given = getattr(self.g, "name_meanings", {}).get(word)
        if given:
            return given      # from the name list (also for names written in kana)
        if not has_kanji(word):
            return ""
        whole = self.g.d.get(word)
        if whole:
            return format_gloss(whole[0][2]).upper()
        parts = []
        for ch in word:
            if has_kanji(ch):
                k = self.g.kanji(ch)
                if k and k[0]:
                    parts.append(k[0].split("-")[0].upper() if len(k[0]) > 12 else k[0].upper())
        return "-".join(parts)

    def _with_meaning(self, text, word):
        if self.o.name_style not in ("both", "meaning"):
            return text
        m = self.name_meaning(word)
        if not m or m == text:
            return text              # no meaning known: keep the romaji name
        if self.o.name_style == "meaning":
            return "(%s)" % m        # you hear the name; the brackets say it's a name
        return "%s (%s)" % (text, m)

    def _casual(self, m, out, st):
        i = int(next(k for k, v in m.groupdict().items() if v and k[0] == "c")[1:])
        _a, _t, word, gloss = CASUAL[i]
        whole, tail = m.group(0), m.group("t%d" % i)
        stem = whole[: len(whole) - len(tail)]
        moras = mora_count(whole) or len(whole)
        tail_m = mora_count(tail) or 1
        known = self._known(word)
        self._add(out, st, stem if known else self.g.override(word) or gloss, max(moras - tail_m, 1), False)
        out[-1].core, out[-1].jp, out[-1].known = ("" if known else out[-1].text.lstrip("(\"")), stem, known
        out[-1].base, out[-1].reading = word, kata_to_hira(word) if not has_kanji(word) else ""
        tail_txt = tail if self.o.script == "hiragana" else to_romaji(kata_to_hira(tail).replace("ー", "え"))
        self._add(out, st, tail_txt, tail_m, True)
        out[-1].jp = tail
        st.update(prev=None, attachable=False, carry="", after_name=False, last_gloss_idx=-1, after_word=True)

    def _kana_content(self, pos1, pos2, lemma, s):
        """A real word written in kana (におい ODOUR, まじめ SERIOUS, ふさわしい APPROPRIATE, いつか SOMEDAY):
        translated like its kanji spelling would be. Short pieces and grammar words stay as sounds."""
        if pos1 not in ("名詞", "動詞", "形容詞", "形状詞") or pos2 in ("非自立可能", "数詞", "固有名詞"):
            return False
        base = lemma if lemma and not has_kanji(lemma) else s
        if pos1 == "動詞" and len(s) < 3 and not any("uk" in (e[3] or "") for e in self.g.d.get(lemma, [])):
            return False    # short kana verb pieces are often a bad split: 持ってかれ, ふんばれ (but やめ STOP)
        if len(base) < 3 or base in KANA_GRAMMAR or s in KANA_GRAMMAR or lemma in KANA_KEEP:
            return False
        return self.g.lookup([base, s]) is not None

    def _known(self, *forms):
        return bool(self.known_forms) and any(f and f in self.known_forms for f in forms)

    def _counter_tail(self, out, st, rest):
        tail, m = COUNTER_TAIL[rest]
        if tail and self._known(rest):
            self._add(out, st, rest, m, False)
            out[-1].known = True
        elif tail is None:   # grammar-ish tails stay as sounds: 2-TIME-me, 3-YEAR-buri
            kana = "め" if rest == "目" else rest
            self._add(out, st, kana if self.o.script == "hiragana" else to_romaji(kana), m, True)
        else:
            self._add(out, st, tail, m, False)
            out[-1].core = tail
        out[-1].jp = rest

    def _token(self, w, out, st):
        s = w.surface
        pos1, pos2, pos3 = _f(w, "pos1"), _f(w, "pos2"), _f(w, "pos3")
        cform, ctype, lemma = _f(w, "cForm"), _f(w, "cType"), _f(w, "lemma")
        reading = self._reading(w)
        pron = _f(w, "pron") or reading
        prev = st["prev"]
        p1, p2, p3 = _f(prev, "pos1"), _f(prev, "pos2"), _f(prev, "pos3")
        was_after_name = st.get("after_name", False)
        if (was_after_name or st.get("after_word")) and s in ("が", "は", "を", "に", "の", "と", "も", "で", "へ", "や", "から", "まで", "って"):
            pos1, pos2 = "助詞", ("係助詞" if s in ("は", "も") else "格助詞")   # 楓が: the tagger can't see the name
        if s in ("が", "けど", "けれど") and pos1 == "接続詞" and out:
            pos1, pos2 = "助詞", "接続助詞"   # 方 がわたし: a particle cut off by a space, not "INDICATES-SUBJECT"
        if prev is not None and p2 == "固有名詞" and s == "君":
            was_after_name = True            # 田中君 -> TANAKA-kun
            st["after_name"] = True
        if was_after_name and s == "君":
            reading = pron = "クン"          # 健太君 -> KENTA-kun

        # ---- punctuation, symbols, latin text, numbers
        if pos1 in ("補助記号", "記号", "空白") or not has_japanese(s):
            p = punct_to_ascii(s)
            if not p.strip():
                # a space inside a Japanese subtitle is a pause -> show it as a comma
                if out and out[-1].text[-1:].isalnum() and not st["prefix"]:
                    out[-1].text += ","
                st["attachable"] = False
                return
            if re.fullmatch(r"[0-9A-Za-z][\w'.,-]*", p):
                if p.isdigit() and st.get("num_open") and out:   # １００ / １，０００: one number, not "1 0 0"
                    out[-1].text += p
                    out[-1].moras += max(1, len(p) // 2)
                else:
                    self._add(out, st, p, max(1, len(p) // 2 + 1), False)
                st.update(prev=w, attachable=p[:1].isdigit(), carry="", prefix_open=False,
                          num_open=p[-1:].isdigit())  # 5+年 -> 5-YEAR
                return
            if p in (",", ".") and st.get("num_open") and out and out[-1].text[-1:].isdigit():
                out[-1].text += p      # 1,000 keeps going; a non-digit next closes it
                st["num_open"] = True
                return
            st["num_open"] = False
            opening = p in ("(", "[", "<") or (p == '"' and s not in "」』》\"")
            if s == '"':
                opening = not out or out[-1].space
            if opening and (not out or out[-1].space or True):
                st["prefix"] += p
            elif out:
                out[-1].text += p
            else:
                st["prefix"] += p
            st.update(attachable=False, carry="", prefix_open=False)   # お… 大きな: not o-...-BIG
            return
        st["num_open"] = False
        if re.fullmatch(r"[ー～〜っッ]+", s):
            if out:                                   # 神+々 -> GODS? keep the sound on the word before it
                out[-1].moras += 1
            return

        moras = mora_count(pron) or (2 * len(s))

        # ---- numbers + counters (5年越し, 3日間, 2回目, 10年後): 5-YEAR THROUGHOUT, 3-DAY PERIOD, 2-TIME-me
        #      (the dictionary would otherwise glue them into odd words like 年越し = NEW-YEAR'S-EVE)
        after_counter = st.pop("after_counter", False)
        if out and prev is not None and prev.surface == "何" and out[-1].core == "WHAT" and (
                pos2 == "数詞" or s[:1].isdigit() or s in SOUND_COUNTERS or any(s.startswith(c) for c in COUNTERS)):
            out[-1].text = out[-1].text.replace("WHAT", "HOW-MANY", 1)   # 何十年, 何回 -> HOW-MANY
            out[-1].core = "HOW-MANY"
        if out:
            if pos1 in ("名詞", "接尾辞") and prev is not None and (
                    p2 == "数詞" or prev.surface.isdigit() or prev.surface == "何"):
                if s in SOUND_COUNTERS and not self._known(s):
                    kana = kata_to_hira(reading or SOUND_COUNTERS[s])
                    self._add(out, st, kana if self.o.script == "hiragana" else to_romaji(kana),
                              mora_count(reading or SOUND_COUNTERS[s]) or 2, True)
                    out[-1].jp = s
                    st.update(prev=w, attachable=True, carry="", last_gloss_idx=-1, after_counter=True)
                    return
                for c in sorted(COUNTERS, key=len, reverse=True):
                    rest = s[len(c):]
                    if s.startswith(c) and (not rest or rest in COUNTER_TAIL):
                        gloss, m1 = COUNTERS[c]
                        known = self._known(c)
                        self._add(out, st, c if known else gloss, m1, True)
                        out[-1].core, out[-1].jp, out[-1].known = ("" if known else gloss), c, known
                        out[-1].base = c
                        if rest:
                            self._counter_tail(out, st, rest)
                        st.update(prev=w, attachable=True, carry="", last_gloss_idx=-1, after_counter=not rest)
                        return
            elif after_counter and s in COUNTER_TAIL:
                self._counter_tail(out, st, s)
                st.update(prev=w, attachable=True, carry="", last_gloss_idx=-1)
                return

        if lemma in ("為る", "する") and prev is not None and prev.surface == "どう" and out and out[-1].text == "HOW":
            out[-1].text, out[-1].core = ("どう" if self.o.script == "hiragana" else "dou"), ""   # どうした -> dou-shi-ta, as in the example files
            st["attachable"], st["prev_dou"] = True, True
        # ---- should this token hang off the previous word as a "-suffix"?
        attach = False
        if st.pop("prev_dou", False):
            attach = True
        after_phrase = st.pop("after_phrase", False)
        if st["prefix_open"]:
            attach = True
        elif after_phrase and st["attachable"] and ((pos1 == "助動詞" and lemma not in ("です", "や") and s not in ("だ", "だっ", "だろ", "でし")) or (pos1 == "助詞" and (
                pos2 == "接続助詞" or s in CONJ_PARTICLES))):
            attach = True  # 作り上げ+た -> BUILD-UP-ta, 気にし+て -> WORRY-ABOUT-te
        elif st.get("after_name") and (s in HONORIFICS or lemma in HONORIFICS):
            attach = True  # KENTA-kun: the name came from the names list, so the tagger didn't see it
        elif s == "ん" and st["attachable"] and p1 in ("動詞", "助動詞", "形容詞"):
            attach = True  # explanatory ん hangs off the verb: EXIST-n da, MAKE-n janai
        elif st["attachable"]:
            if pos1 == "助動詞":
                # verb/adjective endings attach (DECIDE-ta); copulas after nouns stay separate (IDIOT da)
                attach = p1 in ("動詞", "形容詞", "助動詞") or (p1 == "形状詞" and s in ("な", "に", "だ", "で")) \
                    or (p1 == "助詞" and p2 == "接続助詞") or (p1 not in ("名詞", "代名詞", "接尾辞", "形状詞") and p1 != "")
            elif pos1 == "助詞" and (pos2 == "接続助詞" or (s in ("たり", "だり") and p1 in ("動詞", "助動詞"))) \
                    and s in CONJ_PARTICLES:
                attach = True   # 持っ+たり -> HOLD-ttari
            elif pos1 == "接尾辞":
                # a kanji suffix doesn't hang off a kana word: あんま + 火 is NOT-MUCH FIRE
                attach = not (has_kanji(s) and prev is not None and is_hiragana_only(prev.surface)
                              and s not in HONORIFICS and lemma not in HONORIFICS and p1 not in ("動詞", "助動詞"))
                if not attach:
                    pos1 = "名詞"
            elif pos1 == "動詞" and lemma == "為る" and p1 == "名詞" and "サ変" in p3:
                attach = True  # 応援+する -> CHEERING-shi
            elif pos1 == "動詞" and pos2 == "非自立可能" and (
                    p1 in ("助動詞", "動詞", "形容詞") or (p1 == "助詞" and p2 == "接続助詞")
                    or (p1 == "名詞" and "サ変" in p3)):
                attach = True
            elif pos1 == "形容詞" and pos2 == "非自立可能" and (
                    p1 in ("助動詞", "動詞") or (p1 == "助詞" and p2 == "接続助詞")):
                attach = True
            elif pos1 == "形容詞" and lemma == "無い" and p1 in ("形容詞", "形状詞") and \
                    _f(prev, "cForm").startswith("連用形"):
                attach = True   # 怖く+ない -> SCARY-ku-nai
        after_prefix = st["prefix_open"]
        st["prefix_open"] = False
        st["after_name"] = False
        st["after_word"] = False

        # ---- decide: translate (UPPERCASE English) or keep (lowercase romaji)
        proper = pos2 == "固有名詞" and not is_hiragana_only(s)   # kana-only "names" (かよ) are misreads
        if proper and s not in self.g.user_words and any(
                e[0] >= 3 and kata_to_hira(reading or "") in [kata_to_hira(r) for r in e[1]] for e in self.g.d.get(s, [])):
            proper, pos2 = False, "普通名詞"   # 毎日 EVERY-DAY, not the name MAINICHI
        has_override = bool(self.g.override(lemma, s, _f(w, "orthBase")))
        translate = False
        if was_after_name and (s in HONORIFICS or lemma in HONORIFICS):
            translate = False   # KENTA-kun, not KENTA-YOU
        elif s == "かれ" and prev is not None and prev.surface in ("て", "で"):
            translate = False   # 持ってかれ (= 持っていかれ), not かれ HE
        elif lemma in KEEP_SOUND or s in KEEP_SOUND:
            translate = False   # the example files write these as sounds: suki, yappari
        elif len(s) == 1 and is_hiragana_only(s) and not has_override:
            translate = False   # が, で, と on their own are grammar (or a cut-off word), never INDICATES-SUBJECT
        elif (s in ("ない", "なし", "ねえ", "ねー") or (lemma in ("ない", "無い") and is_hiragana_only(s)
                                                    and s[:1] == "な")) and not has_override:
            translate = False   # written in kana these are grammar: shika nai, wake nai, kangae-nashi
        elif pos1 == "接頭辞":
            translate = has_kanji(s) and s not in ("御", "第")
        elif attach and not after_prefix:
            if pos1 == "接尾辞":
                translate = has_kanji(s) and lemma not in HONORIFICS and s not in HONORIFICS
            elif (pos1 == "動詞" and pos2 == "非自立可能") or lemma == "無い":
                translate = False
            else:
                translate = pos1 in CONTENT_POS and (has_kanji(s) or has_katakana(s))
        elif proper:
            translate = True
        elif pos1 == "助詞" or pos1 == "助動詞":
            translate = False
        elif has_override and pos1 not in ("助詞", "助動詞"):
            translate = True
        elif pos1 in CONTENT_POS or pos1 == "感動詞" or after_prefix:
            if has_kanji(s):
                translate = True
            elif has_katakana(s):
                translate = pos1 != "感動詞"
            elif pos1 == "感動詞":
                translate = False
            elif lemma in KANA_TRANSLATE:
                translate = True
            elif lemma in KANA_KEEP or s in KANA_KEEP:
                translate = False
            else:
                # kana adverbs carry meaning too: ずっと FOR-A-LONG-TIME, やっと AT-LAST, きっと SURELY
                translate = pos1 in ("代名詞", "連体詞", "接続詞") or (
                    pos1 == "副詞" and len(s) > 1 and self.g.lookup([lemma, s]) is not None) or \
                    self._kana_content(pos1, pos2, lemma, s)

        gloss = None
        if translate:
            if proper:
                gloss = self.g.override(lemma, s) or (self._name(reading) if reading else self._gloss(w))
            else:
                gloss = self._gloss(w, suffix=attach)
                if s in ("やつ", "奴") and prev is not None and prev.surface in ("って", "という", "っていう", "とかいう"):
                    gloss = "THING"         # 現実ってやつ: "this thing called reality", not a GUY
            if not gloss:
                if has_kanji(s) or proper:
                    gloss = self._name(reading) if reading else s
                else:
                    translate = False  # e.g. katakana onomatopoeia -> lowercase romaji

        # compound lookup: 世界+中 -> 世界中 "around the world", 高校+生 -> "high-school student"
        if translate and attach and pos1 == "接尾辞" and out and prev is not None and has_kanji(prev.surface):
            whole = (out[-1].base or "") + s
            comp = (self.g.lookup([whole]) if whole != prev.surface + s and whole in self.g.d else None) \
                or self.g.lookup([prev.surface + s])    # 結婚相談+所 -> 結婚相談所 MARRIAGE-AGENCY
            if self._known(prev.surface + s) and st.get("last_gloss_idx") == len(out) - 1:
                out[-1].text = out[-1].text[: len(out[-1].text) - len(st["last_gloss"])] + prev.surface + s
                out[-1].core, out[-1].jp, out[-1].known = "", out[-1].jp + s, True
                out[-1].moras += moras
                st.update(prev=w, attachable=True, carry="", last_gloss=prev.surface + s)
                return
            if comp and not out[-1].known and st.get("last_gloss_idx") == len(out) - 1:
                out[-1].text = out[-1].text[: len(out[-1].text) - len(st["last_gloss"])] + comp
                out[-1].core, out[-1].jp = comp, out[-1].jp + s
                out[-1].base = prev.surface + s
                out[-1].reading = self._base_reading(None, out[-1].base, "")
                out[-1].moras += moras
                st.update(prev=w, attachable=True, carry="", last_gloss=comp)
                return

        carry = st["carry"]
        st["carry"] = ""
        if translate:
            tail, new_carry = "", ""
            if pos1 in ("動詞", "形容詞") and has_kanji(s):
                m = re.search(r"[ぁ-ゖ]+$", s)
                ktail = m.group(0) if m else ""
                if ktail:
                    if "音便" in cform:
                        # 良かっ+た -> GOOD-katta; a verb keeps only the sound change: 分かっ+て -> UNDERSTAND-tte
                        new_carry = ktail[-1:] if pos1 == "動詞" else ktail
                    elif "一段" in ctype and not cform.startswith(("終止形", "連体形")):
                        tail = ""                  # 決め+た -> DECIDE-ta
                    else:
                        tail = ktail[-1]           # 伝える -> TELL-ru, 凄い -> INCREDIBLE-i
            elif pos1 in ("動詞", "形容詞") and is_hiragana_only(s):
                if "音便" in cform and s[-1] in "っん":
                    new_carry = s[-1]
                elif not cform.startswith("連用形") or "一段" not in ctype:
                    tail = s[-1] if len(s) > 1 and not ("一段" in ctype and not cform.startswith(("終止形", "連体形"))) else ""
            tail_m = mora_count(tail) + mora_count(new_carry)
            known = self._known(lemma, _f(w, "orthBase"), s)
            if known:   # keep the word itself (kanji and all); its ending still follows the sounds
                if len(new_carry) > 1:   # 大きかっ+た -> 大きか-tta (only the っ/ん moves on)
                    keep = new_carry[:-1] if new_carry[-1] in "っん" else new_carry
                    new_carry = new_carry[len(keep):]
                    tail_m = mora_count(tail) + mora_count(new_carry)
                cut = len(tail) + len(new_carry)
                gloss = s[:len(s) - cut] if cut and len(s) > cut else s
            # noun + adjective/verb that the dictionary knows as one word: 興味+深い -> 興味深い FASCINATING
            comp_base = (prev.surface + (_f(w, "orthBase") or s)) if prev is not None else ""
            comp = None
            noun_pair = (pos1 == "名詞" and p1 == "名詞" and KANJI_ONLY.fullmatch(s or "") and
                         KANJI_ONLY.fullmatch(prev.surface or "") and len(comp_base) >= 3)
            if (not known and (pos1 in ("形容詞", "動詞") or noun_pair) and p1 == "名詞" and has_kanji(prev.surface)
                    and st.get("last_gloss_idx") == len(out) - 1 and out and not out[-1].known):
                comp = self.g.override(comp_base) or (self.g.lookup([comp_base]) if comp_base in self.g.d else None)
            if comp:
                comp = comp.upper()
                last = out[-1]
                last.text = last.text[: len(last.text) - len(st["last_gloss"])] + comp
                last.core, last.jp, last.base = comp, last.jp + s, comp_base
                last.reading = self._base_reading(None, comp_base, "")
                last.moras += max(moras - tail_m, 1)
                st.update(last_gloss=comp)
                if tail:
                    self._add(out, st, self._lower(tail, tail), mora_count(tail), True)
                st["carry"] = new_carry
                st["prev"] = w
                st["attachable"] = True
                return
            self._add(out, st, gloss, max(moras - tail_m, 1), attach)
            out[-1].core, out[-1].jp, out[-1].known = ("" if known else gloss), s, known
            out[-1].yomi, out[-1].yomi_jp = kata_to_hira(reading or ""), s
            out[-1].cut = len(tail) + len(new_carry)
            base = _f(w, "orthBase") or s
            out[-1].base, out[-1].reading, out[-1].name = base, self._base_reading(w, base, reading), proper
            if proper and not known and self.o.name_style != "name":
                out[-1].text = self._with_meaning(out[-1].text, s)
            st.update(last_gloss_idx=len(out) - 1, last_gloss=gloss)
            if tail:
                self._add(out, st, self._lower(tail, tail), mora_count(tail), True)
            st["carry"] = new_carry
        else:
            particle = pos1 == "助詞"
            body_s, body_r = s, kata_to_hira(reading or s)
            # move a trailing small tsu to the next suffix: だっ+たら -> da-ttara
            if body_s.endswith("っ") and len(body_s) > 1 and pos1 in ("助動詞", "動詞", "形容詞"):
                body_s, body_r = body_s[:-1], body_r[:-1] if body_r.endswith("っ") else body_r
                st["carry"] = "っ"
            if carry:
                body_s, body_r = carry + body_s, kata_to_hira(carry) + body_r
            txt = self._lower(body_s, body_r, particle and not carry, pos2)
            if self.o.script == "hiragana":
                txt = body_s if not has_kanji(body_s) else kata_to_hira(body_r)
            if pos1 not in ("助詞", "助動詞", "接尾辞") and not attach and \
                    self._known(lemma, _f(w, "orthBase"), s):
                txt = body_s   # a kana word you know (やめる, ばか): written in Japanese
            self._add(out, st, txt, moras, attach)
        st["prev"] = w
        st["attachable"] = not (pos1 in ("感動詞", "接続詞") or (pos1 == "助詞" and pos2 != "接続助詞"))
        if pos1 == "接頭辞":
            st["prefix_open"] = True


def add_ruby(syls, tagger, script="romaji"):
    """Set Syl.ruby: how each translated word is said, for the small text above it.
    Only the part of the Japanese that the English replaces: 伝える -> TELL-ru gets "tsutae"."""
    for i, s in enumerate(syls):
        s.ruby = ""
        if not s.core or s.known or s.name or not has_japanese(s.jp or ""):
            continue
        jp = s.jp
        if s.yomi and s.yomi_jp == jp:
            yomi = s.yomi
        elif not has_kanji(jp):
            yomi = jp
        else:
            yomi = "".join((_f(t, "kana") or t.surface) for t in tagger(jp))
        yomi = re.sub(r"[^ぁ-ゖァ-ヺー]", "", yomi)
        if not yomi:
            continue
        katakana = has_katakana(jp) and not has_kanji(jp) and not re.search(r"[ぁ-ゖ]", jp)
        yomi = re.sub(r"[^ァ-ヺー]", "", jp) or yomi if katakana else kata_to_hira(yomi)   # loanwords stay katakana
        if s.yomi_jp == jp and s.cut:
            if len(yomi) > s.cut:
                yomi = yomi[:-s.cut]
        elif i + 1 < len(syls) and syls[i + 1].text.startswith("-") and not syls[i + 1].core:
            nxt = syls[i + 1].text.lstrip("-").rstrip(",.!?")       # 身に付けよう = ACQUIRE-you
            r = to_romaji(yomi)
            if nxt and (yomi.endswith(nxt) or r.endswith(nxt)) and len(r) > len(nxt):
                if yomi.endswith(nxt):
                    yomi = yomi[:-len(nxt)]
                else:
                    for k in range(len(yomi) - 1, 0, -1):
                        if to_romaji(yomi[:k]) == r[:len(r) - len(nxt)]:
                            yomi = yomi[:k]
                            break
        s.ruby = yomi if script == "hiragana" else to_romaji(yomi)


def syllables_to_plain(syls):
    return "".join(s.text + (" " if s.space else "") for s in syls).strip()
