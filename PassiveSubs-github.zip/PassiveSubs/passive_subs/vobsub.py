"""DVD picture subtitles (VobSub: an .idx + .sub pair, or a DVD subtitle track inside a video).

Like Blu-ray .sup files these hold pictures, not text; ocr.py has Claude read them.
read_vobsub() returns [(start_ms, end_ms, picture)] with the picture as dark text on white
(a greyscale numpy array), the same as pgs.read_sup().
"""
import os
import re
import struct

import numpy as np


def _palette_from_text(text):
    m = re.search(r"palette:\s*([0-9a-fA-F,\s]+)", text)
    if not m:
        return None
    cols = [c.strip() for c in m.group(1).split(",") if c.strip()]
    pal = []
    for c in cols[:16]:
        v = int(c, 16)
        r, g, b = (v >> 16) & 255, (v >> 8) & 255, v & 255
        pal.append(0.299 * r + 0.587 * g + 0.114 * b)
    return pal if len(pal) == 16 else None


def parse_idx(idx_path):
    """(palette luminances or None, [(timestamp_ms, filepos)]) for the Japanese track (else the first)."""
    with open(idx_path, "rb") as f:
        text = f.read().decode("latin-1")
    tracks, cur = {}, None
    for line in text.splitlines():
        m = re.match(r"\s*id:\s*([a-zA-Z-]*)\s*,\s*index:\s*(\d+)", line)
        if m:
            cur = (m.group(1).lower(), int(m.group(2)))
            tracks[cur] = []
            continue
        m = re.match(r"\s*timestamp:\s*(\d+):(\d+):(\d+):(\d+),\s*filepos:\s*([0-9a-fA-F]+)", line)
        if m and cur is not None:
            h, mi, s, ms = (int(x) for x in m.groups()[:4])
            tracks[cur].append(((h * 3600 + mi * 60 + s) * 1000 + ms, int(m.group(5), 16)))
    if not tracks or not any(tracks.values()):
        return _palette_from_text(text), None, None      # palette only (made for a track from inside a video)
    jp = [k for k in tracks if k[0] in ("ja", "jp", "jpn", "japanese")]
    key = jp[0] if jp else sorted(tracks, key=lambda k: k[1])[0]
    return _palette_from_text(text), tracks[key], key[1]


def _packets(data, start=0, stream=None):
    """Walk an MPEG program stream: yields (pts_ms or None, substream id, payload, packet offset)."""
    i, n = start, len(data)
    while i + 6 <= n:
        if data[i:i + 3] != b"\x00\x00\x01":
            j = data.find(b"\x00\x00\x01", i + 1)
            if j < 0:
                return
            i = j
            continue
        code = data[i + 3]
        if code == 0xBA:                                  # pack header
            if i + 14 <= n and (data[i + 4] & 0xC0) == 0x40:
                i += 14 + (data[i + 13] & 7)              # MPEG-2
            else:
                i += 12                                   # MPEG-1
            continue
        if code == 0xB9:                                  # end of stream
            i += 4
            continue
        length = struct.unpack(">H", data[i + 4:i + 6])[0]
        body = data[i + 6:i + 6 + length]
        if code == 0xBD and len(body) >= 3:               # private stream 1: subpictures live here
            hdr_len = body[2]
            pts = None
            if body[1] & 0x80 and len(body) >= 8:
                p = body[3:8]
                pts = (((p[0] >> 1) & 7) << 30 | p[1] << 22 | (p[2] >> 1) << 15 | p[3] << 7 | p[4] >> 1) // 90
            payload = body[3 + hdr_len:]
            if payload:
                sid = payload[0]
                if 0x20 <= sid < 0x40 and (stream is None or sid == 0x20 + stream):
                    yield pts, sid, payload[1:], i
        i += 6 + length


def _rle_field(data, pos, w, rows, img, first_row):
    """Decode one interlaced field (every second row) of 2-bit run-length pixels."""
    nib_pos = pos * 2

    def nib():
        nonlocal nib_pos
        b = data[nib_pos // 2] if nib_pos // 2 < len(data) else 0
        v = (b >> 4) if nib_pos % 2 == 0 else (b & 15)
        nib_pos += 1
        return v
    y = first_row
    while y < rows:
        x = 0
        while x < w:
            v = nib()
            if v < 0x4:
                v = (v << 4) | nib()
                if v < 0x10:
                    v = (v << 4) | nib()
                    if v < 0x40:
                        v = (v << 4) | nib()
            run, color = v >> 2, v & 3
            if run == 0:
                run = w - x
            img[y, x:x + run] = color
            x += run
        if nib_pos % 2:
            nib_pos += 1                                  # each row starts on a whole byte
        y += 2


def _decode_spu(spu):
    """One subpicture unit -> (start_delay_ms, stop_delay_ms or None, index image, colors, alphas)."""
    size, ctrl = struct.unpack(">HH", spu[:4])
    start_d = stop_d = None
    colors, alphas = [0, 1, 2, 3], [0, 15, 15, 15]
    x1 = x2 = y1 = y2 = 0
    off1 = off2 = 4
    pos = ctrl
    for _ in range(64):
        if pos + 4 > len(spu):
            break
        delay = struct.unpack(">H", spu[pos:pos + 2])[0] * 1024 // 90   # 1024/90000 s ticks -> ms
        nxt = struct.unpack(">H", spu[pos + 2:pos + 4])[0]
        p = pos + 4
        while p < len(spu):
            cmd = spu[p]
            p += 1
            if cmd == 0x00 or cmd == 0x01:
                start_d = delay if start_d is None else start_d
            elif cmd == 0x02:
                stop_d = delay
            elif cmd == 0x03:
                a, b = spu[p], spu[p + 1]
                colors = [b & 15, b >> 4, a & 15, a >> 4]
                p += 2
            elif cmd == 0x04:
                a, b = spu[p], spu[p + 1]
                alphas = [b & 15, b >> 4, a & 15, a >> 4]
                p += 2
            elif cmd == 0x05:
                c = spu[p:p + 6]
                x1, x2 = (c[0] << 4) | (c[1] >> 4), ((c[1] & 15) << 8) | c[2]
                y1, y2 = (c[3] << 4) | (c[4] >> 4), ((c[4] & 15) << 8) | c[5]
                p += 6
            elif cmd == 0x06:
                off1, off2 = struct.unpack(">HH", spu[p:p + 4])
                p += 4
            elif cmd == 0xFF:
                break
            else:                                         # unknown/extended command: stop reading this block
                break
        if nxt == pos or nxt >= len(spu):
            break
        pos = nxt
    w, h = x2 - x1 + 1, y2 - y1 + 1
    if w <= 0 or h <= 0 or w > 4096 or h > 4096:
        return None
    img = np.zeros((h, w), dtype=np.uint8)
    try:
        _rle_field(spu, off1, w, h, img, 0)
        _rle_field(spu, off2, w, h, img, 1)
    except IndexError:
        pass
    return start_d or 0, stop_d, img, colors, alphas


def _render(img, colors, alphas, palette):
    """Index image -> dark text on white. With a palette, the bright opaque colour is the letters' fill;
    without one, the fill is the colour whose pixels are mostly surrounded by other opaque pixels."""
    opaque = [alphas[k] >= 8 for k in range(4)]
    ink_idx = []
    if palette:
        lum = [palette[colors[k]] for k in range(4)]
        ink_idx = [k for k in range(4) if opaque[k] and lum[k] > 128]
        if not ink_idx:
            ink_idx = [k for k in range(4) if opaque[k] and lum[k] <= 128]
    if not ink_idx:
        solid = np.isin(img, [k for k in range(4) if opaque[k]])
        inner = solid.copy()
        inner[1:, :] &= solid[:-1, :]
        inner[:-1, :] &= solid[1:, :]
        inner[:, 1:] &= solid[:, :-1]
        inner[:, :-1] &= solid[:, 1:]
        best, best_ratio = None, -1
        for k in range(4):
            if not opaque[k]:
                continue
            cnt = int((img == k).sum())
            if cnt < 20:
                continue
            ratio = float((inner & (img == k)).sum()) / cnt
            if ratio > best_ratio:
                best, best_ratio = k, ratio
        ink_idx = [best] if best is not None else [k for k in range(4) if opaque[k]]
    out = np.full(img.shape, 255, dtype=np.uint8)
    out[np.isin(img, ink_idx)] = 0
    ys, xs = np.nonzero(out == 0)
    if len(ys) < 10:
        return None
    out = out[max(0, ys.min() - 2):ys.max() + 3, max(0, xs.min() - 2):xs.max() + 3]
    return np.pad(out, 20, constant_values=255)


def _units(data, entries=None, stream=None):
    """Join packets into whole subpicture units: [(time_ms, spu bytes)]."""
    units = []
    if entries:
        for ts, filepos in entries:
            buf, size = b"", None
            for _pts, _sid, payload, _off in _packets(data, filepos, stream):
                buf += payload
                if size is None and len(buf) >= 2:
                    size = struct.unpack(">H", buf[:2])[0]
                if size is not None and len(buf) >= size:
                    break
            if size:
                units.append((ts, buf[:size]))
        return units
    buf, size, t0 = b"", None, 0
    for pts, _sid, payload, _off in _packets(data, 0, stream):
        if size is None:
            buf, t0 = b"", pts or 0
            if len(payload) >= 2:
                size = struct.unpack(">H", payload[:2])[0]
        buf += payload
        if size is not None and len(buf) >= size:
            units.append((t0, buf[:size]))
            buf, size = b"", None
    return units


def is_vobsub(path):
    """A DVD picture subtitle file: .idx, or a .sub/.vob that is an MPEG program stream (not MicroDVD text)."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".idx":
        return True
    if ext in (".sub", ".vob"):
        try:
            with open(path, "rb") as f:
                return f.read(4) == b"\x00\x00\x01\xba"
        except OSError:
            return False
    return False


def read_vobsub(path, palette_text=None):
    """path: an .idx (its .sub beside it), or a DVD program stream (.sub/.vob) with no .idx.
    palette_text: the track's 'palette: ...' line when known (from a video's subtitle track)."""
    base, ext = os.path.splitext(path)
    idx = path if ext.lower() == ".idx" else (base + ".idx" if os.path.exists(base + ".idx") else None)
    sub = base + ".sub" if ext.lower() == ".idx" else path
    if not os.path.exists(sub):
        raise ValueError("the .sub file that goes with %s is missing" % os.path.basename(path))
    with open(sub, "rb") as f:
        data = f.read()
    palette, entries, stream = None, None, None
    if idx:
        palette, entries, stream = parse_idx(idx)
    if palette is None and palette_text:
        palette = _palette_from_text(palette_text)
    events = []
    for t, spu in _units(data, entries, stream):
        d = _decode_spu(spu)
        if not d:
            continue
        start_d, stop_d, img, colors, alphas = d
        pic = _render(img, colors, alphas, palette)
        if pic is None:
            continue
        start = t + start_d
        events.append([start, t + stop_d if stop_d and stop_d < 30000 else None, pic])
    events.sort(key=lambda e: e[0])
    for i, e in enumerate(events):
        if e[1] is None or e[1] <= e[0]:
            nxt = events[i + 1][0] if i + 1 < len(events) else e[0] + 4000
            e[1] = min(nxt, e[0] + 5000)
    return [tuple(e) for e in events]
