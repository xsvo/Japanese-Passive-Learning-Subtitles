"""Turn Blu-ray picture subtitles (.sup) into a Japanese .srt, by having Claude read the pictures.

The result is saved next to the .sup as "<name>.ja.srt", so it is only read (and paid for) once.
After that the .srt is used like any other Japanese subtitle file.
"""
import base64
import hashlib
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from .pgs import read_sup, png

PER_CALL = 10        # pictures per request

SYSTEM = (
    "You transcribe Japanese subtitle pictures from an anime Blu-ray. For each numbered picture, write "
    "exactly the Japanese text it shows, character for character: kanji, kana, punctuation like ？！… "
    "and full-width brackets such as （ハナコ）. Do not translate, correct, or add anything. "
    "Vertical text is read top to bottom, right column first. If a picture has text in two separate places "
    "(for example a vertical caption at the side and a line at the bottom), write each place on its own line, "
    "the vertical one first. Write each line break in the picture as a new line. Small furigana above or beside "
    "kanji are not separate text: leave them out. If a picture has no readable text, return an empty string.")

SCHEMA = {
    "type": "object",
    "properties": {"pictures": {"type": "array", "items": {
        "type": "object",
        "properties": {"n": {"type": "integer"}, "text": {"type": "string"}},
        "required": ["n", "text"], "additionalProperties": False}}},
    "required": ["pictures"],
    "additionalProperties": False,
}


def srt_path_for(sup_path):
    return os.path.splitext(sup_path)[0] + ".ja.srt"


def _png(img):
    return base64.b64encode(png(img)).decode("ascii")


def _merge(events):
    """The same picture shown in back-to-back pieces (common in .sup) becomes one subtitle."""
    out = []
    for s, e, img in events:
        key = hashlib.md5(img.tobytes() + bytes(str(img.shape), "ascii")).hexdigest()
        if out and out[-1][3] == key and s - out[-1][1] < 50:
            out[-1][1] = e
        else:
            out.append([s, e, img, key])
    return out


def _ts(ms):
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def _cache_path(out):
    return out + ".read.json"   # pictures read so far: lets a stopped or partly failed run carry on


def sup_to_srt(sup_path, api_key, log=print, progress=None, out=None):
    """Reads the .sup and writes <name>.ja.srt next to it (reused once every picture is read). Returns its path."""
    out = out or srt_path_for(sup_path)
    cache_file = _cache_path(out)
    cache = {}
    try:
        with open(cache_file, encoding="utf-8") as f:
            cache = json.load(f)
    except (OSError, ValueError):
        pass
    if cache.get("complete") and cache.get("sup_mtime") == os.path.getmtime(sup_path) and os.path.exists(out):
        log("  Using the text already read from these picture subtitles (%s)" % os.path.basename(out))
        return out
    if not cache and os.path.exists(out) and os.path.getmtime(out) >= os.path.getmtime(sup_path):
        log("  Using the text already read from these picture subtitles (%s)" % os.path.basename(out))
        return out      # made by an earlier version of the app
    if cache.get("sup_mtime") != os.path.getmtime(sup_path):
        cache = {}
    if not api_key and not os.environ.get("ANTHROPIC_API_KEY"):
        raise RuntimeError(
            "These subtitles are pictures (Blu-ray .sup or DVD .idx/.sub), not text. To turn them into text the app asks Claude to read "
            "them, which needs your Anthropic API key: paste it in the Claude AI box (the AI option itself can "
            "stay off). Or use a Japanese .srt/.ass for this episode instead.")
    from .ai_gloss import MODEL
    import anthropic
    client = anthropic.Anthropic(api_key=api_key or None, max_retries=6)   # waits out rate limits

    log("  Reading the subtitle pictures in %s..." % os.path.basename(sup_path))
    if sup_path.lower().endswith(".sup"):
        pictures = read_sup(sup_path)
    else:
        from .vobsub import read_vobsub
        pictures = read_vobsub(sup_path)
    events = _merge(pictures)
    unique = {}
    for ev in events:
        unique.setdefault(ev[3], ev[2])
    text = dict(cache.get("text", {}))
    keys = [k for k in unique if k not in text]
    log("  %d subtitles, %d different pictures%s. Asking Claude to read them..."
        % (len(events), len(unique), " (%d already read)" % (len(unique) - len(keys)) if text else ""))
    lock = threading.Lock()

    def save():
        with lock, open(cache_file, "w", encoding="utf-8") as f:
            json.dump({"sup_mtime": os.path.getmtime(sup_path), "complete": len(text) >= len(unique),
                       "text": text}, f, ensure_ascii=False)

    def call(batch):
        content = []
        for n, k in enumerate(batch, 1):
            content.append({"type": "text", "text": "Picture %d:" % n})
            content.append({"type": "image", "source": {"type": "base64", "media_type": "image/png",
                                                        "data": _png(unique[k])}})
        content.append({"type": "text", "text": "Transcribe pictures 1-%d: return exactly %d entries, n = 1 to %d, "
                                                "in order (an empty text for a picture with no text)."
                                                % (len(batch), len(batch), len(batch))})
        resp = client.beta.messages.create(
            model=MODEL, max_tokens=8000,
            betas=["server-side-fallback-2026-07-01"], fallbacks="default",
            system=SYSTEM,
            output_config={"effort": "low", "format": {"type": "json_schema", "schema": SCHEMA}},
            messages=[{"role": "user", "content": content}])
        data = json.loads(next(b.text for b in resp.content if b.type == "text"))
        got = {p["n"]: p["text"] for p in data["pictures"]}
        if sorted(got) != list(range(1, len(batch) + 1)):
            # numbering doesn't line up: texts could land on the wrong subtitles, so don't use any of it
            raise ValueError("answer numbered %d pictures, expected %d" % (len(got), len(batch)))
        return {batch[n - 1]: t for n, t in got.items()}

    def ask(batch):
        last = None
        for attempt in range(3):
            try:
                return call(batch)
            except anthropic.AuthenticationError:
                raise
            except Exception as e:
                last = e
                time.sleep(5 * 3 ** attempt)
        if len(batch) > 1:      # try smaller groups, down to one picture at a time
            h = len(batch) // 2
            return {**ask(batch[:h]), **ask(batch[h:])}
        log("  One subtitle picture couldn't be read (%s: %s)." % (type(last).__name__, last))
        return {}

    def job(batch):
        r = ask(batch)
        with lock:
            text.update(r)
        save()
        return r

    batches = [keys[i:i + PER_CALL] for i in range(0, len(keys), PER_CALL)]
    with ThreadPoolExecutor(max_workers=2) as ex:
        for done, _r in enumerate(ex.map(job, batches), 1):
            if progress:
                progress(done / len(batches))
    save()
    n = 0
    with open(out, "w", encoding="utf-8") as f:
        for s, e, _img, k in events:
            t = "\n".join(l.strip() for l in text.get(k, "").strip().splitlines() if l.strip())
            if not t:
                continue
            n += 1
            f.write("%d\n%s --> %s\n%s\n\n" % (n, _ts(s), _ts(e), t))
    missing = len(unique) - len(text)
    log("  Read %d of %d pictures; saved the Japanese text as %s" % (len(text), len(unique), os.path.basename(out)))
    if missing:
        log("  WARNING: %d subtitle pictures couldn't be read, so those lines are missing. Convert again later "
            "to read just those." % missing)
    if not n:
        os.remove(out)
        raise RuntimeError("No text could be read from the subtitle pictures.")
    return out
