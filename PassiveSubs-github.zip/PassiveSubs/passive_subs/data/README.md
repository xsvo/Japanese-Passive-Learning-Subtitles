# Data files

| File | What it is | Licence |
|---|---|---|
| `jmdict_gloss.json.gz` | Compact Japanese headword -> English gloss table, plus single-kanji meanings (keys starting with `#`). | CC BY-SA (see below) |
| `overrides.txt` | Hand-picked glosses that win over the dictionary. | MIT, like the code |
| `phrases.txt` | Multi-word phrases matched before word splitting. | MIT, like the code |
| `names/` | Name lists, one `.txt` per show. Only `Example_Show.txt` is included; add your own. | MIT, like the code |

## JMdict / KANJIDIC2 attribution

`jmdict_gloss.json.gz` is derived from the **JMdict** and **KANJIDIC2** dictionary files. These files are the
property of the [Electronic Dictionary Research and Development Group](https://www.edrdg.org/), and are used in
conformance with the Group's [licence](https://www.edrdg.org/edrdg/licence.html).

The source used is the compiled database in the [jamdict-data](https://pypi.org/project/jamdict-data/) package
(version 1.5), which distributes the dictionaries under the Creative Commons Attribution-ShareAlike licence.
This derived file is shared under the same licence (CC BY-SA). It was changed from the original: only English
glosses are kept, shortened to the first short gloss of the first senses, with up to four entries per headword
ranked by frequency tags.

To rebuild it yourself:

```
pip install jamdict-data
python tools/build_dict.py
```
