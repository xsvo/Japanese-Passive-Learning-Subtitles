"""Japanese word splitting.

Uses fugashi (MeCab + UniDic) when it is installed, which is the most accurate. On Pythons that
fugashi has no ready-made build for (e.g. 3.15), falls back to janome, a pure-Python tokenizer,
and translates its IPADIC tags into the UniDic-style fields the analyzer expects.
"""
from types import SimpleNamespace

ENGINE = None

# IPADIC writes kana-only dictionary forms; UniDic uses kanji lemmas. The analyzer's word lists
# use UniDic lemmas, so map the common ones.
_KANA_LEMMA = {
    "なる": "成る", "ある": "有る", "いる": "居る", "くる": "来る", "いく": "行く", "ゆく": "行く",
    "みる": "見る", "いう": "言う", "いい": "良い", "よい": "良い", "ない": "無い", "わかる": "分かる",
    "すごい": "凄い", "だめ": "駄目", "みんな": "皆", "まだ": "未だ", "する": "為る", "くれる": "呉れる",
    "しまう": "仕舞う", "もらう": "貰う", "もの": "物", "こと": "事", "よう": "様", "わけ": "訳",
    "はず": "筈", "そう": "然う", "やっぱり": "矢っ張り", "やっぱ": "矢っ張り", "おく": "置く",
    "あげる": "上げる", "やる": "遣る", "いただく": "頂く", "くださる": "下さる", "ちょっと": "一寸",
    "こう": "斯う", "ござる": "御座る", "ところ": "所", "とこ": "所", "ほう": "方",
}
_POS1 = {"接頭詞": "接頭辞", "記号": "補助記号", "フィラー": "感動詞", "その他": "補助記号"}


def _form(f):
    if f in ("*", ""):
        return ""
    if "タ接続" in f or "テ接続" in f or "音便" in f:
        return "連用形-促音便"
    if f.startswith("基本形"):
        return "終止形-一般"
    if f.startswith("体言接続"):
        return "連体形-一般"
    if f.startswith("命令"):
        return "命令形"
    if f.startswith("連用"):
        return "連用形-一般"
    if f.startswith("未然"):
        return "未然形-一般"
    if f.startswith("仮定"):
        return "仮定形-一般"
    return f


def _janome_token(t):
    pos = t.part_of_speech.split(",")
    p1, p2, p3 = pos[0], pos[1] if len(pos) > 1 else "*", pos[2] if len(pos) > 2 else "*"
    n1, n2, n3 = _POS1.get(p1, p1), p2, ""
    if p1 == "名詞":
        if p2 == "代名詞":
            n1, n2 = "代名詞", ""
        elif p2 == "固有名詞":
            n2 = "固有名詞"
        elif p2 == "数":
            n2 = "数詞"
        elif p2 == "接尾":
            n1, n2 = "接尾辞", "名詞的"
        elif p2 == "形容動詞語幹":
            n1, n2 = "形状詞", "一般"
        elif p2 == "サ変接続":
            n2, n3 = "普通名詞", "サ変可能"
        else:
            n2 = "普通名詞"
    elif p1 == "動詞":
        if p2 == "接尾":
            n1, n2 = "助動詞", ""
        else:
            n2 = "非自立可能" if p2 == "非自立" else "一般"
    elif p1 == "形容詞":
        if p2 == "接尾":
            n1, n2 = "接尾辞", "形容詞的"
        else:
            n2 = "非自立可能" if p2 == "非自立" else "一般"
    elif p1 == "助詞":
        n2 = {"連体化": "格助詞", "副詞化": "格助詞", "並立助詞": "副助詞", "特殊": "副助詞"}.get(p2, p2)
    reading = t.reading if t.reading not in ("*", None) else ""
    pron = t.phonetic if t.phonetic not in ("*", None) else reading
    base = t.base_form if t.base_form not in ("*", None) else t.surface
    lemma = _KANA_LEMMA.get(base, base)
    feat = SimpleNamespace(pos1=n1, pos2=n2, pos3=n3, cType=t.infl_type if t.infl_type != "*" else "",
                           cForm=_form(t.infl_form), lemma=lemma, orthBase=base, kana=reading, pron=pron,
                           lForm="", kanaBase="")
    return SimpleNamespace(surface=t.surface, feature=feat)


def get_tagger():
    """Returns a callable text -> list of tokens with .surface and UniDic-style .feature."""
    global ENGINE
    try:
        import fugashi
        tagger = fugashi.Tagger()
        ENGINE = "fugashi + UniDic"
        return lambda text: list(tagger(text))
    except Exception:
        pass
    from janome.tokenizer import Tokenizer
    jt = Tokenizer()
    ENGINE = "janome (pure Python)"
    return lambda text: _janome_fix([_janome_token(t) for t in jt.tokenize(text)])


def _tok(surface, pos1, pos2, lemma, kana, cType="", cForm=""):
    return SimpleNamespace(surface=surface, feature=SimpleNamespace(
        pos1=pos1, pos2=pos2, pos3="", cType=cType, cForm=cForm, lemma=lemma, orthBase=lemma,
        kana=kana, pron=kana, lForm="", kanaBase=""))


def _janome_fix(toks):
    """IPADIC misreads casual 'te-ta-n' (死んでたんじゃない) as the noun たん. Split it back."""
    out = []
    for t in toks:
        if (t.surface in ("たん", "たの") and t.feature.pos1 == "名詞" and out
                and out[-1].surface in ("て", "で")):
            out.append(_tok("た", "助動詞", "", "た", "タ", "特殊・タ", "連体形-一般"))
            out.append(_tok(t.surface[1], "助詞", "準体助詞", t.surface[1], "ン" if t.surface[1] == "ん" else "ノ"))
            continue
        if t.surface == "うの" and out and out[-1].surface in ("じゃ", "ちゃ"):
            # 死んじゃうの: IPADIC reads うの as a name; it is じゃう (finish/end up) + の
            out[-1] = _tok(out[-1].surface + "う", "動詞", "非自立可能", "ちゃう", "チャウ" if out[-1].surface == "ちゃ" else "ジャウ")
            out.append(_tok("の", "助詞", "終助詞", "の", "ノ"))
            continue
        out.append(t)
    return out
